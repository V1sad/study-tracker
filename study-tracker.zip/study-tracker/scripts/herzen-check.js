'use strict';
// Проверка разбора расписания на твоём сервере:
//   node scripts/herzen-check.js 24298        — загрузить группу по номеру и показать пары
//   node scripts/herzen-check.js --raw 24298  — показать текст страницы (для отладки разбора)
//   node scripts/herzen-check.js --find ПМИ   — найти группы по названию
//   node scripts/herzen-check.js --exams 24298 — экзамены и зачёты группы (+ --raw-exams: текст вкладок для отладки)
const herzen = require('../server/herzen');
const DOW = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
(async () => {
  const args = process.argv.slice(2);
  const raw = args[0] === '--raw', find = args[0] === '--find', exams = args[0] === '--exams', rawEx = args[0] === '--raw-exams';
  const arg = args[raw || find || exams || rawEx ? 1 : 0];
  if (!arg) { console.log('Использование: node scripts/herzen-check.js [--raw|--find|--exams|--raw-exams] <номер группы | часть названия>'); process.exit(1); }
  if (rawEx) {
    for (const tab of ['exams', 'credits-practice']) {
      const res = await fetch(`https://guide.herzen.spb.ru/schedule/${encodeURIComponent(arg)}/${tab}`, { headers: { 'user-agent': 'StudyTracker/1.0' } });
      console.log(`===== ${tab} (HTTP ${res.status}) =====`);
      console.log(herzen.htmlToLines(await res.text()).slice(0, 200).join('\n'));
    }
    return;
  }
  if (exams) {
    const today = new Date().toISOString().slice(0, 10);
    const list = await herzen.exams(arg, today, { fresh: true });
    console.log(`Экзаменов и зачётов: ${list.length}`);
    for (const e of list) console.log(`${e.date} ${e.start}${e.end ? '–' + e.end : ''} | ${e.title} | ${e.kind} | ${e.room} | ${e.teacher}`);
    return;
  }
  if (find) {
    for (const g of await herzen.searchGroups(arg, 50)) console.log(g.id, g.name);
    return;
  }
  if (raw) {
    const res = await fetch(`https://guide.herzen.spb.ru/schedule/${encodeURIComponent(arg)}/classes`, { headers: { 'user-agent': 'StudyTracker/1.0' } });
    console.log(herzen.htmlToLines(await res.text()).slice(0, 200).join('\n'));
    return;
  }
  const lessons = await herzen.classes(arg);
  console.log(`Распознано пар: ${lessons.length}`);
  for (const l of lessons) {
    console.log(`${DOW[l.dow]} ${l.start}–${l.end} | ${l.title} | ${l.kind} | ${l.room} | ${l.teacher}${l.week ? ' | неделя ' + l.week : ''}${l.ranges.length ? ' | ' + l.ranges.map((r) => r.join('…')).join(', ') : ''}`);
  }
})().catch((e) => { console.error('Ошибка:', e.message); process.exit(1); });
