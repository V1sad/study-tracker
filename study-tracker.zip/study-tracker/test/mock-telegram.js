'use strict';
// Имитация Telegram Bot API для тестов: принимает вызовы бота, хранит отправленные сообщения.
const http = require('http');

function createMock(port) {
  const sent = [];          // { chat_id, text, extra }
  const edits = [];
  const queue = [];         // входящие апдейты
  let nextId = 1;
  const waiters = [];

  const server = http.createServer((req, res) => {
    let raw = '';
    req.on('data', (c) => { raw += c; });
    req.on('end', () => {
      const body = raw ? JSON.parse(raw) : {};
      const url = req.url;
      const reply = (result) => { res.writeHead(200, { 'content-type': 'application/json' }); res.end(JSON.stringify({ ok: true, result })); };
      // служебные эндпоинты теста
      if (url === '/__push') { const u = { update_id: nextId++, ...body }; queue.push(u); flush(); return reply(true); }
      if (url === '/__sent') { return reply(sent); }
      if (url === '/__edits') { return reply(edits); }
      if (url === '/__reset') { sent.length = 0; edits.length = 0; return reply(true); }
      if (/^\/file\/bot[^/]*\/photos\/.+/.test(url)) { res.writeHead(200, { 'content-type': 'image/jpeg' }); return res.end(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0xff, 0xd9])); }
      const m = url.match(/^\/bot[^/]*\/(\w+)$/);
      if (!m) { res.writeHead(404); return res.end('{}'); }
      switch (m[1]) {
        case 'getMe': return reply({ id: 999, is_bot: true, username: 'TestTrackerBot' });
        case 'setMyCommands': return reply(true);
        case 'sendMessage': {
          if (body.reply_markup && body.reply_markup.inline_keyboard) {
            for (const row of body.reply_markup.inline_keyboard) for (const b of row) {
              if (b.url && /localhost|127\.0\.0\.1/.test(b.url) && process.env.MOCK_REJECT_LOCAL_BUTTON) {
                res.writeHead(200, { 'content-type': 'application/json' });
                return res.end(JSON.stringify({ ok: false, error_code: 400, description: 'Bad Request: wrong HTTP URL' }));
              }
            }
          }
          sent.push({ chat_id: body.chat_id, text: body.text, markup: body.reply_markup || null });
          return reply({ message_id: sent.length, chat: { id: body.chat_id } });
        }
        case 'getUserProfilePhotos':
          return reply(Number(body.user_id) === 111
            ? { total_count: 1, photos: [[{ file_id: 'F1', width: 160, height: 160 }]] }
            : { total_count: 0, photos: [] });
        case 'getFile': return reply({ file_id: body.file_id, file_path: 'photos/' + body.file_id + '.jpg' });
        case 'editMessageText': edits.push(body); return reply(true);
        case 'answerCallbackQuery': return reply(true);
        case 'getUpdates': {
          if (queue.length) { const out = queue.splice(0); return reply(out); }
          const timeout = Math.min((body.timeout || 1) * 1000, 1500);
          const w = { res, reply, timer: setTimeout(() => { const i = waiters.indexOf(w); if (i >= 0) waiters.splice(i, 1); reply([]); }, timeout) };
          waiters.push(w);
          return undefined;
        }
        default: return reply(true);
      }
    });
  });
  function flush() {
    while (waiters.length && queue.length) { const w = waiters.shift(); clearTimeout(w.timer); w.reply(queue.splice(0)); }
  }
  return new Promise((resolve) => server.listen(port, '127.0.0.1', () => resolve({ server })));
}

module.exports = { createMock };
if (require.main === module) createMock(Number(process.env.PORT) || 4010).then(() => console.log('mock telegram on', process.env.PORT || 4010));
