'use strict';
// Сквозной тест: поднимает имитацию Telegram + настоящий сервер и проверяет вход, API, план, бота, напоминания, таймеры.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
const { DatabaseSync } = require('node:sqlite');
const http = require('http');
const { createMock } = require('./mock-telegram');
const Sched = require('../public/sched');
const herzen = require('../server/herzen');
const T = require('../server/time');

const HERZ = 4312, MOCK = 4310, PORT = 4311, BASE = `http://127.0.0.1:${PORT}`, TG = `http://127.0.0.1:${MOCK}`;
const INVITE = 'sekret';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let passed = 0;
const ok = (name) => { passed++; console.log('  ✓', name); };

async function waitFor(fn, ms = 8000, label = '') {
  const t0 = Date.now();
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() - t0 > ms) throw new Error('timeout waiting for ' + label);
    await sleep(120);
  }
}
async function mock(pathname, body = {}) {
  const r = await fetch(TG + pathname, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return (await r.json()).result;
}
const sentTo = async (chat) => (await mock('/__sent')).filter((m) => String(m.chat_id) === String(chat));
const lastText = async (chat) => { const s = await sentTo(chat); return s.length ? s[s.length - 1].text : ''; };
async function say(user, text) {
  await mock('/__push', { message: { message_id: 1, from: { id: user, first_name: 'User' + user, username: 'u' + user }, chat: { id: user, type: 'private' }, text } });
}
async function api(cookie, method, p, body, extra = {}) {
  const headers = { ...(cookie ? { cookie } : {}), ...(body !== undefined ? { 'content-type': 'application/json' } : {}) };
  const r = await fetch(BASE + p, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, redirect: 'manual', ...extra });
  let data = null;
  try { data = await r.json(); } catch { /* пусто */ }
  return { status: r.status, data, headers: r.headers };
}
async function login(user) {
  const s = await api(null, 'POST', '/api/auth/start', {});
  assert.equal(s.status, 200);
  const code = s.data.code;
  const p1 = await api(null, 'GET', '/api/auth/poll?code=' + code);
  assert.equal(p1.data.pending, true);
  await say(user, '/start login_' + code);
  const res = await waitFor(async () => { const r = await api(null, 'GET', '/api/auth/poll?code=' + code); return r.data && r.data.ok ? r : null; }, 6000, 'login');
  const sc = res.headers.get('set-cookie');
  assert.ok(/HttpOnly/i.test(sc) && /SameSite=Lax/i.test(sc), 'cookie flags');
  return sc.split(';')[0];
}

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tracker-e2e-'));
  const dbPath = path.join(dir, 'e2e.db');
  const { server: mockServer } = await createMock(MOCK);
  // имитация сайта расписания вуза
  const fx = (f) => fs.readFileSync(path.join(__dirname, 'fixtures', f), 'utf8');
  const herzServer = http.createServer((req, res) => {
    const send = (code, body) => { res.writeHead(code, { 'content-type': 'text/html; charset=utf-8' }); res.end(body); };
    if (req.url === '/schedule') return send(200, fx('herzen-schedule.html'));
    if (req.url === '/schedule/24298/classes') return send(200, fx('herzen-classes.html'));
    if (req.url === '/schedule/24294/classes') return send(200, '<html><body><h3>понедельник</h3><p>пока пусто</p></body></html>');
    return send(404, 'no');
  });
  await new Promise((r) => herzServer.listen(HERZ, '127.0.0.1', r));
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server', 'index.js')], {
    env: { ...process.env, BOT_TOKEN: '123456:TEST', TG_API_BASE: TG, PORT: String(PORT), BASE_URL: BASE, DB_PATH: dbPath, INVITE_CODE: INVITE, TICK_MS: '400', DEFAULT_TZ: 'Europe/Moscow', JAVA_USERS: '@U111', HERZEN_BASE: `http://127.0.0.1:${HERZ}`, HERZEN_COOLDOWN_MS: '0' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let log = '';
  child.stdout.on('data', (d) => { log += d; });
  child.stderr.on('data', (d) => { log += d; });
  const cleanup = () => { child.kill('SIGTERM'); mockServer.close(); herzServer.close(); };

  try {
    await waitFor(async () => { try { return (await api(null, 'GET', '/api/health')).data.ok; } catch { return false; } }, 8000, 'server');
    await waitFor(async () => (await api(null, 'GET', '/api/auth/info')).data.bot, 8000, 'bot username');
    console.log('Сервер и бот запущены');
    ok('health + имя бота получено через getMe');

    /* --- защита --- */
    assert.equal((await api(null, 'GET', '/api/state')).status, 401); ok('без входа /api/state → 401');
    const nonJson = await fetch(BASE + '/api/auth/start', { method: 'POST', headers: { 'content-type': 'text/plain' }, body: 'x' });
    assert.equal(nonJson.status, 415); ok('POST без JSON content-type → 415 (защита от CSRF)');

    /* --- закрытый бот: инвайт --- */
    const s0 = await api(null, 'POST', '/api/auth/start', {});
    await say(111, '/start login_' + s0.data.code);
    await waitFor(async () => /закрытый/i.test(await lastText(111)), 5000, 'invite refusal');
    ok('новичок без кода приглашения получает отказ');
    await say(111, '/start ' + INVITE);
    await waitFor(async () => (await sentTo(111)).some((m) => /Привет/.test(m.text) && m.markup), 5000, 'welcome');
    ok('с кодом приглашения регистрируется, приходит приветствие с кнопкой входа');

    /* --- вход --- */
    const c1 = await login(111);
    ok('вход через бота (deep-link код → cookie)');
    const used = await api(null, 'GET', '/api/auth/poll?code=' + s0.data.code);
    assert.ok(used.status === 410 || used.data.pending, 'старый код не должен дать сессию');
    let st = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(st.settings.onboarded, false);
    assert.equal(st.settings.schedule.length, 5);
    assert.equal(st.tasks.length, 0);
    ok('состояние нового пользователя: расписание пар по умолчанию, задач нет');

    /* --- настройки и план --- */
    const today = st.today;
    const put = await api(c1, 'PUT', '/api/settings', { onboarded: true, tz: 'Europe/Moscow', plan: { topicTime: '19:00', repeatOn: true, repeatAfter: 5, repeatMin: 60, repeatTime: '20:00' } });
    assert.equal(put.status, 200);
    assert.equal((await api(c1, 'PUT', '/api/settings', { tz: 'Mars/Base' })).status, 400);
    const gen = await api(c1, 'POST', '/api/plan/generate', { startDate: today, fromDay: 1 });
    assert.equal(gen.status, 200);
    st = (await api(c1, 'GET', '/api/state')).data;
    const topics = st.tasks.filter((t) => t.planKind === 'topic'), reps = st.tasks.filter((t) => t.planKind === 'repeat');
    assert.equal(topics.length, 28); assert.equal(reps.length, 20);
    assert.ok(st.tasks.every((t) => t.cat === 'math'), 'только математика');
    assert.ok(!st.tasks.some((t) => /java/i.test(t.title + t.note)), 'Java в плане нет');
    const t0 = topics.find((t) => t.planIdx === 0), r0 = reps.find((t) => t.planIdx === 0);
    assert.equal(t0.date, today); assert.equal(t0.time, '19:00');
    assert.equal(r0.date, T.addDays(today, 5)); assert.equal(r0.time, '20:00'); assert.equal(r0.est, 60);
    assert.ok(!reps.some((t) => [6, 13, 20, 27].includes(t.planOff)), 'повторения не попадают на обзорные дни');
    ok('план: 28 тем по математике + 20 повторений через 5 дней (1 час, 20:00), без Java');

    /* --- бот: просмотр и отметки --- */
    await mock('/__reset');
    await say(111, '/today');
    const todayMsg = await waitFor(async () => { const t = await lastText(111); return /Математика: Высказывания/.test(t) && t; }, 5000, '/today');
    assert.ok(/Прогресс: 0\/1/.test(todayMsg));
    ok('/today показывает тему дня и прогресс');
    await say(111, '/done 1');
    await waitFor(async () => (await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.id === t0.id).done, 5000, '/done');
    ok('/done 1 отмечает задачу (видно через API)');
    const sentList = await sentTo(111);
    const kb = sentList[sentList.length - 1].markup;
    assert.ok(kb && kb.inline_keyboard[0][0].callback_data === 't:' + t0.id);
    await mock('/__push', { callback_query: { id: 'cb1', from: { id: 111 }, data: 't:' + t0.id, message: { message_id: 5, chat: { id: 111 } } } });
    await waitFor(async () => !(await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.id === t0.id).done, 5000, 'callback toggle');
    assert.ok((await mock('/__edits')).length >= 1);
    ok('инлайн-кнопка переключает выполнение и обновляет сообщение');

    await say(111, '/add завтра 18:30 решить пять задач');
    const added = await waitFor(async () => (await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.title === 'решить пять задач'), 5000, '/add');
    assert.equal(added.date, T.addDays(today, 1)); assert.equal(added.time, '18:30'); assert.deepEqual(added.remind, [15, 0]);
    ok('/add завтра 18:30 … создаёт задачу с напоминаниями по умолчанию');
    await say(111, '/add 19.30 без даты');
    const added2 = await waitFor(async () => (await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.title === 'без даты'), 5000, '/add 2');
    assert.equal(added2.date, today); assert.equal(added2.time, '19:30');
    ok('/add 19.30 текст — время без даты');

    for (const [cmd, re] of [['/week', /Ближайшие 7 дней/], ['/plan', /План по математике/], ['/stats', /Статистика/], ['/help', /Команды/], ['/tomorrow', /Завтра/]]) {
      await mock('/__reset'); await say(111, cmd);
      await waitFor(async () => re.test(await lastText(111)), 5000, cmd);
    }
    ok('/week /plan /stats /help /tomorrow отвечают');

    /* --- сдвиг плана --- */
    const sh = await api(c1, 'POST', '/api/plan/shift', {});
    assert.equal(sh.status, 200);
    st = (await api(c1, 'GET', '/api/state')).data;
    const pend = st.tasks.filter((t) => t.plan && !t.done).sort((a, b) => a.date.localeCompare(b.date));
    assert.equal(pend[0].date, today);
    ok('«сдвинуть с сегодня»: ближайшая невыполненная тема переносится на сегодня');

    /* --- напоминания --- */
    const nowMs = Date.now();
    const in10 = T.localToMs(T.dateKey(nowMs, 'Europe/Moscow'), T.hhmm(nowMs + 10 * 60000, 'Europe/Moscow'), 'Europe/Moscow');
    const dateIn10 = T.dateKey(nowMs + 10 * 60000, 'Europe/Moscow');
    await mock('/__reset');
    const rem = await api(c1, 'POST', '/api/tasks', { title: 'Скоро начало', date: dateIn10, time: T.hhmm(in10, 'Europe/Moscow'), type: 'task', cat: 'math', remind: [15, 0] });
    assert.equal(rem.status, 201);
    await waitFor(async () => /Напоминание — через \d+ мин[\s\S]*Скоро начало/.test(await lastText(111)), 6000, 'reminder');
    ok('серверное напоминание «за 15 минут» пришло в Telegram без открытого сайта');
    const n1 = (await sentTo(111)).filter((m) => /Скоро начало/.test(m.text)).length;
    await sleep(1500);
    assert.equal((await sentTo(111)).filter((m) => /Скоро начало/.test(m.text)).length, n1, 'повторов нет');
    ok('напоминание не дублируется');
    const in20 = nowMs + 20 * 60000;
    await api(c1, 'POST', '/api/tasks', { title: 'Рано ещё', date: T.dateKey(in20, 'Europe/Moscow'), time: T.hhmm(in20, 'Europe/Moscow'), type: 'task', cat: 'math', remind: [15] });
    await sleep(1500);
    assert.ok(!(await sentTo(111)).some((m) => /Рано ещё/.test(m.text)));
    ok('напоминание за 15 минут к задаче через 20 минут пока не отправляется');

    /* --- таймеры --- */
    await mock('/__reset');
    const before = (await api(c1, 'GET', '/api/state')).data.study;
    const wt = await api(c1, 'PUT', '/api/timer', { phase: 'work', mode: 'Pomodoro 25/5', workMin: 25, breakMin: 5, taskId: t0.id, endsAt: Date.now() + 1200 });
    assert.equal(wt.status, 200);
    await waitFor(async () => /Таймер завершён[\s\S]*Pomodoro[\s\S]*Математика: Высказывания/.test(await lastText(111)), 6000, 'web timer');
    const after = (await api(c1, 'GET', '/api/state')).data.study;
    assert.deepEqual(after, before);
    ok('таймер с сайта: уведомление придёт даже если вкладку закрыли (учёт времени остаётся за сайтом)');

    await api(c1, 'POST', '/api/log', { ms: 90000, taskId: t0.id, pomo: 1 });
    const lg = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(lg.study[today].ms, 90000); assert.equal(lg.study[today].pomos, 1);
    assert.equal(lg.tasks.find((t) => t.id === t0.id).spentMs, 90000);
    ok('/api/log копит время за день и по задаче');

    await mock('/__reset');
    await say(111, '/pomo 1 1');
    await waitFor(async () => /Таймер запущен/.test(await lastText(111)), 5000, '/pomo');
    const raw = new DatabaseSync(dbPath);
    raw.exec('PRAGMA busy_timeout=5000');
    raw.prepare("UPDATE timers SET ends_at=? WHERE kind='bot'").run(Date.now() - 500);
    await waitFor(async () => /Таймер завершён/.test(await lastText(111)), 6000, 'bot timer end');
    const lg2 = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(lg2.study[today].ms, 90000 + 60000); assert.equal(lg2.study[today].pomos, 2);
    raw.prepare("UPDATE timers SET ends_at=? WHERE kind='bot'").run(Date.now() - 500);
    await waitFor(async () => /Перерыв закончился/.test(await lastText(111)), 6000, 'break end');
    ok('/pomo: таймер из бота сам считает время и помидоры, затем уведомляет о конце перерыва');
    raw.close();

    /* --- утренняя сводка --- */
    await mock('/__reset');
    const nowMsk = T.parts(Date.now(), 'Europe/Moscow');
    if (nowMsk.h * 60 + nowMsk.mi >= 5) {
      await api(c1, 'PUT', '/api/settings', { digest: true, digestTime: T.hhmm(Date.now() - 3 * 60000, 'Europe/Moscow') });
      await waitFor(async () => /Доброе утро/.test(await lastText(111)), 6000, 'digest');
      const nd = (await sentTo(111)).filter((m) => /Доброе утро/.test(m.text)).length;
      await sleep(1200);
      assert.equal((await sentTo(111)).filter((m) => /Доброе утро/.test(m.text)).length, nd);
      ok('утренняя сводка приходит один раз в день');
    }

    /* --- /notify off --- */
    await say(111, '/notify off');
    await waitFor(async () => /выключены/.test(await lastText(111)), 5000, '/notify off');
    await mock('/__reset');
    const in5 = Date.now() + 5 * 60000;
    await api(c1, 'POST', '/api/tasks', { title: 'Тишина', date: T.dateKey(in5, 'Europe/Moscow'), time: T.hhmm(in5, 'Europe/Moscow'), type: 'task', cat: 'other', remind: [15, 0] });
    await sleep(1800);
    assert.ok(!(await sentTo(111)).some((m) => /Тишина/.test(m.text)));
    ok('/notify off отключает все push-сообщения');
    await say(111, '/notify on');
    await waitFor(async () => (await sentTo(111)).some((m) => /Напоминания включены/.test(m.text)), 5000, '/notify on'); // ответ может идти вперемешку с вдруг разрешённым напоминанием

    /* --- ссылка входа из бота --- */
    await mock('/__reset');
    await say(111, '/site');
    const siteMsg = await waitFor(async () => (await sentTo(111)).find((m) => m.markup && m.markup.inline_keyboard[0][0].url), 5000, '/site');
    const magic = siteMsg.markup.inline_keyboard[0][0].url;
    const m1 = await fetch(magic, { redirect: 'manual' });
    assert.equal(m1.status, 302); assert.ok(/sid=/.test(m1.headers.get('set-cookie')));
    const m2 = await fetch(magic, { redirect: 'manual' });
    assert.ok(/expired/.test(m2.headers.get('location')));
    ok('одноразовая ссылка из бота: первый раз входит, повторно не работает');
    process.env.MOCK_REJECT_LOCAL_BUTTON = '1';
    await mock('/__reset');
    await say(111, '/site');
    await waitFor(async () => (await sentTo(111)).some((m) => !m.markup && /\/auth\//.test(m.text)), 5000, 'fallback link');
    delete process.env.MOCK_REJECT_LOCAL_BUTTON;
    ok('если Telegram отклоняет кнопку-ссылку, бот присылает ссылку обычным текстом');

    /* --- изоляция пользователей --- */
    await say(222, '/start ' + INVITE);
    await waitFor(async () => (await sentTo(222)).length > 0, 5000, 'user2 welcome');
    const c2 = await login(222);
    const st2 = (await api(c2, 'GET', '/api/state')).data;
    assert.equal(st2.tasks.length, 0);
    assert.equal((await api(c2, 'PATCH', '/api/tasks/' + t0.id, { done: true })).status, 404);
    assert.equal((await api(c2, 'DELETE', '/api/tasks/' + t0.id)).status, 404);
    ok('данные пользователей изолированы (чужие задачи не читаются и не меняются)');

    /* --- Java-трек: только для пользователей из JAVA_USERS --- */
    assert.equal(st2.features.java, false);
    assert.equal((await api(c2, 'POST', '/api/plan/generate', { startDate: today, fromDay: 1, track: 'java' })).status, 403);
    assert.equal((await api(c2, 'POST', '/api/plan/shift', { track: 'java' })).status, 403);
    assert.equal((await api(c2, 'GET', '/api/state')).data.javaPlan, undefined);
    ok('Java-трек недоступен остальным пользователям (403, в состоянии нет следов)');

    const mathBefore = (await api(c1, 'GET', '/api/state')).data.tasks.filter((t) => t.plan && t.track === 'math').length;
    assert.equal((await api(c1, 'GET', '/api/state')).data.features.java, true);
    const jg = await api(c1, 'POST', '/api/plan/generate', { startDate: today, fromDay: 1, track: 'java' });
    assert.equal(jg.status, 200);
    assert.equal(jg.data.count, 28);                       // повторения по умолчанию выключены
    const stj = (await api(c1, 'GET', '/api/state')).data;
    const jt = stj.tasks.filter((t) => t.plan && t.track === 'java');
    assert.equal(jt.length, 28);
    assert.ok(jt.every((t) => t.cat === 'java' && t.title.startsWith('Java: ') && t.time === '21:00'));
    assert.equal(stj.tasks.filter((t) => t.plan && t.track === 'math').length, mathBefore);
    ok('Java-план создаётся отдельно: 28 тем, категория java, математика не тронута');

    await api(c1, 'PUT', '/api/settings', { java: { repeatOn: true, repeatAfter: 5, topicTime: '20:30' } });
    const jg2 = await api(c1, 'POST', '/api/plan/generate', { startDate: today, fromDay: 1, track: 'java' });
    assert.equal(jg2.data.count, 28 + 20);
    const stj2 = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(stj2.tasks.filter((t) => t.plan && t.track === 'java').length, 48);
    assert.equal(stj2.tasks.filter((t) => t.plan && t.track === 'math').length, mathBefore);
    ok('перегенерация Java-плана заменяет только Java, повторения через 5 дней, время настраивается');

    const sh2 = await api(c1, 'POST', '/api/plan/shift', { track: 'java' });
    assert.equal(sh2.status, 200);
    assert.equal((await api(c1, 'POST', '/api/plan/shift', {})).status, 200);
    await say(111, '/plan');
    await waitFor(async () => /План по Java/.test(await lastText(111)) || /План по Java/.test((await sentTo(111)).map((m) => m.text).join('\n')), 4000, '/plan java');
    ok('сдвиг по треку и /plan в боте показывает оба плана');

    /* --- расписание пар: разбор страницы вуза --- */
    const parsed = herzen.parseClasses(fx('herzen-classes.html'));
    assert.equal(parsed.length, 4);
    const p0 = parsed[0];
    assert.deepEqual([p0.dow, p0.start, p0.end, p0.title, p0.kind], [1, '09:40', '11:10', 'Английский язык', 'практ']);
    assert.equal(p0.room, 'ауд. 209, корпус 1 (Мойка 48)');
    assert.equal(p0.teacher, 'доц. Иванова А. П.');
    assert.deepEqual(p0.ranges, [['09-07', '09-28'], ['11-02', '12-07']]);
    assert.equal(parsed[1].room, 'Видеолекция; дистанционное обучение');
    assert.equal(parsed[1].teacher, 'проф. Петров Сергей Николаевич');
    assert.deepEqual([parsed[2].week, parsed[3].week], ['В', 'Н']);
    assert.deepEqual(herzen.parseGroups(fx('herzen-schedule.html')).map((g) => g.id), ['24298', '24294']);
    ok('парсер расписания вуза: время, предмет, тип, преподаватель, аудитория, даты, недели В/Н');

    const cfgS = { topWeek: '2026-09-01', schedule: [
      { dow: 1, start: '09:40', end: '11:10', title: 'А', ranges: [['09-07', '09-28']] },
      { dow: 1, start: '12:00', end: '13:30', title: 'Б', week: 'Н' },
      { dow: 1, start: '14:00', end: '15:30', title: 'В', week: 'В' }] };
    assert.deepEqual(Sched.classesOn(cfgS, '2026-09-14').map((c) => c.title), ['А', 'В']);   // понедельник верхней недели, в диапазоне
    assert.deepEqual(Sched.classesOn(cfgS, '2026-09-21').map((c) => c.title), ['А', 'Б']);   // нижняя неделя
    assert.deepEqual(Sched.classesOn(cfgS, '2026-10-12').map((c) => c.title), ['В']);        // вне диапазона дат
    ok('какие пары идут в дату: диапазоны дат из примечаний и верхняя/нижняя неделя');

    const grp = await api(c1, 'GET', '/api/herzen/groups?q=' + encodeURIComponent('пми'));
    assert.equal(grp.status, 200); assert.deepEqual(grp.data.groups.map((g) => g.id), ['24298']);
    const cls = await api(c1, 'POST', '/api/herzen/classes', { groupId: '24298' });
    assert.equal(cls.status, 200); assert.equal(cls.data.schedule.length, 4); assert.ok(/^\d{4}-09-01$/.test(cls.data.topWeek));
    assert.equal((await api(c1, 'POST', '/api/herzen/classes', { groupId: '../etc' })).status, 400);
    assert.equal((await api(c1, 'POST', '/api/herzen/classes', { groupId: '24294' })).status, 422);   // пустая страница
    assert.equal((await api(c1, 'POST', '/api/herzen/classes', { groupId: '99999' })).status, 502);   // сайт ответил 404
    assert.equal((await api(null, 'GET', '/api/herzen/groups?q=пми')).status, 401);
    ok('API расписания: поиск группы, загрузка без сохранения, защита от чужих адресов и пустых страниц');

    // сохранить загруженное расписание, пара «сегодня» с аудиторией и преподавателем попадает в бота
    const dowToday = new Date(today + 'T12:00:00Z').getUTCDay();
    const saved = await api(c1, 'PUT', '/api/settings', { topWeek: today, schedule: [{ id: 'h0', dow: dowToday, start: '09:40', end: '11:10', title: 'Матан', room: 'ауд. 777', teacher: 'доц. Тестов Т. Т.', kind: 'лекц', week: 'В', ranges: [] }] });
    assert.equal(saved.status, 200); assert.equal(saved.data.settings.schedule[0].room, 'ауд. 777');
    await mock('/__reset'); await say(111, '/today');
    await waitFor(async () => /ауд\. 777/.test(await lastText(111)) && /Тестов/.test(await lastText(111)), 4000, '/today with class details');
    ok('пары с аудиторией и преподавателем показываются в боте');

    /* --- импорт плана из JSON --- */
    const doc = { title: 'T', startDate: today, tasks: [
      { day: 1, time: '19:00', title: 'Импорт 1', type: 'lesson', cat: 'math', est: 30, remind: [15] },
      { day: 2, title: 'Импорт 2', cat: 'java' },
      { date: today, time: '20:30', title: 'Импорт 3', type: 'note' },
      { day: 3, title: '' },
      { date: '2026-02-30', title: 'Плохая дата' },
      'мусор'] };
    const imp = await api(c2, 'POST', '/api/plan/import', { doc });
    assert.equal(imp.status, 200); assert.equal(imp.data.added, 3); assert.equal(imp.data.errorCount, 3);
    const st2i = (await api(c2, 'GET', '/api/state')).data.tasks.filter((t) => /^Импорт/.test(t.title));
    assert.equal(st2i.length, 3);
    assert.equal(st2i.find((t) => t.title === 'Импорт 2').cat, 'study');          // java недоступна пользователю 222 → «учёба»
    assert.equal(st2i.find((t) => t.title === 'Импорт 1').date, today);
    assert.deepEqual(st2i.find((t) => t.title === 'Импорт 1').remind, [15]);
    const imp2 = await api(c2, 'POST', '/api/plan/import', { doc });
    assert.equal(imp2.data.added, 0); assert.equal(imp2.data.skipped, 3);               // повторная загрузка без дублей
    assert.equal((await api(c2, 'POST', '/api/plan/import', { doc: { nothing: 1 } })).status, 400);
    assert.equal((await api(c2, 'POST', '/api/plan/import', { doc: { tasks: new Array(1001).fill({ day: 1, title: 'x' }) } })).status, 400);
    assert.equal((await api(c2, 'POST', '/api/plan/import', { doc, startDate: 'вчера' })).status, 400);
    ok('импорт плана из JSON: day/date, пропуск ошибочных, без дублей, лимиты, java недоступна другим');

    /* --- рейтинг --- */
    assert.equal((await api(null, 'GET', '/api/rating')).status, 401);
    const empty = (await api(c1, 'GET', '/api/rating?scope=week')).data;
    assert.equal(empty.entries.length, 0); assert.equal(empty.me.on, false);
    const base1 = Math.round((((await api(c1, 'GET', '/api/state')).data.study[today] || {}).ms || 0) / 60000);   // минуты, накопленные прошлыми проверками
    const base2 = Math.round((((await api(c2, 'GET', '/api/state')).data.study[today] || {}).ms || 0) / 60000);
    await api(c1, 'POST', '/api/log', { ms: 90 * 60000 });
    await api(c2, 'POST', '/api/log', { ms: 30 * 60000 });
    await api(c1, 'PUT', '/api/settings', { rating: { on: true, nick: '', photo: true } });
    await api(c2, 'PUT', '/api/settings', { rating: { on: true, nick: 'Ник2', photo: false } });
    const rb = (await api(c1, 'GET', '/api/rating?scope=week')).data;
    assert.deepEqual(rb.entries.map((e) => [e.rank, e.name, e.xp]), [[1, '@u111', 90 + base1], [2, 'Ник2', 30 + base2]]);
    assert.equal(rb.me.rank, 1); assert.equal(rb.entries[0].me, true);
    const rawBoard = JSON.stringify(rb);
    assert.ok(!/User111|User222|1153|"tgId"|"id"/.test(rawBoard), 'в рейтинге нет лишних данных');
    ok('рейтинг: только вступившие, очки за минуты, места, ник вместо имени, без лишних данных');

    const av = await fetch(BASE + '/api/avatar/' + rb.entries[0].pid, { headers: { cookie: c1 } });
    assert.equal(av.status, 200); assert.equal(av.headers.get('content-type'), 'image/jpeg');
    assert.equal((await av.arrayBuffer()).byteLength, 12);
    assert.equal((await fetch(BASE + '/api/avatar/' + rb.entries[1].pid, { headers: { cookie: c1 } })).status, 404);   // фото скрыто
    assert.equal((await fetch(BASE + '/api/avatar/zzzz', { headers: { cookie: c1 } })).status, 404);
    assert.equal((await fetch(BASE + '/api/avatar/' + rb.entries[0].pid)).status, 401);
    await api(c2, 'PUT', '/api/settings', { rating: { on: false } });
    assert.equal((await api(c1, 'GET', '/api/rating')).data.entries.length, 1);
    ok('аватар из Telegram: отдаётся только вступившим с включённым фото и только вошедшим на сайт');

    /* --- очистка календаря --- */
    assert.equal((await api(c1, 'POST', '/api/clear', {})).status, 400);                  // без подтверждения
    const beforeC = (await api(c1, 'GET', '/api/state')).data;
    assert.ok(beforeC.tasks.length > 50 && Object.keys(beforeC.study).length > 0);
    const clr = await api(c1, 'POST', '/api/clear', { confirm: true });
    assert.equal(clr.status, 200); assert.equal(clr.data.tasks, beforeC.tasks.length);
    const afterC = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(afterC.tasks.length, 0);                                                  // и обычные задачи, и оба плана
    assert.ok(Object.keys(afterC.study).length > 0 && afterC.settings.schedule.length === 1);   // статистика и пары остались
    await api(c1, 'POST', '/api/clear', { confirm: true, tasks: false, stats: true, schedule: true });
    const afterC2 = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(Object.keys(afterC2.study).length, 0); assert.equal(afterC2.settings.schedule.length, 0);
    assert.equal(afterC2.javaPlan, null);
    ok('очистка: нужен confirm, удаляет все задачи и планы; статистика и пары — только по выбору');

    /* --- валидация --- */
    assert.equal((await api(c1, 'POST', '/api/tasks', { title: '', date: today })).status, 400);
    assert.equal((await api(c1, 'POST', '/api/tasks', { title: 'x', date: '2026-13-40' })).status, 400);
    assert.equal((await api(c1, 'PUT', '/api/timer', { phase: 'work', endsAt: 1 })).status, 400);
    ok('валидация входных данных');

    /* --- статика --- */
    if (fs.existsSync(path.join(__dirname, '..', 'public', 'index.html'))) {
      const idx = await fetch(BASE + '/');
      assert.equal(idx.status, 200); assert.ok(/text\/html/.test(idx.headers.get('content-type')));
      assert.ok(/default-src 'self'/.test(idx.headers.get('content-security-policy')));
      assert.equal((await fetch(BASE + '/..%2fserver%2fconfig.js')).status === 200, false);
      assert.equal((await fetch(BASE + '/%2e%2e/package.json')).status === 200, false);
      ok('сайт отдаётся с CSP; выход за пределы public/ закрыт');
    }

    /* --- удаление аккаунта --- */
    assert.equal((await api(c2, 'DELETE', '/api/account')).status, 200);
    assert.equal((await api(c2, 'GET', '/api/state')).status, 401);
    ok('удаление аккаунта убирает данные и сессию');

    console.log(`\nВсе проверки пройдены: ${passed}`);
    cleanup();
    process.exit(0);
  } catch (e) {
    console.error('\n✗ ПРОВАЛ:', e.message);
    console.error(e.stack.split('\n').slice(0, 4).join('\n'));
    console.error('--- лог сервера ---\n' + log.slice(-2500));
    cleanup();
    process.exit(1);
  }
})();
