'use strict';
// Сквозной тест: поднимает имитацию Telegram + настоящий сервер и проверяет вход, API, план, бота, напоминания, таймеры.
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
const { DatabaseSync } = require('node:sqlite');
const { createMock } = require('./mock-telegram');
const T = require('../server/time');

const MOCK = 4310, PORT = 4311, BASE = `http://127.0.0.1:${PORT}`, TG = `http://127.0.0.1:${MOCK}`;
const INVITE = 'sekret';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
let passed = 0;
const ok = (name) => { passed++; console.log('  ✓', name); };

async function waitFor(fn, ms = 8000, label = '') {
  const t0 = Date.now();
  for (;;) {
    const v = await fn();
    if (v) return v;
    if (Date.now() - t0 > ms) throw new Error('timeout waiting for ' + label);
    await sleep(120);
  }
}
async function mock(pathname, body = {}) {
  const r = await fetch(TG + pathname, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  return (await r.json()).result;
}
const sentTo = async (chat) => (await mock('/__sent')).filter((m) => String(m.chat_id) === String(chat));
const lastText = async (chat) => { const s = await sentTo(chat); return s.length ? s[s.length - 1].text : ''; };
async function say(user, text) {
  await mock('/__push', { message: { message_id: 1, from: { id: user, first_name: 'User' + user, username: 'u' + user }, chat: { id: user, type: 'private' }, text } });
}
async function api(cookie, method, p, body, extra = {}) {
  const headers = { ...(cookie ? { cookie } : {}), ...(body !== undefined ? { 'content-type': 'application/json' } : {}) };
  const r = await fetch(BASE + p, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined, redirect: 'manual', ...extra });
  let data = null;
  try { data = await r.json(); } catch { /* пусто */ }
  return { status: r.status, data, headers: r.headers };
}
async function login(user) {
  const s = await api(null, 'POST', '/api/auth/start', {});
  assert.equal(s.status, 200);
  const code = s.data.code;
  const p1 = await api(null, 'GET', '/api/auth/poll?code=' + code);
  assert.equal(p1.data.pending, true);
  await say(user, '/start login_' + code);
  const res = await waitFor(async () => { const r = await api(null, 'GET', '/api/auth/poll?code=' + code); return r.data && r.data.ok ? r : null; }, 6000, 'login');
  const sc = res.headers.get('set-cookie');
  assert.ok(/HttpOnly/i.test(sc) && /SameSite=Lax/i.test(sc), 'cookie flags');
  return sc.split(';')[0];
}

(async () => {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'tracker-e2e-'));
  const dbPath = path.join(dir, 'e2e.db');
  const { server: mockServer } = await createMock(MOCK);
  const child = spawn(process.execPath, [path.join(__dirname, '..', 'server', 'index.js')], {
    env: { ...process.env, BOT_TOKEN: '123456:TEST', TG_API_BASE: TG, PORT: String(PORT), BASE_URL: BASE, DB_PATH: dbPath, INVITE_CODE: INVITE, TICK_MS: '400', DEFAULT_TZ: 'Europe/Moscow' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let log = '';
  child.stdout.on('data', (d) => { log += d; });
  child.stderr.on('data', (d) => { log += d; });
  const cleanup = () => { child.kill('SIGTERM'); mockServer.close(); };

  try {
    await waitFor(async () => { try { return (await api(null, 'GET', '/api/health')).data.ok; } catch { return false; } }, 8000, 'server');
    await waitFor(async () => (await api(null, 'GET', '/api/auth/info')).data.bot, 8000, 'bot username');
    console.log('Сервер и бот запущены');
    ok('health + имя бота получено через getMe');

    /* --- защита --- */
    assert.equal((await api(null, 'GET', '/api/state')).status, 401); ok('без входа /api/state → 401');
    const nonJson = await fetch(BASE + '/api/auth/start', { method: 'POST', headers: { 'content-type': 'text/plain' }, body: 'x' });
    assert.equal(nonJson.status, 415); ok('POST без JSON content-type → 415 (защита от CSRF)');

    /* --- закрытый бот: инвайт --- */
    const s0 = await api(null, 'POST', '/api/auth/start', {});
    await say(111, '/start login_' + s0.data.code);
    await waitFor(async () => /закрытый/i.test(await lastText(111)), 5000, 'invite refusal');
    ok('новичок без кода приглашения получает отказ');
    await say(111, '/start ' + INVITE);
    await waitFor(async () => (await sentTo(111)).some((m) => /Привет/.test(m.text) && m.markup), 5000, 'welcome');
    ok('с кодом приглашения регистрируется, приходит приветствие с кнопкой входа');

    /* --- вход --- */
    const c1 = await login(111);
    ok('вход через бота (deep-link код → cookie)');
    const used = await api(null, 'GET', '/api/auth/poll?code=' + s0.data.code);
    assert.ok(used.status === 410 || used.data.pending, 'старый код не должен дать сессию');
    let st = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(st.settings.onboarded, false);
    assert.equal(st.settings.schedule.length, 5);
    assert.equal(st.tasks.length, 0);
    ok('состояние нового пользователя: расписание пар по умолчанию, задач нет');

    /* --- настройки и план --- */
    const today = st.today;
    const put = await api(c1, 'PUT', '/api/settings', { onboarded: true, tz: 'Europe/Moscow', plan: { topicTime: '19:00', repeatOn: true, repeatAfter: 5, repeatMin: 60, repeatTime: '20:00' } });
    assert.equal(put.status, 200);
    assert.equal((await api(c1, 'PUT', '/api/settings', { tz: 'Mars/Base' })).status, 400);
    const gen = await api(c1, 'POST', '/api/plan/generate', { startDate: today, fromDay: 1 });
    assert.equal(gen.status, 200);
    st = (await api(c1, 'GET', '/api/state')).data;
    const topics = st.tasks.filter((t) => t.planKind === 'topic'), reps = st.tasks.filter((t) => t.planKind === 'repeat');
    assert.equal(topics.length, 28); assert.equal(reps.length, 20);
    assert.ok(st.tasks.every((t) => t.cat === 'math'), 'только математика');
    assert.ok(!st.tasks.some((t) => /java/i.test(t.title + t.note)), 'Java в плане нет');
    const t0 = topics.find((t) => t.planIdx === 0), r0 = reps.find((t) => t.planIdx === 0);
    assert.equal(t0.date, today); assert.equal(t0.time, '19:00');
    assert.equal(r0.date, T.addDays(today, 5)); assert.equal(r0.time, '20:00'); assert.equal(r0.est, 60);
    assert.ok(!reps.some((t) => [6, 13, 20, 27].includes(t.planOff)), 'повторения не попадают на обзорные дни');
    ok('план: 28 тем по математике + 20 повторений через 5 дней (1 час, 20:00), без Java');

    /* --- бот: просмотр и отметки --- */
    await mock('/__reset');
    await say(111, '/today');
    const todayMsg = await waitFor(async () => { const t = await lastText(111); return /Математика: Высказывания/.test(t) && t; }, 5000, '/today');
    assert.ok(/Прогресс: 0\/1/.test(todayMsg));
    ok('/today показывает тему дня и прогресс');
    await say(111, '/done 1');
    await waitFor(async () => (await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.id === t0.id).done, 5000, '/done');
    ok('/done 1 отмечает задачу (видно через API)');
    const sentList = await sentTo(111);
    const kb = sentList[sentList.length - 1].markup;
    assert.ok(kb && kb.inline_keyboard[0][0].callback_data === 't:' + t0.id);
    await mock('/__push', { callback_query: { id: 'cb1', from: { id: 111 }, data: 't:' + t0.id, message: { message_id: 5, chat: { id: 111 } } } });
    await waitFor(async () => !(await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.id === t0.id).done, 5000, 'callback toggle');
    assert.ok((await mock('/__edits')).length >= 1);
    ok('инлайн-кнопка переключает выполнение и обновляет сообщение');

    await say(111, '/add завтра 18:30 решить пять задач');
    const added = await waitFor(async () => (await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.title === 'решить пять задач'), 5000, '/add');
    assert.equal(added.date, T.addDays(today, 1)); assert.equal(added.time, '18:30'); assert.deepEqual(added.remind, [15, 0]);
    ok('/add завтра 18:30 … создаёт задачу с напоминаниями по умолчанию');
    await say(111, '/add 19.30 без даты');
    const added2 = await waitFor(async () => (await api(c1, 'GET', '/api/state')).data.tasks.find((t) => t.title === 'без даты'), 5000, '/add 2');
    assert.equal(added2.date, today); assert.equal(added2.time, '19:30');
    ok('/add 19.30 текст — время без даты');

    for (const [cmd, re] of [['/week', /Ближайшие 7 дней/], ['/plan', /План по математике/], ['/stats', /Статистика/], ['/help', /Команды/], ['/tomorrow', /Завтра/]]) {
      await mock('/__reset'); await say(111, cmd);
      await waitFor(async () => re.test(await lastText(111)), 5000, cmd);
    }
    ok('/week /plan /stats /help /tomorrow отвечают');

    /* --- сдвиг плана --- */
    const sh = await api(c1, 'POST', '/api/plan/shift', {});
    assert.equal(sh.status, 200);
    st = (await api(c1, 'GET', '/api/state')).data;
    const pend = st.tasks.filter((t) => t.plan && !t.done).sort((a, b) => a.date.localeCompare(b.date));
    assert.equal(pend[0].date, today);
    ok('«сдвинуть с сегодня»: ближайшая невыполненная тема переносится на сегодня');

    /* --- напоминания --- */
    const nowMs = Date.now();
    const in10 = T.localToMs(T.dateKey(nowMs, 'Europe/Moscow'), T.hhmm(nowMs + 10 * 60000, 'Europe/Moscow'), 'Europe/Moscow');
    const dateIn10 = T.dateKey(nowMs + 10 * 60000, 'Europe/Moscow');
    await mock('/__reset');
    const rem = await api(c1, 'POST', '/api/tasks', { title: 'Скоро начало', date: dateIn10, time: T.hhmm(in10, 'Europe/Moscow'), type: 'task', cat: 'math', remind: [15, 0] });
    assert.equal(rem.status, 201);
    await waitFor(async () => /Напоминание — через \d+ мин[\s\S]*Скоро начало/.test(await lastText(111)), 6000, 'reminder');
    ok('серверное напоминание «за 15 минут» пришло в Telegram без открытого сайта');
    const n1 = (await sentTo(111)).filter((m) => /Скоро начало/.test(m.text)).length;
    await sleep(1500);
    assert.equal((await sentTo(111)).filter((m) => /Скоро начало/.test(m.text)).length, n1, 'повторов нет');
    ok('напоминание не дублируется');
    const in20 = nowMs + 20 * 60000;
    await api(c1, 'POST', '/api/tasks', { title: 'Рано ещё', date: T.dateKey(in20, 'Europe/Moscow'), time: T.hhmm(in20, 'Europe/Moscow'), type: 'task', cat: 'math', remind: [15] });
    await sleep(1500);
    assert.ok(!(await sentTo(111)).some((m) => /Рано ещё/.test(m.text)));
    ok('напоминание за 15 минут к задаче через 20 минут пока не отправляется');

    /* --- таймеры --- */
    await mock('/__reset');
    const before = (await api(c1, 'GET', '/api/state')).data.study;
    const wt = await api(c1, 'PUT', '/api/timer', { phase: 'work', mode: 'Pomodoro 25/5', workMin: 25, breakMin: 5, taskId: t0.id, endsAt: Date.now() + 1200 });
    assert.equal(wt.status, 200);
    await waitFor(async () => /Таймер завершён[\s\S]*Pomodoro[\s\S]*Математика: Высказывания/.test(await lastText(111)), 6000, 'web timer');
    const after = (await api(c1, 'GET', '/api/state')).data.study;
    assert.deepEqual(after, before);
    ok('таймер с сайта: уведомление придёт даже если вкладку закрыли (учёт времени остаётся за сайтом)');

    await api(c1, 'POST', '/api/log', { ms: 90000, taskId: t0.id, pomo: 1 });
    const lg = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(lg.study[today].ms, 90000); assert.equal(lg.study[today].pomos, 1);
    assert.equal(lg.tasks.find((t) => t.id === t0.id).spentMs, 90000);
    ok('/api/log копит время за день и по задаче');

    await mock('/__reset');
    await say(111, '/pomo 1 1');
    await waitFor(async () => /Таймер запущен/.test(await lastText(111)), 5000, '/pomo');
    const raw = new DatabaseSync(dbPath);
    raw.exec('PRAGMA busy_timeout=5000');
    raw.prepare("UPDATE timers SET ends_at=? WHERE kind='bot'").run(Date.now() - 500);
    await waitFor(async () => /Таймер завершён/.test(await lastText(111)), 6000, 'bot timer end');
    const lg2 = (await api(c1, 'GET', '/api/state')).data;
    assert.equal(lg2.study[today].ms, 90000 + 60000); assert.equal(lg2.study[today].pomos, 2);
    raw.prepare("UPDATE timers SET ends_at=? WHERE kind='bot'").run(Date.now() - 500);
    await waitFor(async () => /Перерыв закончился/.test(await lastText(111)), 6000, 'break end');
    ok('/pomo: таймер из бота сам считает время и помидоры, затем уведомляет о конце перерыва');
    raw.close();

    /* --- утренняя сводка --- */
    await mock('/__reset');
    const nowMsk = T.parts(Date.now(), 'Europe/Moscow');
    if (nowMsk.h * 60 + nowMsk.mi >= 5) {
      await api(c1, 'PUT', '/api/settings', { digest: true, digestTime: T.hhmm(Date.now() - 3 * 60000, 'Europe/Moscow') });
      await waitFor(async () => /Доброе утро/.test(await lastText(111)), 6000, 'digest');
      const nd = (await sentTo(111)).filter((m) => /Доброе утро/.test(m.text)).length;
      await sleep(1200);
      assert.equal((await sentTo(111)).filter((m) => /Доброе утро/.test(m.text)).length, nd);
      ok('утренняя сводка приходит один раз в день');
    }

    /* --- /notify off --- */
    await say(111, '/notify off');
    await waitFor(async () => /выключены/.test(await lastText(111)), 5000, '/notify off');
    await mock('/__reset');
    const in5 = Date.now() + 5 * 60000;
    await api(c1, 'POST', '/api/tasks', { title: 'Тишина', date: T.dateKey(in5, 'Europe/Moscow'), time: T.hhmm(in5, 'Europe/Moscow'), type: 'task', cat: 'other', remind: [15, 0] });
    await sleep(1800);
    assert.ok(!(await sentTo(111)).some((m) => /Тишина/.test(m.text)));
    ok('/notify off отключает все push-сообщения');
    await say(111, '/notify on');
    await waitFor(async () => /включены/.test(await lastText(111)), 5000, '/notify on');

    /* --- ссылка входа из бота --- */
    await mock('/__reset');
    await say(111, '/site');
    const siteMsg = await waitFor(async () => (await sentTo(111)).find((m) => m.markup && m.markup.inline_keyboard[0][0].url), 5000, '/site');
    const magic = siteMsg.markup.inline_keyboard[0][0].url;
    const m1 = await fetch(magic, { redirect: 'manual' });
    assert.equal(m1.status, 302); assert.ok(/sid=/.test(m1.headers.get('set-cookie')));
    const m2 = await fetch(magic, { redirect: 'manual' });
    assert.ok(/expired/.test(m2.headers.get('location')));
    ok('одноразовая ссылка из бота: первый раз входит, повторно не работает');
    process.env.MOCK_REJECT_LOCAL_BUTTON = '1';
    await mock('/__reset');
    await say(111, '/site');
    await waitFor(async () => (await sentTo(111)).some((m) => !m.markup && /\/auth\//.test(m.text)), 5000, 'fallback link');
    delete process.env.MOCK_REJECT_LOCAL_BUTTON;
    ok('если Telegram отклоняет кнопку-ссылку, бот присылает ссылку обычным текстом');

    /* --- изоляция пользователей --- */
    await say(222, '/start ' + INVITE);
    await waitFor(async () => (await sentTo(222)).length > 0, 5000, 'user2 welcome');
    const c2 = await login(222);
    const st2 = (await api(c2, 'GET', '/api/state')).data;
    assert.equal(st2.tasks.length, 0);
    assert.equal((await api(c2, 'PATCH', '/api/tasks/' + t0.id, { done: true })).status, 404);
    assert.equal((await api(c2, 'DELETE', '/api/tasks/' + t0.id)).status, 404);
    ok('данные пользователей изолированы (чужие задачи не читаются и не меняются)');

    /* --- валидация --- */
    assert.equal((await api(c1, 'POST', '/api/tasks', { title: '', date: today })).status, 400);
    assert.equal((await api(c1, 'POST', '/api/tasks', { title: 'x', date: '2026-13-40' })).status, 400);
    assert.equal((await api(c1, 'PUT', '/api/timer', { phase: 'work', endsAt: 1 })).status, 400);
    ok('валидация входных данных');

    /* --- статика --- */
    if (fs.existsSync(path.join(__dirname, '..', 'public', 'index.html'))) {
      const idx = await fetch(BASE + '/');
      assert.equal(idx.status, 200); assert.ok(/text\/html/.test(idx.headers.get('content-type')));
      assert.ok(/default-src 'self'/.test(idx.headers.get('content-security-policy')));
      assert.equal((await fetch(BASE + '/..%2fserver%2fconfig.js')).status === 200, false);
      assert.equal((await fetch(BASE + '/%2e%2e/package.json')).status === 200, false);
      ok('сайт отдаётся с CSP; выход за пределы public/ закрыт');
    }

    /* --- удаление аккаунта --- */
    assert.equal((await api(c2, 'DELETE', '/api/account')).status, 200);
    assert.equal((await api(c2, 'GET', '/api/state')).status, 401);
    ok('удаление аккаунта убирает данные и сессию');

    console.log(`\nВсе проверки пройдены: ${passed}`);
    cleanup();
    process.exit(0);
  } catch (e) {
    console.error('\n✗ ПРОВАЛ:', e.message);
    console.error(e.stack.split('\n').slice(0, 4).join('\n'));
    console.error('--- лог сервера ---\n' + log.slice(-2500));
    cleanup();
    process.exit(1);
  }
})();
