'use strict';
// Лиги: группы, подъём/спуск, вступление посреди недели, уведомления. Работает на отдельной временной базе, время подставляется.
const fs = require('fs');
const os = require('os');
const path = require('path');
const assert = require('assert');
process.env.DB_PATH = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'tracker-league-')), 'l.db');
process.env.BOT_TOKEN = '123456:TEST';
const store = require('../server/store');
const league = require('../server/league');
const rating = require('../server/rating');
const T = require('../server/time');

const W1 = '2026-10-12';                                 // понедельник
const at = (key, h = 12) => T.localToMs(key, `${String(h).padStart(2, '0')}:00`, 'Europe/Moscow');
const mk = (n, on = true) => {
  const u = store.createUser({ tgId: 7000 + n, name: 'U' + n, username: 'lg' + n });
  store.updateSettings(u.id, { rating: { on, nick: 'n' + n, photo: false } });
  rating.invalidate();                                   // как в PUT /api/settings
  return u.id;
};
let passed = 0;
const ok = (m) => { passed++; console.log('  ✓', m); };

const ids = Array.from({ length: 12 }, (_, i) => mk(i + 1));
const outsider = mk(99, false);
// неделя 1: очки растут с номером (n-й учился n*10 минут), у 1-го и 2-го — 0
ids.forEach((id, i) => { if (i >= 2) store.addStudy(id, T.addDays(W1, 1), (i + 1) * 10 * 60000, 1); });

let b = league.board(ids[0], at(W1));
assert.equal(b.on, true); assert.equal(b.league, 0); assert.equal(b.size, 12);
assert.equal(league.board(outsider, at(W1)).on, false);
ok('все вступившие попадают в одну бронзовую группу, не вступившие — нет');

// группа из 12: зоны по 4 человека
assert.equal(b.zoneSize, 4);
assert.deepEqual(b.entries.slice(0, 4).map((e) => e.zone), ['up', 'up', 'up', 'up']);
assert.equal(b.entries[0].name, 'n12');
assert.equal(b.entries.at(-1).zone, '');                 // в бронзе вылетать некуда
ok('топ-4 в зоне повышения, в самой низкой лиге зоны спуска нет');

// неделя 2: подъём лучших, у остальных лига сохраняется
const W2 = T.addDays(W1, 7);
const b2 = league.board(ids[11], at(W2));
assert.equal(b2.league, 1);
assert.equal(b2.last.rank, 1); assert.equal(b2.last.to, 1); assert.equal(b2.last.from, 0);
const mid = league.board(ids[5], at(W2));                // 6-й по очкам: ни вверх, ни вниз
assert.equal(mid.league, 0);
assert.ok(!mid.last || mid.last.to === 0);
const top = new Set(ids.slice(8).map((id) => league.board(id, at(W2)).league));
assert.deepEqual([...top], [1]);
ok('по итогам недели лучшие 4 поднялись в серебро, остальные остались');

// у серебряной группы мало людей: 4 человека → зона 1
assert.equal(b2.size, 4); assert.equal(b2.zoneSize, 1);
ok('группа из 4 человек: зона повышения и спуска — по одному');

// вступление посреди недели: попадает в бронзу
const late = mk(50);
const bl = league.board(late, at(W2, 18));
assert.equal(bl.on, true); assert.equal(bl.league, 0);
ok('вступивший посреди недели попадает в свою лигу');

// уведомления: о прошлой неделе, один раз
const notes = league.pendingNotices(at(W2));
assert.ok(notes.length >= 10 && notes.some((n) => /поднимаешься/.test(n.text)));
league.markNotified(notes[0].userId, notes[0].week);
assert.ok(!league.pendingNotices(at(W2)).some((n) => n.userId === notes[0].userId));
ok('итоги недели отправляются один раз каждому участнику');

// спуск: в серебре отстающий уходит в бронзу
store.addStudy(ids[11], T.addDays(W2, 1), 90 * 60000, 1);
store.addStudy(ids[10], T.addDays(W2, 1), 80 * 60000, 1);
store.addStudy(ids[9], T.addDays(W2, 1), 70 * 60000, 1);
const W3 = T.addDays(W2, 7);
const down = league.board(ids[8], at(W3));              // в серебре ничего не учил → последний
assert.equal(down.league, 0);
assert.equal(down.last.to, 0); assert.equal(down.last.from, 1);
ok('отстающий в серебре опускается в бронзу');

// ушедший из рейтинга не виден и не двигается
store.updateSettings(ids[11], { rating: { on: false } }); rating.invalidate();
assert.ok(!league.board(ids[10], at(W3)).entries.some((e) => e.name === 'n12'));
ok('вышедший из рейтинга исчезает из таблицы лиги');

// удаление пользователя чистит данные лиг
store.deleteUser(ids[0]);
assert.equal(require('../server/db').db.prepare('SELECT COUNT(*) c FROM league_members WHERE user_id=?').get(ids[0]).c, 0);
ok('удаление аккаунта убирает записи лиг');

console.log(`\nЛиги: ${passed} проверок пройдено`);
process.exit(0);
