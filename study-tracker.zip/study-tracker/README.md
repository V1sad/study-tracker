# Study Tracker — календарь-трекер учёбы с Telegram-ботом

Сайт + Telegram-бот для группы: у каждого свой аккаунт и свои данные (задачи, пары, статистика, настройки).
Вход без паролей — через Telegram. Напоминания приходят от сервера, даже если сайт закрыт.

**Что внутри**
- Календарь, задачи с чекбоксами, прогресс по дням, расписание пар (редактируется).
- Таймеры: Pomodoro 25/5, Deep Work 50/10, свой, секундомер — с привязкой к задаче. Конец таймера — сообщение в Telegram.
- План по математике на 28 дней (каждое 7-е занятие — лёгкий «обзор недели»), повторение темы через 5 дней (60 мин). Всё меняется в настройках. Кнопки «Сгенерировать с даты» и «Сдвинуть на сегодня».
- Статистика по времени учёбы, серия дней.
- Утренний дайджест, напоминания за 1 ч / 30 мин / 15 мин / в момент начала (настраивается).
- Установка как приложение (PWA).

**Команды бота**

| Команда | Что делает |
|---|---|
| `/today`, `/tomorrow`, `/week` | задачи и пары на день / неделю |
| `/done N [день]`, `/undo N` | отметить / снять отметку |
| `/add [день] [время] текст` | добавить задачу, напр. `/add завтра 18:30 Сдать лабу` |
| `/plan`, `/shift` | сводка плана / сдвинуть план на сегодня |
| `/stats` | статистика |
| `/pomo [работа] [отдых]`, `/stop` | таймер Pomodoro прямо в боте |
| `/notify on\|off`, `/digest on\|off\|HH:MM`, `/tz` | уведомления, дайджест, часовой пояс |
| `/site` | одноразовая ссылка для входа на сайт |

---

## Требования

- Сервер с Linux, **Node.js ≥ 22.13** (используется встроенный `node:sqlite`, **npm-пакеты не нужны**).
- Домен, направленный на сервер (для HTTPS), и порты 80/443.
- Бот от [@BotFather](https://t.me/BotFather).
- С сервера должен открываться `api.telegram.org` (см. «Если Telegram недоступен»).

## 1. Создаём бота

1. В Telegram → @BotFather → `/newbot` → имя и username → получаем **токен**.
2. `/setuserpic` — загрузи аватарку; `/setdescription` — короткое описание.
3. Команды бот регистрирует сам при запуске (`setMyCommands`).

## 2. Ставим на сервер

```bash
# Node 22+ (пример для Debian/Ubuntu)
curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash -
sudo apt-get install -y nodejs git
node -v    # должно быть v22.13 или выше

sudo useradd -r -m -d /opt/study-tracker tracker
sudo -u tracker git clone https://github.com/<ТЫ>/study-tracker.git /opt/study-tracker
cd /opt/study-tracker
sudo -u tracker mkdir -p data
sudo -u tracker cp .env.example .env
sudo -u tracker nano .env      # впиши BOT_TOKEN, BASE_URL, при желании INVITE_CODE
```

Проверка вручную: `sudo -u tracker npm start` (или `node --disable-warning=ExperimentalWarning server/index.js`), в логе должно появиться, что сервер и бот запущены. Останови через Ctrl+C.

## 3. Автозапуск (systemd)

```bash
sudo cp deploy/study-tracker.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now study-tracker
sudo systemctl status study-tracker
journalctl -u study-tracker -f       # логи
```

Если `node` лежит не в `/usr/bin/node`, поправь путь в `ExecStart` (`which node`).

## 4. HTTPS (Caddy)

```bash
sudo apt-get install -y caddy
# замени домен в deploy/Caddyfile и положи его в /etc/caddy/Caddyfile
sudo cp deploy/Caddyfile /etc/caddy/Caddyfile
sudo systemctl reload caddy
```

В DNS у домена должна быть A-запись на IP сервера. Caddy сам выпустит сертификат.
Если используешь nginx — достаточно `proxy_pass http://127.0.0.1:3000;` с заголовками `Host` и `X-Forwarded-For`.

В `.env` должно быть `BASE_URL=https://твой-домен` (без слэша в конце) — тогда cookie получают флаг Secure.

## 5. Как одногруппники подключаются

1. Открывают сайт → «Войти через Telegram» → откроется бот → «Запустить». Сайт сам войдёт.
2. Проходят короткую настройку (часовой пояс, время занятий, пары).

**Закрытая регистрация.** Задай в `.env` `INVITE_CODE=любойкод` и перезапусти сервис. Тогда новые пользователи смогут войти только по ссылке:
`https://t.me/ИМЯ_БОТА?start=любойкод`. Уже зарегистрированных это не затрагивает.

## Обновление и резервные копии

```bash
cd /opt/study-tracker && sudo -u tracker git pull && sudo systemctl restart study-tracker
```

Все данные — один файл `data/tracker.db` (режим WAL, рядом могут лежать `-wal` и `-shm`). Бэкап:

```bash
sudo -u tracker sqlite3 /opt/study-tracker/data/tracker.db ".backup '/opt/study-tracker/data/backup.db'"
# или просто остановить сервис и скопировать папку data/
```

Каждый пользователь может сам выгрузить свои данные (`/api/export`) и удалить аккаунт в настройках.

## Выкладываем на GitHub

```bash
cd study-tracker
git init && git add . && git commit -m "Study Tracker"
git branch -M main
git remote add origin https://github.com/<ТЫ>/study-tracker.git
git push -u origin main
```

`.gitignore` уже исключает `.env` и `data/` — токен бота и чужие данные в репозиторий не попадут.
**Если токен случайно попал в публичный репозиторий — немедленно перевыпусти его в @BotFather (`/revoke`).**

## Если Telegram недоступен с сервера

Некоторые хостинги блокируют `api.telegram.org`. Проверь: `curl -sS https://api.telegram.org`. Если не открывается — подними прокси, пробрасывающий Telegram API, и укажи его адрес в `.env`: `TG_API_BASE=https://твой-прокси`.

## Настройки `.env`

| Переменная | По умолчанию | Назначение |
|---|---|---|
| `BOT_TOKEN` | — | токен бота (обязательно) |
| `BASE_URL` | — | публичный адрес сайта |
| `PORT`, `HOST` | `3000`, `127.0.0.1` | где слушает приложение |
| `INVITE_CODE` | пусто | включает закрытую регистрацию |
| `DEFAULT_TZ` | `Europe/Moscow` | часовой пояс новых пользователей |
| `DB_PATH` | `./data/tracker.db` | путь к базе |
| `TG_API_BASE` | `https://api.telegram.org` | адрес API Telegram / прокси |
| `TICK_MS` | `5000` | период проверки напоминаний |

## Разработка и тесты

```bash
npm test      # 29 сквозных проверок на моковом Telegram API, без сети и без токена
```

## Безопасность

- Данные пользователей изолированы: все запросы привязаны к `user_id`.
- Сессия — httpOnly cookie, SameSite=Lax; защита от CSRF (только `application/json`), CSP, лимит размера тела и частоты попыток входа.
- Вход одноразовыми кодами через Telegram; паролей нет.

## Структура

```
server/   index, app (HTTP+API), bot, scheduler, store, plan, settings, db, tg, format, time, config
public/   index.html, app.js, style.css, ticker.js, sw.js, manifest, иконки
deploy/   systemd-юнит, Caddyfile
test/     mock-telegram.js, e2e.js
```

## Известные ограничения

- Время работы веб-таймера учитывается в открытой вкладке; сообщение об окончании таймера отправляет сервер в любом случае. Таймер `/pomo` в боте учитывается сервером.
- Бот работает через long polling — один экземпляр сервиса на один токен.
