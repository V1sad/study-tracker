'use strict';
// Лиги в духе Duolingo. Каждую неделю (пн–вс) участники рейтинга делятся на группы до 30 человек внутри своей лиги.
// По итогам недели лучшие поднимаются на ступень выше, худшие опускаются. Очки — минуты учёбы (как в рейтинге).
// Состав недели создаётся лениво при первом обращении, поэтому сервер может быть выключен в понедельник.
const crypto = require('crypto');
const { db, tx } = require('./db');
const T = require('./time');
const rating = require('./rating');

const LEAGUES = [
  ['🥉', 'Бронзовая'], ['🥈', 'Серебряная'], ['🥇', 'Золотая'], ['🔷', 'Сапфировая'], ['🔴', 'Рубиновая'],
  ['🟢', 'Изумрудная'], ['🟣', 'Аметистовая'], ['⚪', 'Жемчужная'], ['⚫', 'Обсидиановая'], ['💠', 'Алмазная'],
];
const GROUP_MAX = 30;
const ZONE_MAX = 5;
const SECRET = process.env.SESSION_SECRET || process.env.BOT_TOKEN || 'dev-secret';

const leagueName = (i) => `${LEAGUES[i][0]} ${LEAGUES[i][1]}`;
const weekOf = (now = Date.now()) => rating.periodStart('week', now);
const zoneSize = (n) => Math.min(ZONE_MAX, Math.floor(n / 3));

function xpMap(week) {
  const to = T.addDays(week, 6);
  const m = new Map();
  for (const r of db.prepare('SELECT user_id, ms FROM study WHERE date>=? AND date<=? AND ms>0').all(week, to)) {
    m.set(r.user_id, (m.get(r.user_id) || 0) + Math.min(Math.round(r.ms / 60000), rating.DAY_CAP_MIN));
  }
  return m;
}
const shuffleKey = (week, id) => crypto.createHmac('sha256', SECRET).update(`league:${week}:${id}`).digest('hex');
const stateOf = (userId) => db.prepare('SELECT * FROM league_state WHERE user_id=?').get(userId);
const leagueOf = (userId) => { const s = stateOf(userId); return s ? s.league : 0; };

// кто поднимается/опускается в группе: массив строк, отсортированных по очкам
function zones(rows, league) {
  const n = rows.length, k = zoneSize(n);
  return rows.map((r, i) => {
    if (i < k && r.xp > 0 && league < LEAGUES.length - 1) return 'up';
    if (i >= n - k && n >= 4 && league > 0) return 'down';
    return '';
  });
}

// подвести итоги прошлой недели и собрать группы новой; возвращает true, если неделя была создана
function sync(now = Date.now()) {
  const week = weekOf(now);
  if (db.prepare('SELECT 1 FROM league_members WHERE week=? LIMIT 1').get(week)) return false;
  rating.invalidate();
  const parts = rating.participants();
  const prev = T.addDays(week, -7);
  tx(() => {
    const prevRows = db.prepare('SELECT user_id, league, grp FROM league_members WHERE week=?').all(prev);
    if (prevRows.length) {
      const xp = xpMap(prev), active = new Set(parts.map((p) => p.id));
      const groups = new Map();
      for (const r of prevRows) {
        if (!active.has(r.user_id)) continue;           // ушедшие из рейтинга не двигаются
        const key = `${r.league}:${r.grp}`;
        if (!groups.has(key)) groups.set(key, { league: r.league, rows: [] });
        groups.get(key).rows.push({ id: r.user_id, xp: xp.get(r.user_id) || 0 });
      }
      for (const g of groups.values()) {
        g.rows.sort((a, b) => b.xp - a.xp || a.id - b.id);
        const z = zones(g.rows, g.league);
        g.rows.forEach((r, i) => {
          const to = z[i] === 'up' ? g.league + 1 : z[i] === 'down' ? g.league - 1 : g.league;
          const result = JSON.stringify({ week: prev, from: g.league, to, rank: i + 1, size: g.rows.length, xp: r.xp });
          db.prepare(`INSERT INTO league_state(user_id,league,result) VALUES(?,?,?)
            ON CONFLICT(user_id) DO UPDATE SET league=excluded.league, result=excluded.result`).run(r.id, to, result);
        });
      }
    }
    // новые группы: внутри лиги перемешиваем и делим поровну, не больше 30 в группе
    const byLeague = new Map();
    for (const p of parts) {
      const l = leagueOf(p.id);
      if (!byLeague.has(l)) byLeague.set(l, []);
      byLeague.get(l).push(p.id);
    }
    const ins = db.prepare('INSERT OR IGNORE INTO league_members(week,user_id,league,grp) VALUES(?,?,?,?)');
    for (const [l, ids] of byLeague) {
      ids.sort((a, b) => (shuffleKey(week, a) < shuffleKey(week, b) ? -1 : 1));
      const groups = Math.ceil(ids.length / GROUP_MAX);
      ids.forEach((id, i) => ins.run(week, id, l, i % groups));
    }
  });
  return true;
}

// участник, вступивший посреди недели, попадает в наименее заполненную группу своей лиги
function ensureMember(userId, week) {
  const have = db.prepare('SELECT league, grp FROM league_members WHERE week=? AND user_id=?').get(week, userId);
  if (have) return have;
  const l = leagueOf(userId);
  const counts = db.prepare('SELECT grp, COUNT(*) c FROM league_members WHERE week=? AND league=? GROUP BY grp ORDER BY c').all(week, l);
  let grp = 0;
  if (counts.length) {
    grp = counts[0].c < GROUP_MAX ? counts[0].grp : Math.max(...counts.map((c) => c.grp)) + 1;
  }
  db.prepare('INSERT OR IGNORE INTO league_members(week,user_id,league,grp) VALUES(?,?,?,?)').run(week, userId, l, grp);
  return { league: l, grp };
}

function board(userId, now = Date.now()) {
  sync(now);
  const week = weekOf(now), end = T.addDays(week, 6);
  const today = T.dateKey(now, rating.RATING_TZ);
  const parts = new Map(rating.participants().map((p) => [p.id, p]));
  const base = { leagues: LEAGUES.map(([e, n]) => `${e} ${n}`), week, end, daysLeft: Math.max(0, Math.round((Date.parse(end) - Date.parse(today)) / 86400000) + 1) };
  if (!parts.has(userId)) return { ...base, on: false };
  const me = ensureMember(userId, week);
  const xp = xpMap(week);
  const members = db.prepare('SELECT user_id FROM league_members WHERE week=? AND league=? AND grp=?').all(week, me.league, me.grp)
    .map((r) => parts.get(r.user_id)).filter(Boolean)
    .map((p) => ({ p, xp: xp.get(p.id) || 0 }))
    .sort((a, b) => b.xp - a.xp || a.p.id - b.p.id);
  const z = zones(members, me.league);
  let rank = 0, prevXp = null;
  const entries = members.map((m, i) => {
    if (m.xp !== prevXp) { rank = i + 1; prevXp = m.xp; }
    return { rank, name: rating.displayName(m.p), pid: m.p.pid, photo: !!m.p.r.photo, xp: m.xp, me: m.p.id === userId, zone: z[i] };
  });
  const mine = entries.find((e) => e.me);
  let last = null;
  const st = stateOf(userId);
  if (st && st.result) { try { last = JSON.parse(st.result); } catch { /* повреждено */ } }
  return {
    ...base, on: true, league: me.league, name: leagueName(me.league), size: entries.length,
    zoneSize: zoneSize(entries.length), top: me.league >= LEAGUES.length - 1,
    entries, me: { rank: mine.rank, xp: mine.xp, zone: mine.zone },
    last: last && { ...last, fromName: leagueName(last.from), toName: leagueName(last.to) },
  };
}

// итоги прошлой недели, о которых ещё не сообщали в Telegram
function pendingNotices(now = Date.now()) {
  sync(now);
  const prev = T.addDays(weekOf(now), -7);
  const out = [];
  const active = new Set(rating.participants().map((p) => p.id));
  for (const s of db.prepare("SELECT user_id, result, notified FROM league_state WHERE result<>''").all()) {
    if (!active.has(s.user_id) || s.notified === prev) continue;
    let r; try { r = JSON.parse(s.result); } catch { continue; }
    if (r.week !== prev) continue;
    out.push({ userId: s.user_id, week: prev, text: noticeText(r) });
  }
  return out;
}
function noticeText(r) {
  const head = `🏆 Итоги недели в лиге «${LEAGUES[r.from][1]}»: ${r.rank} место из ${r.size} (${r.xp} оч.)`;
  if (r.to > r.from) return `${head}\n🎉 Ты поднимаешься в лигу «${LEAGUES[r.to][1]}»! Так держать.`;
  if (r.to < r.from) return `${head}\n⬇️ Новая неделя начнётся в лиге «${LEAGUES[r.to][1]}». Вернуть место можно уже сегодня — запусти таймер.`;
  return `${head}\nОстаёшься в этой лиге. Новая неделя — новый шанс подняться!`;
}
const markNotified = (userId, week) => db.prepare('UPDATE league_state SET notified=? WHERE user_id=?').run(week, userId);

module.exports = { board, sync, pendingNotices, markNotified, noticeText, LEAGUES, leagueName, weekOf, zones };
