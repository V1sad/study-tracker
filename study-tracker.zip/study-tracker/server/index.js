'use strict';
const cfg = require('./config');
require('./db');
const { createServer } = require('./app');
const bot = require('./bot');
const scheduler = require('./scheduler');

process.on('unhandledRejection', (e) => console.error('[unhandledRejection]', e));
process.on('uncaughtException', (e) => console.error('[uncaughtException]', e));

const server = createServer();
server.listen(cfg.port, cfg.host, () => {
  console.log(`[http] слушаю http://${cfg.host}:${cfg.port} (публичный адрес: ${cfg.baseUrl})`);
});
bot.start();
scheduler.start();

function shutdown() {
  console.log('Останавливаюсь…');
  bot.stop(); scheduler.stop();
  server.close(() => process.exit(0));
  setTimeout(() => process.exit(0), 3000).unref();
}
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
