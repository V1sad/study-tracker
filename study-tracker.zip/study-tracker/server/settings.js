'use strict';
// Настройки пользователя: значения по умолчанию, слияние и проверка входных данных.
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;
const REMIND_OK = [0, 5, 10, 15, 30, 45, 60, 120, 180, 1440];

// Расписание пар группы (dow: 0 = вс, 1 = пн … 6 = сб). Каждый может отредактировать у себя.
const DEFAULT_SCHEDULE = [
  { id: 'c1', dow: 1, start: '11:20', end: '16:40', title: 'Пары: английский, основы российской государственности, физкультура' },
  { id: 'c2', dow: 2, start: '09:40', end: '16:40', title: 'Пары: основы российской государственности, философия, финансово-экономический практикум' },
  { id: 'c3', dow: 3, start: '11:20', end: '15:00', title: 'Пары: введение в алгебру и мат. анализ' },
  { id: 'c4', dow: 4, start: '15:10', end: '16:40', title: 'Пары: физкультура' },
  { id: 'c5', dow: 5, start: '09:40', end: '16:40', title: 'Пары: аналитическая геометрия, основы военной подготовки' },
];

function defaultSettings() {
  return {
    onboarded: false,
    tgOn: true,              // присылать напоминания в Telegram
    notifyTimer: true,       // сообщать о конце таймера
    digest: true,            // утренняя сводка
    digestTime: '08:00',
    defaultRemind: [15, 0],
    autoStart: false,
    custom: { work: 30, brk: 5 },
    plan: {
      topicTime: '19:00', topicMin: 45,
      repeatOn: true, repeatAfter: 5, repeatMin: 60, repeatTime: '20:00',
    },
    schedule: DEFAULT_SCHEDULE.map((c) => ({ ...c })),
  };
}

function merge(saved) {
  const d = defaultSettings();
  const s = { ...d, ...(saved || {}) };
  s.plan = { ...d.plan, ...((saved && saved.plan) || {}) };
  s.custom = { ...d.custom, ...((saved && saved.custom) || {}) };
  if (!Array.isArray(s.schedule)) s.schedule = d.schedule;
  if (!Array.isArray(s.defaultRemind)) s.defaultRemind = d.defaultRemind;
  return s;
}

const clampInt = (v, lo, hi) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= lo && n <= hi ? n : null;
};
function cleanRemind(arr) {
  if (!Array.isArray(arr)) return [];
  return [...new Set(arr.map(Number).filter((n) => REMIND_OK.includes(n)))].sort((a, b) => b - a);
}

function sanitize(input, current) {
  const out = merge(current);
  const i = input && typeof input === 'object' ? input : {};
  for (const k of ['onboarded', 'tgOn', 'notifyTimer', 'digest', 'autoStart']) {
    if (typeof i[k] === 'boolean') out[k] = i[k];
  }
  if (typeof i.digestTime === 'string' && HHMM.test(i.digestTime)) out.digestTime = i.digestTime;
  if (Array.isArray(i.defaultRemind)) out.defaultRemind = cleanRemind(i.defaultRemind);
  if (i.custom && typeof i.custom === 'object') {
    const w = clampInt(i.custom.work, 1, 240), b = clampInt(i.custom.brk, 0, 120);
    if (w != null) out.custom.work = w;
    if (b != null) out.custom.brk = b;
  }
  if (i.plan && typeof i.plan === 'object') {
    const p = i.plan;
    if (typeof p.topicTime === 'string' && HHMM.test(p.topicTime)) out.plan.topicTime = p.topicTime;
    if (typeof p.repeatTime === 'string' && HHMM.test(p.repeatTime)) out.plan.repeatTime = p.repeatTime;
    if (typeof p.repeatOn === 'boolean') out.plan.repeatOn = p.repeatOn;
    const a = clampInt(p.repeatAfter, 1, 30), rm = clampInt(p.repeatMin, 5, 240), tm = clampInt(p.topicMin, 5, 240);
    if (a != null) out.plan.repeatAfter = a;
    if (rm != null) out.plan.repeatMin = rm;
    if (tm != null) out.plan.topicMin = tm;
  }
  if (Array.isArray(i.schedule)) {
    out.schedule = i.schedule.slice(0, 40).map((c, n) => ({
      id: String((c && c.id) || 'c' + n).replace(/[^\w-]/g, '').slice(0, 12) || 'c' + n,
      dow: clampInt(c && c.dow, 0, 6) ?? 1,
      start: c && HHMM.test(c.start) ? c.start : '09:00',
      end: c && HHMM.test(c.end) ? c.end : '10:00',
      title: String((c && c.title) || 'Пара').trim().slice(0, 160) || 'Пара',
    }));
  }
  return out;
}

module.exports = { HHMM, REMIND_OK, defaultSettings, merge, sanitize, cleanRemind, DEFAULT_SCHEDULE };
