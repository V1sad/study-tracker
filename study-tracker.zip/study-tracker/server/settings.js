'use strict';
// Настройки пользователя: значения по умолчанию, слияние и проверка входных данных.
const HHMM = /^([01]\d|2[0-3]):[0-5]\d$/;
const REMIND_OK = [0, 5, 10, 15, 30, 45, 60, 120, 180, 1440];

// Расписание пар группы (dow: 0 = вс, 1 = пн … 6 = сб). Каждый может отредактировать у себя.
const DEFAULT_SCHEDULE = [
  { id: 'c1', dow: 1, start: '11:20', end: '16:40', title: 'Пары: английский, основы российской государственности, физкультура' },
  { id: 'c2', dow: 2, start: '09:40', end: '16:40', title: 'Пары: основы российской государственности, философия, финансово-экономический практикум' },
  { id: 'c3', dow: 3, start: '11:20', end: '15:00', title: 'Пары: введение в алгебру и мат. анализ' },
  { id: 'c4', dow: 4, start: '15:10', end: '16:40', title: 'Пары: физкультура' },
  { id: 'c5', dow: 5, start: '09:40', end: '16:40', title: 'Пары: аналитическая геометрия, основы военной подготовки' },
];

function defaultSettings() {
  return {
    onboarded: false,
    tgOn: true,              // присылать напоминания в Telegram
    notifyTimer: true,       // сообщать о конце таймера
    digest: true,            // утренняя сводка
    digestTime: '08:00',
    defaultRemind: [15, 0],
    autoStart: false,
    custom: { work: 30, brk: 5 },
    plan: {
      topicTime: '19:00', topicMin: 45,
      repeatOn: true, repeatAfter: 5, repeatMin: 60, repeatTime: '20:00',
    },
    // личный Java-трек (доступен только пользователям из JAVA_USERS)
    java: {
      topicTime: '21:00', topicMin: 60,
      repeatOn: false, repeatAfter: 5, repeatMin: 30, repeatTime: '22:00',
    },
    schedule: DEFAULT_SCHEDULE.map((c) => ({ ...c })),
    topWeek: '',             // дата внутри «верхней» недели (для пар с пометкой В/Н)
    group: '',               // группа, из которой загружено расписание (для подписи)
    groupId: '',             // номер группы на сайте вуза — нужен для автообновления и экзаменов
    autoSync: true,          // автообновление расписания и сообщения об изменениях
    // рейтинг: по умолчанию выключен; показывается только ник и фото
    rating: { on: false, nick: '', photo: true },
  };
}

function merge(saved) {
  const d = defaultSettings();
  const s = { ...d, ...(saved || {}) };
  s.plan = { ...d.plan, ...((saved && saved.plan) || {}) };
  s.rating = { ...d.rating, ...((saved && saved.rating) || {}) };
  s.java = { ...d.java, ...((saved && saved.java) || {}) };
  s.custom = { ...d.custom, ...((saved && saved.custom) || {}) };
  if (!Array.isArray(s.schedule)) s.schedule = d.schedule;
  if (!Array.isArray(s.defaultRemind)) s.defaultRemind = d.defaultRemind;
  return s;
}

const clampInt = (v, lo, hi) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) && n >= lo && n <= hi ? n : null;
};
function cleanRemind(arr) {
  if (!Array.isArray(arr)) return [];
  return [...new Set(arr.map(Number).filter((n) => REMIND_OK.includes(n)))].sort((a, b) => b - a);
}

const MD = /^(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$/;
function cleanRanges(r) {
  if (!Array.isArray(r)) return [];
  return r.slice(0, 24).filter((x) => Array.isArray(x) && MD.test(x[0]) && MD.test(x[1])).map((x) => [x[0], x[1]]);
}

function sanitize(input, current) {
  const out = merge(current);
  const i = input && typeof input === 'object' ? input : {};
  for (const k of ['onboarded', 'tgOn', 'notifyTimer', 'digest', 'autoStart']) {
    if (typeof i[k] === 'boolean') out[k] = i[k];
  }
  if (typeof i.digestTime === 'string' && HHMM.test(i.digestTime)) out.digestTime = i.digestTime;
  if (Array.isArray(i.defaultRemind)) out.defaultRemind = cleanRemind(i.defaultRemind);
  if (i.custom && typeof i.custom === 'object') {
    const w = clampInt(i.custom.work, 1, 240), b = clampInt(i.custom.brk, 0, 120);
    if (w != null) out.custom.work = w;
    if (b != null) out.custom.brk = b;
  }
  for (const key of ['plan', 'java']) {
    if (!(i[key] && typeof i[key] === 'object')) continue;
    const p = i[key], o = out[key];
    if (typeof p.topicTime === 'string' && HHMM.test(p.topicTime)) o.topicTime = p.topicTime;
    if (typeof p.repeatTime === 'string' && HHMM.test(p.repeatTime)) o.repeatTime = p.repeatTime;
    if (typeof p.repeatOn === 'boolean') o.repeatOn = p.repeatOn;
    const a = clampInt(p.repeatAfter, 1, 30), rm = clampInt(p.repeatMin, 5, 240), tm = clampInt(p.topicMin, 5, 240);
    if (a != null) o.repeatAfter = a;
    if (rm != null) o.repeatMin = rm;
    if (tm != null) o.topicMin = tm;
  }
  if (Array.isArray(i.schedule)) {
    out.schedule = i.schedule.slice(0, 150).map((c, n) => ({
      id: String((c && c.id) || 'c' + n).replace(/[^\w-]/g, '').slice(0, 12) || 'c' + n,
      dow: clampInt(c && c.dow, 0, 6) ?? 1,
      start: c && HHMM.test(c.start) ? c.start : '09:00',
      end: c && HHMM.test(c.end) ? c.end : '10:00',
      title: String((c && c.title) || 'Пара').trim().slice(0, 160) || 'Пара',
      room: String((c && c.room) || '').trim().slice(0, 80),
      teacher: String((c && c.teacher) || '').trim().slice(0, 120),
      kind: String((c && c.kind) || '').trim().slice(0, 16),
      week: c && (c.week === 'В' || c.week === 'Н') ? c.week : '',
      ranges: cleanRanges(c && c.ranges),
    }));
  }
  if (typeof i.topWeek === 'string' && (i.topWeek === '' || /^\d{4}-\d{2}-\d{2}$/.test(i.topWeek))) out.topWeek = i.topWeek;
  if (typeof i.group === 'string') out.group = i.group.slice(0, 80);
  if (typeof i.groupId === 'string' && (i.groupId === '' || /^\d{1,9}$/.test(i.groupId))) out.groupId = i.groupId;
  if (typeof i.autoSync === 'boolean') out.autoSync = i.autoSync;
  if (i.rating && typeof i.rating === 'object') {
    if (typeof i.rating.on === 'boolean') out.rating.on = i.rating.on;
    if (typeof i.rating.nick === 'string') out.rating.nick = i.rating.nick.replace(/[\u0000-\u001f<>]/g, '').trim().slice(0, 24);
    if (typeof i.rating.photo === 'boolean') out.rating.photo = i.rating.photo;

  }
  return out;
}

module.exports = { HHMM, REMIND_OK, defaultSettings, merge, sanitize, cleanRemind, DEFAULT_SCHEDULE };
