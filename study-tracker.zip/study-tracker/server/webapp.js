'use strict';
// Проверка данных запуска Telegram Mini App (initData): подпись HMAC-SHA256 по токену бота, свежесть, пользователь.
// Схема из документации Telegram: secret = HMAC_SHA256("WebAppData", bot_token); hash = HMAC_SHA256(secret, строка_проверки).
const crypto = require('crypto');

function validate(initData, botToken, { maxAgeSec = 24 * 3600, now = Date.now() } = {}) {
  if (typeof initData !== 'string' || !initData || initData.length > 4096 || !botToken) return null;
  const params = new URLSearchParams(initData);
  const hash = params.get('hash');
  if (!hash || !/^[0-9a-f]{64}$/.test(hash)) return null;
  params.delete('hash');
  const check = [...params.entries()].sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  const calc = crypto.createHmac('sha256', secret).update(check).digest();
  const given = Buffer.from(hash, 'hex');
  if (given.length !== calc.length || !crypto.timingSafeEqual(given, calc)) return null;
  const authDate = Number(params.get('auth_date'));
  if (!Number.isFinite(authDate) || now / 1000 - authDate > maxAgeSec || authDate - now / 1000 > 300) return null;
  let user;
  try { user = JSON.parse(params.get('user') || ''); } catch { return null; }
  if (!user || typeof user !== 'object' || !Number.isSafeInteger(user.id) || user.id <= 0 || user.is_bot) return null;
  return {
    id: user.id,
    name: [user.first_name, user.last_name].filter(Boolean).join(' ').slice(0, 80),
    username: String(user.username || '').slice(0, 64),
  };
}

// Для тестов: собрать корректно подписанные initData
function sign(fields, botToken) {
  const params = new URLSearchParams(fields);
  const check = [...params.entries()].sort(([a], [b]) => (a < b ? -1 : 1)).map(([k, v]) => `${k}=${v}`).join('\n');
  const secret = crypto.createHmac('sha256', 'WebAppData').update(botToken).digest();
  params.set('hash', crypto.createHmac('sha256', secret).update(check).digest('hex'));
  return params.toString();
}

module.exports = { validate, sign };
