'use strict';
// Telegram-бот: вход на сайт, быстрые команды, таймер. Работает через long polling.
const cfg = require('./config');
const T = require('./time');
const store = require('./store');
const F = require('./format');
const tg = require('./tg');

let me = null;
let running = false;
let offset = 0;
const username = () => (me && me.username) || null;

const COMMAND_LIST = [
  { command: 'today', description: 'Пары и задачи на сегодня' },
  { command: 'tomorrow', description: 'План на завтра' },
  { command: 'week', description: 'Обзор недели' },
  { command: 'done', description: 'Отметить выполненным: /done 2' },
  { command: 'undo', description: 'Снять отметку: /undo 2' },
  { command: 'add', description: 'Добавить: /add завтра 18:30 текст' },
  { command: 'plan', description: 'Прогресс плана и ближайшие темы' },
  { command: 'shift', description: 'Сдвинуть план с сегодняшнего дня' },
  { command: 'stats', description: 'Статистика' },
  { command: 'pomo', description: 'Таймер: /pomo 25 5' },
  { command: 'stop', description: 'Остановить таймер' },
  { command: 'notify', description: 'Напоминания вкл/выкл' },
  { command: 'digest', description: 'Утренняя сводка вкл/выкл/время' },
  { command: 'site', description: 'Ссылка для входа на сайт' },
  { command: 'help', description: 'Справка' },
];

const HELP = `Команды:
/today, /tomorrow — пары и задачи дня (кнопками можно отмечать выполненное)
/week — обзор недели
/done 2 — отметить задачу №2 сегодня (/done 2 завтра — на другой день), /undo 2 — снять отметку
/add завтра 18:30 решить 5 задач — быстро добавить (дата и время необязательны)
/plan — прогресс плана, /shift — сдвинуть невыполненное на сегодня
/stats — статистика
/pomo 25 5 — таймер 25 мин работы + 5 мин отдыха, /stop — остановить
/notify on|off — напоминания, /digest on|off|08:00 — утренняя сводка
/tz Europe/Moscow — часовой пояс
/site — войти на сайт`;

/* ---------- разбор дат и времени ---------- */
const DAYS = { пн: 1, вт: 2, ср: 3, чт: 4, пт: 5, сб: 6, вс: 0 };
function parseDayWord(w, user, { future = false } = {}) {
  const word = w.toLowerCase();
  const today = store.todayOf(user);
  if (word === 'сегодня') return today;
  if (word === 'завтра') return T.addDays(today, 1);
  if (word === 'послезавтра') return T.addDays(today, 2);
  if (word === 'вчера') return T.addDays(today, -1);
  if (Object.hasOwn(DAYS, word)) {
    for (let n = 0; n < 7; n++) { const k = T.addDays(today, n); if (T.dow(k) === DAYS[word]) return k; }
  }
  let m = word.match(/^(\d{1,2})\.(\d{1,2})(?:\.(\d{2}|\d{4}))?$/);
  if (m) {
    const day = +m[1], mon = +m[2];
    if (mon < 1 || mon > 12) return null;
    let year = +today.slice(0, 4);
    if (m[3]) year = m[3].length === 2 ? 2000 + +m[3] : +m[3];
    let key = `${year}-${T.pad(mon)}-${T.pad(day)}`;
    if (!T.validDate(key)) return null;
    if (!m[3] && future && key < today) { key = `${year + 1}-${T.pad(mon)}-${T.pad(day)}`; if (!T.validDate(key)) return null; }
    return key;
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(word) && T.validDate(word)) return word;
  return null;
}
function parseTimeWord(w) {
  const m = w.match(/^(\d{1,2})[:.](\d{2})$/);
  if (!m) return null;
  const h = +m[1], mi = +m[2];
  return h <= 23 && mi <= 59 ? `${T.pad(h)}:${T.pad(mi)}` : null;
}
function parseAdd(text, user) {
  const tokens = text.split(/\s+/).filter(Boolean);
  let date = null, time = '';
  for (let n = 0; n < 2 && tokens.length; n++) {
    const tok = tokens[0];
    const t = tok.includes(':') ? parseTimeWord(tok) : null;
    const d = !t ? parseDayWord(tok, user, { future: true }) : null;
    if (t && !time) { time = t; tokens.shift(); }
    else if (d && !date) { date = d; tokens.shift(); }
    else {
      const t2 = !time ? parseTimeWord(tok) : null; // «19.30»
      if (t2 && !d) { time = t2; tokens.shift(); } else break;
    }
  }
  return { date: date || store.todayOf(user), time, title: tokens.join(' ').trim() };
}

/* ---------- отправка ---------- */
const reply = (chatId, text, keyboard) => tg.send(chatId, text, keyboard ? { reply_markup: keyboard } : {});

async function sendLoginLink(user, chatId, intro) {
  const code = store.newLogin(user.id);
  const url = `${cfg.baseUrl}/auth/${code}`;
  const r = await tg.send(chatId, `${intro}\n\nСсылка действует 10 минут и работает один раз.`, {
    reply_markup: { inline_keyboard: [[{ text: '🌐 Открыть сайт', url }]] },
  });
  if (!r) await tg.send(chatId, `${intro}\n\n${url}\n\nСсылка действует 10 минут и работает один раз.`);
}

/* ---------- команды ---------- */
async function cmdStart(msg, user, args) {
  const chatId = msg.chat.id;
  let loginCode = null, invite = '';
  if (args.startsWith('login_')) loginCode = args.slice(6).trim();
  else invite = args;
  let isNew = false;
  if (!user) {
    if (cfg.invite && invite !== cfg.invite) {
      await reply(chatId, '🔒 Бот закрытый. Чтобы начать, отправь /start и код приглашения, например:\n/start КОД\n(код можно получить у того, кто поделился ботом).');
      return;
    }
    const name = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ');
    user = store.createUser({ tgId: msg.from.id, name, username: msg.from.username || '' });
    isNew = true;
  }
  if (loginCode) {
    const ok = store.bindLogin(loginCode, user.id);
    await reply(chatId, ok
      ? '✅ Вход выполнен. Вернись на сайт — страница обновится сама.'
      : '⚠️ Ссылка для входа устарела. Нажми «Войти через Telegram» на сайте ещё раз.');
    if (ok && isNew) await reply(chatId, `Добро пожаловать, ${user.name || 'студент'}! Команды бота: /help`);
    return;
  }
  const hello = `👋 Привет, ${user.name || 'студент'}! Я бот-трекер учёбы.\n\nПрисылаю напоминания о задачах, сообщаю об окончании таймера и каждое утро показываю расписание на день. Календарь, план и статистика — на сайте.\n\nВсе команды: /help`;
  await sendLoginLink(user, chatId, isNew ? `${hello}\n\nНачни с сайта: там настроишь план под себя.` : hello);
}

async function sendDay({ user, chatId }, offset) {
  const date = T.addDays(store.todayOf(user), offset);
  const r = F.renderDay(user, date);
  await reply(chatId, r.text, r.keyboard);
}

async function cmdMark({ user, chatId, args }, done) {
  const [a, b] = args.split(/\s+/);
  const n = parseInt(a, 10);
  const cmd = done ? '/done' : '/undo';
  if (!n || n < 1) return reply(chatId, `Укажи номер задачи из списка /today, например: ${cmd} 2`);
  const date = b ? parseDayWord(b, user) : store.todayOf(user);
  if (!date) return reply(chatId, 'Не понял день. Примеры: завтра, пн, 28.10');
  const task = F.nthTask(user.id, date, n);
  if (!task) return reply(chatId, `Задачи №${n} на ${F.ddmm(date)} нет. Список: /today`);
  store.patchTask(user.id, task.id, { done });
  const r = F.renderDay(user, date);
  await reply(chatId, `${done ? '✅ Выполнено' : '↩️ Снято'}: ${task.title}\n\n${r.text}`, r.keyboard);
}

async function cmdAdd({ user, chatId, args }) {
  if (!args) return reply(chatId, 'Формат: /add [день] [время] текст\nПримеры:\n/add завтра 18:30 решить 5 задач\n/add пт 15:00 сдать лабу\n/add купить тетрадь');
  const p = parseAdd(args, user);
  if (!p.title) return reply(chatId, 'Не вижу текста задачи. Пример: /add завтра 18:30 решить 5 задач');
  const task = store.insertTask(user.id, {
    date: p.date, time: p.time, title: p.title.slice(0, 160), type: 'task', cat: 'study',
    remind: p.time ? user.settings.defaultRemind : [],
  });
  const rem = task.remind.length ? `\n🔔 ${task.remind.map(F.remindLabel).join(', ')}` : '';
  await reply(chatId, `➕ Добавлено: ${F.ddmm(task.date)}${task.time ? ' ' + task.time : ''} — ${task.title}${rem}`);
}

async function cmdWeek({ user, chatId }) {
  const today = store.todayOf(user);
  const lines = ['🗓 Ближайшие 7 дней'];
  for (let i = 0; i < 7; i++) {
    const date = T.addDays(today, i);
    const tasks = store.dayTasks(user.id, date).filter((t) => t.type !== 'note');
    const classes = (user.settings.schedule || []).filter((c) => c.dow === T.dow(date)).sort((a, b) => a.start.localeCompare(b.start));
    const done = tasks.filter((t) => t.done).length;
    let line = `${F.WD[T.dow(date)]} ${F.ddmm(date)}${i === 0 ? ' (сегодня)' : ''}: `;
    line += tasks.length ? `${done}/${tasks.length} задач` : 'задач нет';
    if (classes.length) line += ` · пары ${classes[0].start}–${classes[classes.length - 1].end}`;
    lines.push(line);
    const first = tasks.find((t) => !t.done);
    if (first) lines.push(`   → ${first.time ? first.time + ' ' : ''}${first.title}`);
  }
  await reply(chatId, lines.join('\n'));
}

async function cmdPlan({ user, chatId }) {
  const s = store.planSummary(user.id);
  if (!s) return reply(chatId, 'План пока не создан. Открой сайт → «Сгенерировать заново» (/site).');
  const lines = [
    `📚 План по математике`,
    `Тем: ${s.topicsDone}/${s.topicsTotal} · повторений: ${s.repeatsDone}/${s.repeatsTotal}`,
    `Всего выполнено: ${s.done}/${s.total} (${Math.round((s.done / s.total) * 100)}%)`,
  ];
  if (s.next.length) {
    lines.push('\nБлижайшее:');
    for (const t of s.next.slice(0, 4)) lines.push(`• ${F.ddmm(t.date)} ${t.time} ${t.title}`);
  } else lines.push('\n🎉 План выполнен! Создай новый на сайте.');
  await reply(chatId, lines.join('\n'));
}

async function cmdShift({ user, chatId }) {
  const r = store.shiftPlan(user);
  if (!r) return reply(chatId, 'Нечего сдвигать: в плане нет невыполненных задач.');
  await reply(chatId, `⏩ Сдвинул ${r.moved} невыполненных задач плана: ближайшая тема (день ${r.firstDay}) теперь сегодня.`);
}

async function cmdStats({ user, chatId }) {
  const st = store.statsFor(user);
  const lines = [
    '📊 Статистика',
    `Сегодня: ${F.fmtMin(st.todayMs)} · 🍅 ${st.todayPomos}`,
    `За 7 дней: ${F.fmtMin(st.weekMs)} · 🍅 ${st.weekPomos}`,
    `🔥 Серия дней с выполненными задачами: ${st.streak}`,
  ];
  if (st.plan) lines.push(`Тем плана: ${st.plan.topicsDone}/${st.plan.topicsTotal} · повторений: ${st.plan.repeatsDone}/${st.plan.repeatsTotal}`);
  await reply(chatId, lines.join('\n'));
}

const clampInt = (v, lo, hi) => { const n = Math.round(Number(v)); return Number.isFinite(n) && n >= lo && n <= hi ? n : null; };
async function cmdPomo({ user, chatId, args }) {
  const nums = args.split(/\s+/).filter(Boolean);
  const w = nums[0] === undefined ? 25 : clampInt(nums[0], 1, 180);
  const b = nums[1] === undefined ? 5 : clampInt(nums[1], 0, 60);
  if (w == null || b == null) return reply(chatId, 'Формат: /pomo [работа, мин] [отдых, мин]\nПример: /pomo 25 5');
  const at = store.now();
  store.setTimer(user.id, 'bot', { endsAt: at + w * 60000, phase: 'work', mode: 'Telegram', workMin: w, breakMin: b, startedAt: at });
  await reply(chatId, `🍅 Таймер запущен: ${w} мин работы${b ? `, затем ${b} мин отдыха` : ''}. Закончится в ${T.hhmm(at + w * 60000, user.tz)}.\nОстановить: /stop`);
}
async function cmdStop({ user, chatId }) {
  const t = store.getTimer(user.id, 'bot');
  if (!t) return reply(chatId, 'Таймер из бота не запущен.');
  store.clearTimer(user.id, 'bot');
  let extra = '';
  if (t.phase === 'work') {
    const mins = Math.min(t.workMin, Math.floor((store.now() - t.startedAt) / 60000));
    if (mins > 0) { store.addStudy(user.id, store.todayOf(user), mins * 60000); extra = ` Засчитано ${mins} мин.`; }
  }
  await reply(chatId, `⏹ Таймер остановлен.${extra}`);
}

async function cmdNotify({ user, chatId, args }) {
  const a = args.toLowerCase();
  if (a !== 'on' && a !== 'off' && a !== 'вкл' && a !== 'выкл') {
    return reply(chatId, `Напоминания сейчас: ${user.settings.tgOn ? 'включены' : 'выключены'}.\nИзменить: /notify on или /notify off`);
  }
  const on = a === 'on' || a === 'вкл';
  store.updateSettings(user.id, { tgOn: on });
  await reply(chatId, on ? '🔔 Напоминания включены.' : '🔕 Напоминания, сводка и сообщения таймера выключены. Включить: /notify on');
}
async function cmdDigest({ user, chatId, args }) {
  const a = args.toLowerCase();
  const st = user.settings;
  if (!a) return reply(chatId, `Утренняя сводка: ${st.digest ? 'включена, ' + st.digestTime : 'выключена'}.\nИзменить: /digest on, /digest off или /digest 07:30`);
  if (a === 'on' || a === 'вкл') { store.updateSettings(user.id, { digest: true }); return reply(chatId, `☀️ Сводка включена, придёт в ${st.digestTime}.`); }
  if (a === 'off' || a === 'выкл') { store.updateSettings(user.id, { digest: false }); return reply(chatId, 'Утренняя сводка выключена.'); }
  const t = parseTimeWord(a);
  if (!t) return reply(chatId, 'Не понял. Примеры: /digest on, /digest off, /digest 07:30');
  store.updateSettings(user.id, { digest: true, digestTime: t });
  await reply(chatId, `☀️ Сводка будет приходить в ${t}.`);
}
async function cmdTz({ user, chatId, args }) {
  if (!args) return reply(chatId, `Часовой пояс сейчас: ${user.tz}. Изменить: /tz Europe/Moscow (список названий: «IANA time zones»).`);
  if (!T.validTz(args)) return reply(chatId, 'Не знаю такой пояс. Пример: Europe/Moscow, Asia/Yekaterinburg, Europe/Kaliningrad');
  store.updateSettings(user.id, { tz: args });
  await reply(chatId, `🌍 Часовой пояс: ${args} (сейчас у тебя ${T.hhmm(store.now(), args)}).`);
}

const COMMANDS = {
  help: ({ chatId }) => reply(chatId, HELP),
  today: (c) => sendDay(c, 0),
  tomorrow: (c) => sendDay(c, 1),
  week: cmdWeek,
  done: (c) => cmdMark(c, true),
  undo: (c) => cmdMark(c, false),
  add: cmdAdd,
  plan: cmdPlan,
  shift: cmdShift,
  stats: cmdStats,
  pomo: cmdPomo,
  stop: cmdStop,
  notify: cmdNotify,
  digest: cmdDigest,
  tz: cmdTz,
  site: ({ user, chatId }) => sendLoginLink(user, chatId, '🌐 Вход на сайт:'),
};

/* ---------- обработка апдейтов ---------- */
async function handleMessage(msg) {
  if (!msg || !msg.from || !msg.chat || msg.chat.type !== 'private') return;
  const text = (msg.text || '').trim();
  const chatId = msg.chat.id;
  const m = text.match(/^\/([A-Za-z_]+)(?:@\w+)?(?:\s+([\s\S]*))?$/);
  let user = store.getUserByTg(msg.from.id);
  if (!m) {
    if (user) await reply(chatId, 'Я понимаю команды, список: /help');
    else await reply(chatId, 'Нажми /start, чтобы начать.');
    return;
  }
  const cmd = m[1].toLowerCase();
  const args = (m[2] || '').trim();
  if (cmd === 'start') return cmdStart(msg, user, args);
  if (!user) return reply(chatId, 'Сначала нажми /start (если бот закрытый — отправь /start и код приглашения).');
  const name = [msg.from.first_name, msg.from.last_name].filter(Boolean).join(' ');
  if (name !== user.name || (msg.from.username || '') !== user.username) store.touchProfile(user.id, { name, username: msg.from.username || '' });
  const h = COMMANDS[cmd];
  if (!h) return reply(chatId, 'Не знаю такой команды. Список: /help');
  await h({ user, chatId, args, msg });
}

async function handleCallback(cb) {
  const answer = (text) => tg.call('answerCallbackQuery', { callback_query_id: cb.id, text }).catch(() => {});
  const user = cb.from && store.getUserByTg(cb.from.id);
  if (!user || !cb.data) return answer();
  if (cb.data.startsWith('t:')) {
    const task = store.getTask(user.id, cb.data.slice(2));
    if (!task || task.type === 'note') return answer('Задача не найдена');
    store.patchTask(user.id, task.id, { done: !task.done });
    const r = F.renderDay(user, task.date);
    if (cb.message) {
      await tg.call('editMessageText', {
        chat_id: cb.message.chat.id, message_id: cb.message.message_id, text: r.text,
        reply_markup: r.keyboard || { inline_keyboard: [] },
      }).catch((e) => { if (!/not modified/i.test(e.message)) console.error('[bot] edit:', e.message); });
    }
    return answer(task.done ? 'Снято' : 'Выполнено ✅');
  }
  return answer();
}

async function handleUpdate(u) {
  try {
    if (u.message) await handleMessage(u.message);
    else if (u.callback_query) await handleCallback(u.callback_query);
  } catch (e) { console.error('[bot] handler error:', e); }
}

async function init() {
  me = await tg.call('getMe');
  try { await tg.call('setMyCommands', { commands: COMMAND_LIST }); } catch (e) { console.error('[bot] setMyCommands:', e.message); }
  console.log(`[bot] @${me.username} запущен`);
}

async function loop() {
  while (running) {
    try {
      if (!me) await init();
      const updates = await tg.call('getUpdates', { offset, timeout: 25, allowed_updates: ['message', 'callback_query'] }, { timeoutMs: 40000 });
      for (const u of updates) { offset = u.update_id + 1; await handleUpdate(u); }
    } catch (e) {
      console.error('[bot] polling:', e.message);
      await tg.sleep(5000);
    }
  }
}

function start() {
  if (!cfg.botToken) { console.warn('[bot] BOT_TOKEN не задан — бот отключён'); return; }
  running = true;
  loop();
}
function stop() { running = false; }

module.exports = { start, stop, username, handleUpdate, parseAdd };
