'use strict';
// Автообновление расписания и экзаменов с сайта вуза + сообщения об изменениях в Telegram.
// Снимок последней версии хранится в sched_sync. Первая проверка только запоминает «как есть» (без сообщений).
// Дальше при каждом изменении на сайте пары, загруженные с сайта (id вида h0, h1…), заменяются новыми,
// а добавленные вручную остаются как были.
const cfg = require('./config');
const T = require('./time');
const { db } = require('./db');
const store = require('./store');
const herzen = require('./herzen');
const tg = require('./tg');

const DOW = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
const [QUIET_FROM, QUIET_TO] = (/^(\d{1,2})-(\d{1,2})$/.exec(cfg.syncQuiet || '') || [0, 0, 0]).slice(1).map(Number);   // ночью сообщения не шлём
const RETRY_MS = 30 * 60 * 1000;
const MAX_LINES = 14;
const J = (s, d) => { try { return s ? JSON.parse(s) : d; } catch { return d; } };

const rowOf = (userId) => db.prepare('SELECT * FROM sched_sync WHERE user_id=?').get(userId);
const reset = (userId) => db.prepare('DELETE FROM sched_sync WHERE user_id=?').run(userId);
function info(user) {
  const r = rowOf(user.id);
  if (!r || r.group_id !== user.settings.groupId) return { on: !!(user.settings.groupId && user.settings.autoSync), at: 0, changedAt: 0, error: '' };
  return { on: !!(user.settings.groupId && user.settings.autoSync), at: r.at, changedAt: r.changed_at, error: r.error };
}

/* ---------- сравнение ---------- */
const lessonBase = (l) => [l.dow, l.start, l.title, l.week || '', JSON.stringify(l.ranges || [])].join('|');
const lessonFull = (l) => [lessonBase(l), l.end, l.kind || '', l.room || '', l.teacher || ''].join('|');
const lessonLabel = (l) => `${DOW[l.dow]} ${l.start}–${l.end} ${l.title}${l.week ? ` (${l.week})` : ''}`;
const lessonExtra = (l) => [l.kind, l.room, l.teacher].filter(Boolean).join(' · ');

function diffLessons(oldL, newL) {
  const oldMap = new Map(oldL.map((l) => [lessonBase(l), l]));
  const newMap = new Map(newL.map((l) => [lessonBase(l), l]));
  const lines = [];
  for (const [k, n] of newMap) {
    const o = oldMap.get(k);
    if (!o) { lines.push(`➕ ${lessonLabel(n)}${lessonExtra(n) ? ' · ' + lessonExtra(n) : ''}`); continue; }
    if (lessonFull(o) !== lessonFull(n)) {
      const bits = [];
      if (o.end !== n.end) bits.push(`до ${o.end} → ${n.end}`);
      if ((o.room || '') !== (n.room || '')) bits.push(`ауд. ${o.room || '—'} → ${n.room || '—'}`);
      if ((o.teacher || '') !== (n.teacher || '')) bits.push(`преп. ${o.teacher || '—'} → ${n.teacher || '—'}`);
      if ((o.kind || '') !== (n.kind || '')) bits.push(`${o.kind || '—'} → ${n.kind || '—'}`);
      lines.push(`✏️ ${lessonLabel(n)}: ${bits.join('; ')}`);
    }
  }
  for (const [k, o] of oldMap) if (!newMap.has(k)) lines.push(`➖ ${lessonLabel(o)}`);
  return lines;
}

const dm = (d) => `${d.slice(8)}.${d.slice(5, 7)}`;
const examBase = (e) => [e.date, e.title, e.kind].join('|');
const examFull = (e) => [examBase(e), e.start, e.end, e.room, e.teacher].join('|');
const examLabel = (e) => `${dm(e.date)}${e.start ? ' ' + e.start : ''} ${e.title}${e.kind && e.kind !== e.title ? ' · ' + e.kind : ''}${e.room ? ' · ' + e.room : ''}`;
function diffExams(oldE, newE) {
  const oldMap = new Map(oldE.map((e) => [examBase(e), e]));
  const newMap = new Map(newE.map((e) => [examBase(e), e]));
  const lines = [];
  for (const [k, n] of newMap) {
    const o = oldMap.get(k);
    if (!o) lines.push(`➕ ${examLabel(n)}`);
    else if (examFull(o) !== examFull(n)) lines.push(`✏️ ${examLabel(n)} (было: ${o.start || 'время не указано'}${o.room ? ', ' + o.room : ''})`);
  }
  for (const [k, o] of oldMap) if (!newMap.has(k)) lines.push(`➖ ${examLabel(o)}`);
  return lines;
}

const clip = (lines) => (lines.length > MAX_LINES ? [...lines.slice(0, MAX_LINES), `…и ещё ${lines.length - MAX_LINES}`] : lines);

/* ---------- проверка одного пользователя ---------- */
const save = (userId, patch) => {
  const cur = rowOf(userId) || {};
  const row = { group_id: '', at: 0, next_at: 0, lessons: '', exams: '', exams_at: 0, changed_at: 0, error: '', ...cur, ...patch };
  db.prepare(`INSERT INTO sched_sync(user_id,group_id,at,next_at,lessons,exams,exams_at,changed_at,error) VALUES(?,?,?,?,?,?,?,?,?)
    ON CONFLICT(user_id) DO UPDATE SET group_id=excluded.group_id, at=excluded.at, next_at=excluded.next_at, lessons=excluded.lessons,
      exams=excluded.exams, exams_at=excluded.exams_at, changed_at=excluded.changed_at, error=excluded.error`)
    .run(userId, row.group_id, row.at, row.next_at, row.lessons, row.exams, row.exams_at, row.changed_at, row.error);
};

async function check(user, at = Date.now(), cache = new Map()) {
  const st = user.settings, gid = st.groupId;
  let row = rowOf(user.id);
  if (row && row.group_id !== gid) { reset(user.id); row = null; }
  const today = store.todayOf(user);
  const next = at + cfg.syncEveryMs;
  const memo = async (key, fn) => { if (!cache.has(key)) cache.set(key, fn().then((v) => ({ v }), (e) => ({ e }))); const r = await cache.get(key); if (r.e) throw r.e; return r.v; };

  let lessons = null, exams = null, error = '';
  try { lessons = await memo('c' + gid, () => herzen.classes(gid, { fresh: true })); } catch (e) { error = e.message; }
  try { exams = await memo('x' + gid, () => herzen.exams(gid, today, { fresh: true })); } catch (e) { error = error || e.message; }
  if (!lessons && !exams) { save(user.id, { group_id: gid, at, next_at: at + RETRY_MS, error: error.slice(0, 200) }); return null; }

  const prevL = row && row.lessons ? J(row.lessons, null) : null;
  const prevE = row && row.exams ? J(row.exams, null) : null;
  const lines = [];
  let applied = false;

  if (lessons) {
    // сайт вернул заметно меньше пар, чем было — считаем сбоем сайта, а не реальным изменением
    const glitch = prevL && prevL.length >= 4 && lessons.length < prevL.length / 3;
    if (glitch) error = 'Сайт вернул подозрительно мало пар — пропускаю обновление';
    else if (prevL) {
      const d = diffLessons(prevL, lessons);
      if (d.length) {
        lines.push(...d);
        const own = (st.schedule || []).filter((c) => !/^h\d+$/.test(String(c.id)));
        store.updateSettings(user.id, { schedule: [...herzen.toSchedule(lessons), ...own].slice(0, 150) });
        applied = true;
      }
    }
  }
  const examLines = exams && prevE ? diffExams(prevE, exams) : [];

  save(user.id, {
    group_id: gid, at, next_at: next, error,
    lessons: lessons && !(error && /подозрительно/.test(error)) ? JSON.stringify(lessons) : (row ? row.lessons : ''),
    exams: exams ? JSON.stringify(exams) : (row ? row.exams : ''), exams_at: exams ? at : (row ? row.exams_at : 0),
    changed_at: lines.length || examLines.length ? at : (row ? row.changed_at : 0),
  });

  if ((lines.length || examLines.length) && st.tgOn) {
    const parts = [`🔔 Изменения на сайте вуза${st.group ? ` (${st.group})` : ''}`];
    if (lines.length) parts.push('', 'Пары:', ...clip(lines));
    if (examLines.length) parts.push('', '🎓 Экзамены и зачёты:', ...clip(examLines));
    if (applied) parts.push('', 'Расписание в календаре обновлено автоматически.');
    await tg.send(user.tgId, parts.join('\n'));
  }
  return { lines, examLines, applied };
}

// вызывается планировщиком: проверяет тех, у кого подошло время
async function tick(at = Date.now()) {
  const cache = new Map();
  for (const user of store.allUsers()) {
    const st = user.settings;
    if (!st.groupId || !st.autoSync) continue;
    const row = rowOf(user.id);
    if (row && row.group_id === st.groupId && row.next_at > at) continue;
    const h = Number(T.hhmm(at, user.tz).slice(0, 2));
    if (QUIET_FROM !== QUIET_TO && (QUIET_FROM > QUIET_TO ? h >= QUIET_FROM || h < QUIET_TO : h >= QUIET_FROM && h < QUIET_TO)) { if (row && row.group_id === st.groupId) continue; }   // первая проверка (снимок) — в любое время
    try { await check(user, at, cache); } catch (e) { console.error(`[sync] ${user.id}:`, e.message); }
  }
}

// экзамены для страницы: из снимка; если снимка нет или он старый — запрашиваем
async function examsFor(user, { force = false } = {}) {
  const gid = user.settings.groupId;
  if (!gid) return { groupId: '', exams: [], at: 0 };
  const row = rowOf(user.id);
  const have = row && row.group_id === gid && row.exams ? J(row.exams, []) : null;
  if (have && !force && Date.now() - row.exams_at < 6 * 3600 * 1000) return { groupId: gid, exams: have, at: row.exams_at };
  try {
    const list = await herzen.exams(gid, store.todayOf(user), { fresh: force });
    if (row && row.group_id === gid) save(user.id, { exams: JSON.stringify(list), exams_at: Date.now() });
    return { groupId: gid, exams: list, at: Date.now() };
  } catch (e) {
    if (have) return { groupId: gid, exams: have, at: row.exams_at, stale: true };
    throw e;
  }
}

module.exports = { tick, check, info, reset, examsFor, diffLessons, diffExams };
