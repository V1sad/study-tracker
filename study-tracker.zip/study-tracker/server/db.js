'use strict';
// SQLite через встроенный модуль node:sqlite (Node.js 22.13+), без внешних пакетов.
const fs = require('fs');
const path = require('path');
const cfg = require('./config');

const { DatabaseSync } = require('node:sqlite');

fs.mkdirSync(path.dirname(cfg.dbPath), { recursive: true });
const db = new DatabaseSync(cfg.dbPath);
db.exec('PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;');

db.exec(`
CREATE TABLE IF NOT EXISTS users(
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tg_id TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL DEFAULT '',
  username TEXT NOT NULL DEFAULT '',
  tz TEXT NOT NULL,
  settings TEXT NOT NULL,
  last_digest TEXT NOT NULL DEFAULT '',
  created_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS sessions(
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS logins(
  code TEXT PRIMARY KEY,
  user_id INTEGER,
  expires_at INTEGER NOT NULL
);
CREATE TABLE IF NOT EXISTS tasks(
  id TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  time TEXT NOT NULL DEFAULT '',
  title TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'task',
  cat TEXT NOT NULL DEFAULT 'study',
  note TEXT NOT NULL DEFAULT '',
  done INTEGER NOT NULL DEFAULT 0,
  remind TEXT NOT NULL DEFAULT '[]',
  sent TEXT NOT NULL DEFAULT '{}',
  spent_ms INTEGER NOT NULL DEFAULT 0,
  est INTEGER NOT NULL DEFAULT 0,
  plan INTEGER NOT NULL DEFAULT 0,
  plan_idx INTEGER NOT NULL DEFAULT 0,
  plan_off INTEGER NOT NULL DEFAULT 0,
  plan_kind TEXT NOT NULL DEFAULT '',
  plan_gen INTEGER NOT NULL DEFAULT 0,
  created_at INTEGER NOT NULL
);
CREATE INDEX IF NOT EXISTS tasks_user_date ON tasks(user_id, date);
CREATE TABLE IF NOT EXISTS study(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  date TEXT NOT NULL,
  ms INTEGER NOT NULL DEFAULT 0,
  pomos INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, date)
);
CREATE TABLE IF NOT EXISTS timers(
  user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  kind TEXT NOT NULL,
  ends_at INTEGER NOT NULL,
  phase TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT '',
  work_min INTEGER NOT NULL DEFAULT 0,
  break_min INTEGER NOT NULL DEFAULT 0,
  task_id TEXT NOT NULL DEFAULT '',
  started_at INTEGER NOT NULL DEFAULT 0,
  PRIMARY KEY(user_id, kind)
);
`);

function tx(fn) {
  db.exec('BEGIN');
  try { const r = fn(); db.exec('COMMIT'); return r; }
  catch (e) { try { db.exec('ROLLBACK'); } catch { /* ignore */ } throw e; }
}

module.exports = { db, tx };
