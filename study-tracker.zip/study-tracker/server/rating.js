'use strict';
// Рейтинг в духе Duolingo: недельная таблица по очкам (минуты учёбы). Виден только тем, кто сам включил участие,
// и только ник + фото + очки. Настоящее имя и Telegram-id наружу не отдаются: у каждого есть непрозрачный pid.
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const T = require('./time');
const { db } = require('./db');
const store = require('./store');
const tg = require('./tg');

const DAY_CAP_MIN = 600;                  // не больше 10 часов в день в зачёт
const RATING_TZ = cfg.defaultTz;          // недели считаем в одном часовом поясе для всех
const TOP = 50;
const AVATAR_TTL = 24 * 3600 * 1000;
const dir = path.join(path.dirname(cfg.dbPath), 'avatars');

const SECRET = process.env.SESSION_SECRET || cfg.botToken || 'dev-secret';
const pidOf = (userId) => crypto.createHmac('sha256', SECRET).update('rating:' + userId).digest('hex').slice(0, 12);

function periodStart(scope, now = Date.now()) {
  const today = T.dateKey(now, RATING_TZ);
  if (scope === 'all') return '0000-01-01';
  if (scope === 'month') return T.addDays(today, -29);
  return T.addDays(today, -((T.dow(today) + 6) % 7));   // понедельник текущей недели
}

let cache = { at: 0, users: [] };
function participants() {
  if (Date.now() - cache.at < 15000) return cache.users;
  const users = store.allUsers().filter((u) => u.settings && u.settings.rating && u.settings.rating.on).map((u) => ({
    id: u.id, tgId: u.tgId, username: u.username, pid: pidOf(u.id), r: u.settings.rating,
  }));
  cache = { at: Date.now(), users };
  return users;
}
const invalidate = () => { cache.at = 0; };

const displayName = (p) => p.r.nick || (p.username ? '@' + p.username : 'Студент ' + p.pid.slice(0, 4));

function board(scope, meId) {
  const from = periodStart(scope);
  const users = participants();
  const ids = new Map(users.map((u) => [u.id, u]));
  const xp = new Map();
  if (ids.size) {
    for (const r of db.prepare('SELECT user_id, ms FROM study WHERE date>=? AND ms>0').all(from)) {
      if (!ids.has(r.user_id)) continue;
      xp.set(r.user_id, (xp.get(r.user_id) || 0) + Math.min(Math.round(r.ms / 60000), DAY_CAP_MIN));
    }
  }
  const rows = users.map((u) => ({ u, xp: xp.get(u.id) || 0 }))
    .filter((r) => r.xp > 0 || r.u.id === meId)
    .sort((a, b) => b.xp - a.xp || a.u.id - b.u.id);
  let rank = 0, prev = null, shown = 0;
  const ranked = rows.map((r, i) => { if (r.xp !== prev) { rank = i + 1; prev = r.xp; } return { ...r, rank }; });
  const entries = ranked.filter((r) => r.xp > 0).slice(0, TOP).map((r) => ({
    rank: r.rank, name: displayName(r.u), xp: r.xp, pid: r.u.pid, photo: !!r.u.r.photo, me: r.u.id === meId,
  }));
  const mine = ranked.find((r) => r.u.id === meId);
  shown = ranked.filter((r) => r.xp > 0).length;
  return {
    scope, from, total: shown,
    entries,
    me: mine ? { on: true, rank: mine.xp > 0 ? mine.rank : null, xp: mine.xp, name: displayName(mine.u), pid: mine.u.pid } : { on: false },
  };
}

/* ---------- фото из Telegram ---------- */
const inflight = new Map();
async function fetchAvatar(u) {
  fs.mkdirSync(dir, { recursive: true });
  const file = path.join(dir, `${u.id}.jpg`), none = path.join(dir, `${u.id}.none`);
  const fresh = (f) => { try { return Date.now() - fs.statSync(f).mtimeMs < AVATAR_TTL; } catch { return false; } };
  if (fresh(file)) return file;
  if (fresh(none)) return null;
  try {
    const photos = await tg.call('getUserProfilePhotos', { user_id: Number(u.tgId), limit: 1 });
    const sizes = photos && photos.photos && photos.photos[0];
    if (!sizes || !sizes.length) { fs.writeFileSync(none, ''); return null; }
    const pick = sizes.find((s) => s.width >= 160) || sizes[sizes.length - 1];
    const info = await tg.call('getFile', { file_id: pick.file_id });
    const res = await fetch(`${cfg.tgBase}/file/bot${cfg.botToken}/${info.file_path}`);
    if (!res.ok) throw new Error('HTTP ' + res.status);
    const buf = Buffer.from(await res.arrayBuffer());
    if (buf.length > 2 * 1024 * 1024) throw new Error('слишком большой файл');
    fs.writeFileSync(file, buf);
    try { fs.unlinkSync(none); } catch { /* нет такого */ }
    return file;
  } catch (e) {
    console.error(`[rating] аватар ${u.id}: ${e.message}`);
    return fs.existsSync(file) ? file : null;     // лучше старое фото, чем ничего
  }
}
async function avatarFor(pid) {
  const u = participants().find((x) => x.pid === pid);
  if (!u || !u.r.photo) return null;
  if (!inflight.has(u.id)) inflight.set(u.id, fetchAvatar(u).finally(() => inflight.delete(u.id)));
  const file = await inflight.get(u.id);
  return file ? fs.readFileSync(file) : null;
}

module.exports = { board, avatarFor, invalidate, pidOf, periodStart };
