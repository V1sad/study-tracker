'use strict';
// Слой данных: пользователи, задачи, учёт времени, таймеры, сессии, план.
const crypto = require('crypto');
const cfg = require('./config');
const { db, tx } = require('./db');
const T = require('./time');
const S = require('./settings');
const planLib = require('./plan');

const J = (s, d) => { try { return JSON.parse(s); } catch { return d; } };
const now = () => Date.now();
const rid = () => crypto.randomBytes(6).toString('base64url');
const token = (n = 32) => crypto.randomBytes(n).toString('base64url');

/* ---------------- пользователи ---------------- */
const userFrom = (r) => r && ({
  id: r.id, tgId: r.tg_id, name: r.name, username: r.username, tz: r.tz,
  settings: S.merge(J(r.settings, {})), lastDigest: r.last_digest, createdAt: r.created_at,
});
const getUser = (id) => userFrom(db.prepare('SELECT * FROM users WHERE id=?').get(id));
const getUserByTg = (tgId) => userFrom(db.prepare('SELECT * FROM users WHERE tg_id=?').get(String(tgId)));
const allUsers = () => db.prepare('SELECT * FROM users').all().map(userFrom);

function createUser({ tgId, name, username }) {
  db.prepare('INSERT INTO users(tg_id,name,username,tz,settings,created_at) VALUES(?,?,?,?,?,?)')
    .run(String(tgId), String(name || '').slice(0, 80), String(username || '').slice(0, 64), cfg.defaultTz, JSON.stringify(S.defaultSettings()), now());
  return getUserByTg(tgId);
}
function touchProfile(userId, { name, username }) {
  db.prepare('UPDATE users SET name=?, username=? WHERE id=?').run(String(name || '').slice(0, 80), String(username || '').slice(0, 64), userId);
}
function saveSettings(userId, settings) {
  db.prepare('UPDATE users SET settings=? WHERE id=?').run(JSON.stringify(settings), userId);
}
function updateSettings(userId, input) {
  const u = getUser(userId);
  const next = S.sanitize(input, u.settings);
  saveSettings(userId, next);
  if (input && input.tz !== undefined && T.validTz(input.tz)) db.prepare('UPDATE users SET tz=? WHERE id=?').run(input.tz, userId);
  return getUser(userId);
}
function setLastDigest(userId, key) { db.prepare('UPDATE users SET last_digest=? WHERE id=?').run(key, userId); }
function deleteUser(userId) { db.prepare('DELETE FROM users WHERE id=?').run(userId); }
const todayOf = (user, at = now()) => T.dateKey(at, user.tz);

/* ---------------- задачи ---------------- */
const taskFrom = (r) => r && ({
  id: r.id, date: r.date, time: r.time, title: r.title, type: r.type, cat: r.cat, note: r.note,
  done: !!r.done, remind: J(r.remind, []), sent: J(r.sent, {}), spentMs: r.spent_ms, est: r.est,
  plan: !!r.plan, track: r.track || 'math', planIdx: r.plan_idx, planOff: r.plan_off, planKind: r.plan_kind, planGen: r.plan_gen,
});
const getTask = (userId, id) => taskFrom(db.prepare('SELECT * FROM tasks WHERE id=? AND user_id=?').get(String(id), userId));
const listTasks = (userId) => db.prepare('SELECT * FROM tasks WHERE user_id=? ORDER BY date, time, created_at').all(userId).map(taskFrom);
const dayTasks = (userId, date) => db.prepare("SELECT * FROM tasks WHERE user_id=? AND date=? ORDER BY (time='') DESC, time, created_at").all(userId, date).map(taskFrom);

const TYPES = ['task', 'lesson', 'note'];
const CATS = ['math', 'java', 'study', 'other'];

// Проверка и нормализация входных данных задачи. partial=true — для PATCH.
function cleanTask(inp, { partial = false } = {}) {
  const o = {};
  const i = inp && typeof inp === 'object' ? inp : {};
  const fail = (m) => { const e = new Error(m); e.status = 400; throw e; };
  if (!partial || 'title' in i) {
    const t = String(i.title ?? '').trim();
    if (!t) fail('Нужно название');
    o.title = t.slice(0, 160);
  }
  if (!partial || 'date' in i) {
    if (!T.validDate(i.date)) fail('Неверная дата');
    o.date = i.date;
  }
  if ('time' in i || !partial) {
    const t = i.time == null ? '' : String(i.time);
    if (t && !S.HHMM.test(t)) fail('Неверное время');
    o.time = t;
  }
  if ('type' in i || !partial) {
    const t = i.type == null ? 'task' : i.type;
    if (!TYPES.includes(t)) fail('Неверный тип');
    o.type = t;
  }
  if ('cat' in i || !partial) {
    const c = i.cat == null ? 'study' : i.cat;
    if (!CATS.includes(c)) fail('Неверная категория');
    o.cat = c;
  }
  if ('note' in i || !partial) o.note = String(i.note ?? '').slice(0, 2000);
  if ('est' in i || !partial) {
    const n = Math.round(Number(i.est || 0));
    o.est = Number.isFinite(n) && n >= 0 && n <= 1000 ? n : 0;
  }
  if ('remind' in i || !partial) o.remind = S.cleanRemind(i.remind || []);
  if ('done' in i) o.done = !!i.done;
  if (o.type === 'note') o.done = false;
  return o;
}

function insertTask(userId, t) {
  const id = rid();
  db.prepare(`INSERT INTO tasks(id,user_id,date,time,title,type,cat,note,done,remind,sent,spent_ms,est,plan,plan_idx,plan_off,plan_kind,plan_gen,track,created_at)
              VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)`)
    .run(id, userId, t.date, t.time || '', t.title, t.type || 'task', t.cat || 'study', t.note || '', t.done ? 1 : 0,
      JSON.stringify(t.remind || []), '{}', 0, t.est || 0, t.plan ? 1 : 0, t.planIdx || 0, t.planOff || 0, t.planKind || '', t.planGen || 0, t.track || 'math', now());
  return getTask(userId, id);
}

function patchTask(userId, id, p) {
  const cur = getTask(userId, id);
  if (!cur) return null;
  const sets = [], vals = [];
  const set = (c, v) => { sets.push(c + '=?'); vals.push(v); };
  if ('title' in p) set('title', p.title);
  if ('date' in p) set('date', p.date);
  if ('time' in p) set('time', p.time);
  if ('type' in p) set('type', p.type);
  if ('cat' in p) set('cat', p.cat);
  if ('note' in p) set('note', p.note);
  if ('est' in p) set('est', p.est);
  if ('remind' in p) set('remind', JSON.stringify(p.remind));
  if ('done' in p) set('done', p.done ? 1 : 0);
  const resched = ('date' in p && p.date !== cur.date) || ('time' in p && p.time !== cur.time)
    || ('remind' in p && JSON.stringify(p.remind) !== JSON.stringify(cur.remind));
  if (resched) set('sent', '{}');
  if (!sets.length) return cur;
  db.prepare(`UPDATE tasks SET ${sets.join(',')} WHERE id=? AND user_id=?`).run(...vals, id, userId);
  return getTask(userId, id);
}
function setSent(taskId, sent) { db.prepare('UPDATE tasks SET sent=? WHERE id=?').run(JSON.stringify(sent), taskId); }
function deleteTask(userId, id) {
  return db.prepare('DELETE FROM tasks WHERE id=? AND user_id=?').run(String(id), userId).changes > 0;
}

/* ---------------- учёт времени ---------------- */
function addStudy(userId, date, ms, pomos = 0) {
  db.prepare(`INSERT INTO study(user_id,date,ms,pomos) VALUES(?,?,?,?)
              ON CONFLICT(user_id,date) DO UPDATE SET ms=ms+excluded.ms, pomos=pomos+excluded.pomos`)
    .run(userId, date, Math.max(0, Math.round(ms)), pomos);
}
function addTaskSpent(userId, taskId, ms) {
  db.prepare('UPDATE tasks SET spent_ms=spent_ms+? WHERE id=? AND user_id=?').run(Math.max(0, Math.round(ms)), String(taskId), userId);
}
function studyMap(userId, sinceDate) {
  const out = {};
  for (const r of db.prepare('SELECT date,ms,pomos FROM study WHERE user_id=? AND date>=?').all(userId, sinceDate)) out[r.date] = { ms: r.ms, pomos: r.pomos };
  return out;
}

/* ---------------- таймеры (серверные уведомления) ---------------- */
const timerFrom = (r) => r && ({ userId: r.user_id, kind: r.kind, endsAt: r.ends_at, phase: r.phase, mode: r.mode, workMin: r.work_min, breakMin: r.break_min, taskId: r.task_id, startedAt: r.started_at });
function setTimer(userId, kind, t) {
  db.prepare(`INSERT INTO timers(user_id,kind,ends_at,phase,mode,work_min,break_min,task_id,started_at) VALUES(?,?,?,?,?,?,?,?,?)
              ON CONFLICT(user_id,kind) DO UPDATE SET ends_at=excluded.ends_at,phase=excluded.phase,mode=excluded.mode,work_min=excluded.work_min,break_min=excluded.break_min,task_id=excluded.task_id,started_at=excluded.started_at`)
    .run(userId, kind, Math.round(t.endsAt), t.phase, String(t.mode || '').slice(0, 40), t.workMin | 0, t.breakMin | 0, String(t.taskId || ''), t.startedAt || now());
}
const getTimer = (userId, kind) => timerFrom(db.prepare('SELECT * FROM timers WHERE user_id=? AND kind=?').get(userId, kind));
const clearTimer = (userId, kind) => db.prepare('DELETE FROM timers WHERE user_id=? AND kind=?').run(userId, kind).changes > 0;
const dueTimers = (at) => db.prepare('SELECT * FROM timers WHERE ends_at<=?').all(at).map(timerFrom);

/* ---------------- вход и сессии ---------------- */
const LOGIN_TTL = 10 * 60 * 1000;
const SESSION_TTL = 30 * 24 * 3600 * 1000;

function newLogin(userId = null) {
  db.prepare('DELETE FROM logins WHERE expires_at<?').run(now());
  const code = token(12);
  db.prepare('INSERT INTO logins(code,user_id,expires_at) VALUES(?,?,?)').run(code, userId, now() + LOGIN_TTL);
  return code;
}
function bindLogin(code, userId) {
  return db.prepare('UPDATE logins SET user_id=? WHERE code=? AND expires_at>? AND user_id IS NULL').run(userId, String(code), now()).changes > 0;
}
// возвращает id пользователя и сразу «сжигает» код
function consumeLogin(code) {
  return tx(() => {
    const r = db.prepare('SELECT user_id, expires_at FROM logins WHERE code=?').get(String(code));
    if (!r || r.expires_at < now()) return null;
    if (r.user_id == null) return 'pending';
    db.prepare('DELETE FROM logins WHERE code=?').run(String(code));
    return r.user_id;
  });
}
function createSession(userId) {
  const t = token(32);
  db.prepare('DELETE FROM sessions WHERE expires_at<?').run(now());
  db.prepare('INSERT INTO sessions(token,user_id,expires_at) VALUES(?,?,?)').run(t, userId, now() + SESSION_TTL);
  return t;
}
function sessionUser(t) {
  if (!t) return null;
  const r = db.prepare('SELECT user_id, expires_at FROM sessions WHERE token=?').get(String(t));
  if (!r || r.expires_at < now()) return null;
  if (r.expires_at - now() < SESSION_TTL - 24 * 3600 * 1000) db.prepare('UPDATE sessions SET expires_at=? WHERE token=?').run(now() + SESSION_TTL, t);
  return getUser(r.user_id);
}
const destroySession = (t) => db.prepare('DELETE FROM sessions WHERE token=?').run(String(t || ''));

/* ---------------- план ---------------- */
function latestGen(userId) {
  return db.prepare('SELECT COALESCE(MAX(plan_gen),0) g FROM tasks WHERE user_id=? AND plan=1').get(userId).g;
}
const hasJava = (user) => !!user && cfg.javaUsers.some((x) => x === String(user.username || '').toLowerCase() || x === String(user.tgId));
const tracksOf = (user) => (hasJava(user) ? ['math', 'java'] : ['math']);
function trackOf(user, t) {
  const track = t === 'java' ? 'java' : 'math';
  if (track === 'java' && !hasJava(user)) { const e = new Error('Java-трек недоступен для этого аккаунта'); e.status = 403; throw e; }
  return track;
}
function generatePlan(user, { startDate, fromDay, track: tr }) {
  const track = trackOf(user, tr);
  const len = planLib.TRACKS[track].topics.length;
  const from = Math.min(len, Math.max(1, Math.round(Number(fromDay) || 1))) - 1;
  return tx(() => {
    const gen = latestGen(user.id) + 1;
    db.prepare('DELETE FROM tasks WHERE user_id=? AND plan=1 AND done=0 AND track=?').run(user.id, track);
    const items = planLib.buildPlan({ track, startDate, fromIdx: from, settings: user.settings[planLib.TRACKS[track].settingsKey], remind: user.settings.defaultRemind, gen });
    for (const it of items) insertTask(user.id, it);
    return { count: items.length, gen, track };
  });
}
// track не указан — сдвигаем все треки пользователя (каждый независимо)
function shiftPlan(user, tr) {
  const today = todayOf(user);
  const tracks = tr ? [trackOf(user, tr)] : tracksOf(user);
  return tx(() => {
    let moved = 0, firstDay = 0;
    const upd = db.prepare("UPDATE tasks SET date=?, sent='{}' WHERE id=?");
    for (const track of tracks) {
      const pending = db.prepare('SELECT id, plan_off FROM tasks WHERE user_id=? AND plan=1 AND done=0 AND track=?').all(user.id, track);
      if (!pending.length) continue;
      const k = Math.min(...pending.map((p) => p.plan_off));
      for (const p of pending) upd.run(T.addDays(today, p.plan_off - k), p.id);
      moved += pending.length;
      if (!firstDay) firstDay = k + 1;
    }
    return moved ? { moved, firstDay, start: today } : null;
  });
}
function planSummary(userId, track = 'math') {
  const gen = db.prepare('SELECT COALESCE(MAX(plan_gen),0) g FROM tasks WHERE user_id=? AND plan=1 AND track=?').get(userId, track).g;
  if (!gen) return null;
  const rows = db.prepare('SELECT * FROM tasks WHERE user_id=? AND plan=1 AND track=? AND plan_gen=? ORDER BY date,time').all(userId, track, gen).map(taskFrom);
  const topics = rows.filter((r) => r.planKind === 'topic');
  const repeats = rows.filter((r) => r.planKind === 'repeat');
  const next = rows.filter((r) => !r.done);
  return {
    track,
    total: rows.length, done: rows.filter((r) => r.done).length,
    topicsTotal: topics.length, topicsDone: topics.filter((r) => r.done).length,
    repeatsTotal: repeats.length, repeatsDone: repeats.filter((r) => r.done).length,
    next,
  };
}

/* ---------------- статистика ---------------- */
function streakFor(userId, today) {
  const days = new Set(db.prepare("SELECT DISTINCT date FROM tasks WHERE user_id=? AND done=1 AND type!='note'").all(userId).map((r) => r.date));
  let k = today, n = 0;
  if (!days.has(k)) k = T.addDays(k, -1);
  while (days.has(k)) { n++; k = T.addDays(k, -1); }
  return n;
}
function statsFor(user) {
  const today = todayOf(user);
  const since = T.addDays(today, -13);
  const map = studyMap(user.id, since);
  const days = [];
  for (let i = 0; i < 14; i++) {
    const k = T.addDays(since, i);
    days.push({ date: k, ms: (map[k] && map[k].ms) || 0, pomos: (map[k] && map[k].pomos) || 0 });
  }
  const week = days.slice(7);
  return {
    days, streak: streakFor(user.id, today),
    weekMs: week.reduce((a, d) => a + d.ms, 0), weekPomos: week.reduce((a, d) => a + d.pomos, 0),
    todayMs: days[13].ms, todayPomos: days[13].pomos,
    plan: planSummary(user.id),
    javaPlan: hasJava(user) ? planSummary(user.id, 'java') : null,
  };
}

module.exports = {
  now, token, getUser, getUserByTg, allUsers, createUser, touchProfile, saveSettings, updateSettings, setLastDigest, deleteUser, todayOf,
  getTask, listTasks, dayTasks, cleanTask, insertTask, patchTask, setSent, deleteTask,
  addStudy, addTaskSpent, studyMap,
  setTimer, getTimer, clearTimer, dueTimers,
  newLogin, bindLogin, consumeLogin, createSession, sessionUser, destroySession,
  generatePlan, shiftPlan, planSummary, latestGen, hasJava, tracksOf,
  streakFor, statsFor,
};
