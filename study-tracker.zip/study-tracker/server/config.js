'use strict';
// Конфигурация из переменных окружения и файла .env (без внешних зависимостей).
const fs = require('fs');
const path = require('path');

function loadEnv(file) {
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (!(m[1] in process.env)) process.env[m[1]] = v;
  }
}
loadEnv(path.join(__dirname, '..', '.env'));

const e = process.env;
const baseUrl = (e.BASE_URL || 'http://localhost:3000').replace(/\/+$/, '');

module.exports = {
  botToken: e.BOT_TOKEN || '',
  baseUrl,
  port: Number(e.PORT) || 3000,
  host: e.HOST || '127.0.0.1',
  dbPath: e.DB_PATH || path.join(__dirname, '..', 'data', 'tracker.db'),
  invite: e.INVITE_CODE || '',
  tgBase: (e.TG_API_BASE || 'https://api.telegram.org').replace(/\/+$/, ''),
  defaultTz: e.DEFAULT_TZ || 'Europe/Moscow',
  tickMs: Number(e.TICK_MS) || 5000,
  contact: (e.CONTACT || '').trim(),          // как с тобой связаться (показывается на странице «О сервисе»), например @ник
  syncQuiet: e.SYNC_QUIET === undefined ? '22-8' : e.SYNC_QUIET,   // «22-8» — ночью не проверять; пусто — без тихих часов
  syncEveryMs: Number(e.SYNC_EVERY_MS) || 6 * 3600 * 1000,
  // Java-трек доступен только перечисленным: Telegram-ники (без @) или числовые ID через запятую
  javaUsers: (e.JAVA_USERS || '').split(',').map((x) => x.trim().replace(/^@/, '').toLowerCase()).filter(Boolean),
  secureCookie: baseUrl.startsWith('https://'),
  publicDir: path.join(__dirname, '..', 'public'),
};
