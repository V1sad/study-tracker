'use strict';
// Конфигурация из переменных окружения и файла .env (без внешних зависимостей).
const fs = require('fs');
const path = require('path');

function loadEnv(file) {
  let text = '';
  try { text = fs.readFileSync(file, 'utf8'); } catch { return; }
  for (const line of text.split(/\r?\n/)) {
    if (!line.trim() || line.trim().startsWith('#')) continue;
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$/);
    if (!m) continue;
    let v = m[2];
    if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) v = v.slice(1, -1);
    if (!(m[1] in process.env)) process.env[m[1]] = v;
  }
}
loadEnv(path.join(__dirname, '..', '.env'));

const e = process.env;
const baseUrl = (e.BASE_URL || 'http://localhost:3000').replace(/\/+$/, '');

module.exports = {
  botToken: e.BOT_TOKEN || '',
  baseUrl,
  port: Number(e.PORT) || 3000,
  host: e.HOST || '127.0.0.1',
  dbPath: e.DB_PATH || path.join(__dirname, '..', 'data', 'tracker.db'),
  invite: e.INVITE_CODE || '',
  tgBase: (e.TG_API_BASE || 'https://api.telegram.org').replace(/\/+$/, ''),
  defaultTz: e.DEFAULT_TZ || 'Europe/Moscow',
  tickMs: Number(e.TICK_MS) || 5000,
  secureCookie: baseUrl.startsWith('https://'),
  publicDir: path.join(__dirname, '..', 'public'),
};
