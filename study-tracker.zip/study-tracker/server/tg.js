'use strict';
// Минимальный клиент Telegram Bot API на встроенном fetch.
const cfg = require('./config');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function call(method, params = {}, { timeoutMs = 20000 } = {}) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(`${cfg.tgBase}/bot${cfg.botToken}/${method}`, {
      method: 'POST',
      headers: { 'content-type': 'application/json' },
      body: JSON.stringify(params),
      signal: ctrl.signal,
    });
    const j = await res.json().catch(() => ({}));
    if (!j.ok) {
      const err = new Error(j.description || `Telegram HTTP ${res.status}`);
      err.code = j.error_code || res.status;
      err.retryAfter = j.parameters && j.parameters.retry_after;
      throw err;
    }
    return j.result;
  } finally {
    clearTimeout(timer);
  }
}

// Отправка сообщения. Никогда не бросает исключение: возвращает результат или null.
async function send(chatId, text, extra = {}) {
  const body = { chat_id: chatId, text: String(text).slice(0, 4000), disable_web_page_preview: true, ...extra };
  for (let attempt = 0; attempt < 2; attempt++) {
    try {
      return await call('sendMessage', body);
    } catch (e) {
      if (e.retryAfter && attempt === 0) { await sleep(Math.min(e.retryAfter, 30) * 1000 + 300); continue; }
      console.error(`[tg] sendMessage -> ${chatId}: ${e.message}`);
      return null;
    }
  }
  return null;
}

module.exports = { call, send, sleep };
