'use strict';
// Фоновые задачи сервера: напоминания, таймеры, утренняя сводка.
// Работает независимо от того, открыт ли сайт у пользователя.
const cfg = require('./config');
const T = require('./time');
const store = require('./store');
const F = require('./format');
const tg = require('./tg');
const league = require('./league');
const sync = require('./sync');

const MODE_NAMES = { pomodoro: 'Pomodoro 25/5', deep: 'Deep Work 50/10', custom: 'Свой таймер' };
const modeName = (m) => MODE_NAMES[m] || m;

const FRESH_MS = 15 * 60 * 1000;     // напоминание старше 15 минут не отправляем (сервер был выключен)
const TIMER_FRESH_MS = 30 * 60 * 1000;
const DIGEST_WINDOW_MIN = 180;        // сводку можно отправить с опозданием до 3 часов

async function reminders(at) {
  for (const user of store.allUsers()) {
    if (!user.settings.tgOn) continue;
    const today = T.dateKey(at, user.tz);
    const dates = [T.addDays(today, -1), today, T.addDays(today, 1)];
    for (const date of dates) {
      for (const task of store.dayTasks(user.id, date)) {
        if (task.done || !task.time || !task.remind.length) continue;
        const start = T.localToMs(task.date, task.time, user.tz);
        let changed = false;
        const due = [];
        for (const m of task.remind) {
          if (task.sent[String(m)]) continue;
          const fireAt = start - m * 60000;
          if (at < fireAt) continue;
          task.sent[String(m)] = true; changed = true;
          if (at - fireAt <= FRESH_MS) due.push(m);
        }
        if (!changed) continue;
        store.setSent(task.id, task.sent);   // сначала фиксируем, потом отправляем: без повторов
        // если сработало сразу несколько порогов — отправляем одно сообщение
        if (due.length) {
          const minLeft = Math.round((start - at) / 60000);
          await tg.send(user.tgId, F.reminderText(task, minLeft));
        }
      }
    }
  }
}

async function fireTimer(t, at) {
  const user = store.getUser(t.userId);
  if (!store.clearTimer(t.userId, t.kind) || !user) return;
  const late = Math.max(0, at - t.endsAt);
  const task = t.taskId ? store.getTask(user.id, t.taskId) : null;
  const today = T.dateKey(t.endsAt, user.tz);
  const canSend = user.settings.tgOn && user.settings.notifyTimer && late <= TIMER_FRESH_MS;
  if (t.phase === 'work') {
    if (t.kind === 'bot') {
      store.addStudy(user.id, today, t.workMin * 60000, 1);          // таймер из бота сам ведёт учёт
      if (t.breakMin > 0) store.setTimer(user.id, 'bot', { endsAt: t.endsAt + t.breakMin * 60000, phase: 'break', mode: t.mode, workMin: t.workMin, breakMin: t.breakMin, startedAt: t.endsAt });
    }
    if (canSend) {
      const total = store.studyMap(user.id, today)[today];
      let text = `🍅 Таймер завершён${t.mode ? ` (${modeName(t.mode)})` : ''}\n✅ Отработано: ${t.workMin} мин`;
      if (task) text += `\n📌 Задача: ${task.title}`;
      if (total) text += `\n⏱ Всего сегодня: ${F.fmtMin(total.ms)}`;
      text += t.breakMin > 0 ? `\n☕ Отдохни ${t.breakMin} мин.` : '\nМожно начинать следующую сессию.';
      await tg.send(user.tgId, text);
    }
  } else if (canSend) {
    await tg.send(user.tgId, `☕ Перерыв закончился — пора за работу!${task ? `\n📌 ${task.title}` : ''}`);
  }
}

async function timers(at) {
  for (const t of store.dueTimers(at)) await fireTimer(t, at);
}

async function digests(at) {
  for (const user of store.allUsers()) {
    const st = user.settings;
    if (!st.tgOn || !st.digest) continue;
    const today = T.dateKey(at, user.tz);
    if (user.lastDigest === today) continue;
    const nowMin = T.toMin(T.hhmm(at, user.tz));
    const dMin = T.toMin(st.digestTime);
    if (nowMin < dMin || nowMin > dMin + DIGEST_WINDOW_MIN) continue;
    store.setLastDigest(user.id, today);
    const r = F.renderDay(user, today, 'Сегодня');
    await tg.send(user.tgId, `☀️ Доброе утро${user.name ? ', ' + user.name.split(' ')[0] : ''}!\n\n${r.text}`, r.keyboard ? { reply_markup: r.keyboard } : {});
  }
}

// итоги недели лиг: одно сообщение каждому участнику в понедельник
const syncSchedules = (at) => sync.tick(at);

async function leagues(at) {
  for (const n of league.pendingNotices(at)) {
    const user = store.getUser(n.userId);
    league.markNotified(n.userId, n.week);                  // сначала фиксируем: без повторов
    if (user && user.settings.tgOn) await tg.send(user.tgId, n.text);
  }
}

let busy = false;
let timer = null;
async function tick(at = Date.now()) {
  if (busy) return;
  busy = true;
  try {
    for (const fn of [reminders, timers, digests, leagues, syncSchedules]) {
      try { await fn(at); } catch (e) { console.error(`[scheduler] ${fn.name}:`, e); }
    }
  } finally { busy = false; }
}
function start() {
  if (!cfg.botToken) return;
  timer = setInterval(() => tick(), cfg.tickMs);
  tick();
}
function stop() { if (timer) clearInterval(timer); }

module.exports = { start, stop, tick, fireTimer };
