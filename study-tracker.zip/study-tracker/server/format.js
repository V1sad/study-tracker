'use strict';
// Текстовые представления (для бота, напоминаний и сводок).
const T = require('./time');
const store = require('./store');
const Sched = require('../public/sched');

const WD = ['вс', 'пн', 'вт', 'ср', 'чт', 'пт', 'сб'];
const WD_FULL = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
const ddmm = (k) => { const [, m, d] = k.split('-'); return `${d}.${m}`; };
const fmtMin = (ms) => { const m = Math.floor(ms / 60000); return m < 60 ? `${m} мин` : `${Math.floor(m / 60)} ч ${m % 60} мин`; };
function remindLabel(m) {
  if (m === 0) return 'в момент начала';
  if (m < 60) return `за ${m} мин`;
  return m % 60 === 0 ? `за ${m / 60} ч` : `за ${m} мин`;
}
function dayLabel(user, date) {
  const today = store.todayOf(user);
  if (date === today) return 'Сегодня';
  if (date === T.addDays(today, 1)) return 'Завтра';
  if (date === T.addDays(today, -1)) return 'Вчера';
  return WD_FULL[T.dow(date)].replace(/^./, (c) => c.toUpperCase());
}

// Текст дня + инлайн-кнопки «отметить выполненным»
function renderDay(user, date, label) {
  const lbl = label || dayLabel(user, date);
  const classes = Sched.classesOn(user.settings, date);
  const tasks = store.dayTasks(user.id, date);
  const lines = [`📅 ${lbl}, ${WD[T.dow(date)]} ${ddmm(date)}`];
  for (const c of classes) lines.push(`🎓 ${c.start}–${c.end} ${c.title}${Sched.classDetails(c) ? '\n    ' + Sched.classDetails(c) : ''}`);
  if (!tasks.length) lines.push('Задач на этот день нет. Добавить: /add');
  let n = 0;
  const buttons = [];
  for (const t of tasks) {
    if (t.type === 'note') { lines.push(`📝 ${t.time ? t.time + ' ' : ''}${t.title}`); continue; }
    n++;
    lines.push(`${n}. ${t.done ? '✅' : '⬜'} ${t.time ? t.time + ' ' : ''}${t.title}${t.est ? ` (${t.est} мин)` : ''}`);
    buttons.push({ text: `${t.done ? '↩️' : '✅'} ${n}`, callback_data: 't:' + t.id });
  }
  const countable = tasks.filter((t) => t.type !== 'note');
  if (countable.length) {
    const d = countable.filter((t) => t.done).length;
    lines.push(`\nПрогресс: ${d}/${countable.length} (${Math.round((d / countable.length) * 100)}%)`);
  }
  const rows = [];
  for (let i = 0; i < buttons.length; i += 4) rows.push(buttons.slice(i, i + 4));
  return { text: lines.join('\n'), keyboard: rows.length ? { inline_keyboard: rows } : undefined };
}

// n-я «считаемая» задача дня (как в нумерации renderDay)
function nthTask(userId, date, n) {
  const list = store.dayTasks(userId, date).filter((t) => t.type !== 'note');
  return list[n - 1] || null;
}

function reminderText(task, minLeft) {
  const when = minLeft > 0
    ? `через ${minLeft >= 60 ? Math.floor(minLeft / 60) + ' ч' + (minLeft % 60 ? ' ' + (minLeft % 60) + ' мин' : '') : minLeft + ' мин'}`
    : 'пора начинать!';
  let text = `⏰ Напоминание — ${when}\n📌 ${task.title}\n🕐 ${ddmm(task.date)} в ${task.time}`;
  if (task.note) text += `\n\n📝 ${task.note.length > 400 ? task.note.slice(0, 400) + '…' : task.note}`;
  return text;
}

module.exports = { WD, WD_FULL, ddmm, fmtMin, remindLabel, dayLabel, renderDay, nthTask, reminderText };
