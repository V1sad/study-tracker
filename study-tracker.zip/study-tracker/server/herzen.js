'use strict';
// Загрузка расписания пар с сайта вуза (guide.herzen.spb.ru/schedule): список групп и занятия группы.
// Сайт отдаёт обычный HTML, поэтому HTML превращается в строки текста и разбирается по структуре
// «день недели → пары (время, предмет, примечание, тип, преподаватель, аудитория)».
// Адреса собираются только на сервере из числового id группы — произвольные URL запрашивать нельзя.
const fs = require('fs');
const path = require('path');
const cfg = require('./config');

const HOST = process.env.HERZEN_BASE || 'https://guide.herzen.spb.ru';
const UA = 'StudyTracker/1.0 (+personal study planner; contact via Telegram bot)';
const GROUPS_TTL = 12 * 3600 * 1000;
const CLASSES_TTL = 6 * 3600 * 1000;
let groupsCache = { at: 0, list: [] };
const classesCache = new Map();           // id → { at, lessons }

async function fetchHtml(url) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { headers: { 'user-agent': UA, accept: 'text/html' }, signal: ctrl.signal });
    if (!res.ok) { const e = new Error(`Сайт расписания ответил ${res.status}`); e.status = 502; throw e; }
    const text = await res.text();
    if (text.length > 3 * 1024 * 1024) { const e = new Error('Страница расписания слишком большая'); e.status = 502; throw e; }
    return text;
  } catch (err) {
    if (err.status) throw err;
    const e = new Error('Не удалось связаться с сайтом расписания вуза. Попробуй позже.'); e.status = 502; throw e;
  } finally { clearTimeout(timer); }
}

const ENT = { nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", ndash: '–', mdash: '—', laquo: '«', raquo: '»' };
const decode = (s) => s
  .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
  .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
  .replace(/&([a-z]+);/gi, (m, n) => (n.toLowerCase() in ENT ? ENT[n.toLowerCase()] : m));

// HTML → массив непустых строк текста
function htmlToLines(html) {
  const t = String(html)
    .replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<\/(p|div|li|ul|ol|tr|table|section|h[1-6]|dd|dt|thead|tbody)>|<br\s*\/?>|<(li|tr|h[1-6]|p|div)[\s>]/gi, '\n$&')
    .replace(/<\/?(td|th)[^>]*>/gi, ' ')
    .replace(/<[^>]+>/g, ' ');
  return decode(t).split('\n').map((l) => l.replace(/[ \t ]+/g, ' ').trim()).filter(Boolean);
}

/* ---------- список групп ---------- */
function parseGroups(html) {
  const out = new Map();
  const re = /<a\b[^>]*href\s*=\s*["']([^"']*\/schedule\/(\d+)\/classes[^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html))) {
    const name = decode(m[3].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
    if (name && !out.has(m[2])) out.set(m[2], { id: m[2], name });
  }
  return [...out.values()];
}
async function groups() {
  if (Date.now() - groupsCache.at < GROUPS_TTL && groupsCache.list.length) return groupsCache.list;
  const list = parseGroups(await fetchHtml(`${HOST}/schedule`));
  if (!list.length) { const e = new Error('Не удалось получить список групп с сайта вуза.'); e.status = 502; throw e; }
  groupsCache = { at: Date.now(), list };
  return list;
}
async function searchGroups(q, limit = 30) {
  const needle = String(q || '').trim().toLowerCase();
  if (needle.length < 2) return [];
  return (await groups()).filter((g) => g.name.toLowerCase().includes(needle)).slice(0, limit);
}

/* ---------- занятия группы ---------- */
const DAYS = { понедельник: 1, вторник: 2, среда: 3, четверг: 4, пятница: 5, суббота: 6, воскресенье: 0 };
const TIME = /(\d{1,2}):(\d{2})\s*[-–—]\s*(\d{1,2}):(\d{2})/;   // только двоеточие: точки — у дат в примечаниях
const pad = (n) => String(n).padStart(2, '0');
const hhmm = (h, m) => `${pad(h)}:${m}`;
const KIND = /^(лекц\w*|практ\w*|лаб\w*|сем\w*|конс\w*|зач\w*|экз\w*)\.?$/i;
const ROOM = /^(ауд\.|аудитория|корп|каб\.|видеолекц|дистанц|онлайн)/i;
const TEACHER = /^(проф|доц|ст\.?\s*преп|преп|асс|зав|к\.\s?[а-я]\.\s?н|д\.\s?[а-я]\.\s?н)|[А-ЯЁ][а-яё-]+\s+[А-ЯЁ]\.\s?[А-ЯЁ]\./;
const FULLNAME = /^[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё-]+$/;

// «7.09—28.09, 2.11—7.12» → [['09-07','09-28'], ['11-02','12-07']]; «17.11» → [['11-17','11-17']]
function parseRanges(text) {
  const out = [];
  const re = /(\d{1,2})\.(\d{1,2})(?:\.\d{2,4})?\s*(?:[-–—]\s*(\d{1,2})\.(\d{1,2})(?:\.\d{2,4})?)?/g;
  let m;
  while ((m = re.exec(text)) && out.length < 24) {
    const a = `${pad(+m[2])}-${pad(+m[1])}`;
    const b = m[3] ? `${pad(+m[4])}-${pad(+m[3])}` : a;
    if (+m[2] >= 1 && +m[2] <= 12 && (!m[4] || (+m[4] >= 1 && +m[4] <= 12)) && +m[1] >= 1 && +m[1] <= 31) out.push([a, b]);
  }
  return out;
}

const FOOTER = /^(Главная|Полезная информация|Ссылки|Старая версия сайта)(\s|$)|^Меню$/;
const NOTE = /^примечани[ея]\s*:?\s*/i;
const emptyEntry = () => ({ title: '', kind: '', room: [], teacher: [], week: '', note: '', has: false });

// В одном временном слоте может идти несколько предметов (у каждого свои недели, даты, преподаватель и аудитория).
// Запись начинается с пометки В/Н или с названия предмета, а дальше идут примечание, тип, преподаватель, аудитория.
function splitEntries(body) {
  const entries = [];
  let e = emptyEntry();
  const push = () => { if (e.title || e.has) entries.push(e); e = emptyEntry(); };
  const fieldsSet = () => e.note || e.kind || e.room.length || e.teacher.length;
  for (let i = 0; i < body.length; i++) {
    const s = body[i];
    if (s === 'В' || s === 'Н') { if (e.title || fieldsSet() || e.week) push(); e.week = s; e.has = true; continue; }
    if (NOTE.test(s)) {
      if (e.note) { const t = e.title, w = e.week; push(); e.title = t; e.week = w; }
      const rest = s.replace(NOTE, '');
      if (rest) e.note = rest; else if (i + 1 < body.length) e.note = body[++i];
      e.has = true; continue;
    }
    if (KIND.test(s)) {
      if (e.kind) { const t = e.title, w = e.week; push(); e.title = t; e.week = w; }
      e.kind = s.replace(/\.$/, ''); e.has = true; continue;
    }
    if (ROOM.test(s)) { if (!e.room.includes(s)) e.room.push(s); e.has = true; continue; }
    if (TEACHER.test(s) || FULLNAME.test(s)) { if (!e.teacher.includes(s)) e.teacher.push(s); e.has = true; continue; }
    // название предмета
    if (e.title && fieldsSet()) push();           // уже есть данные предыдущей записи → это новый предмет
    e.title = e.title ? `${e.title} ${s}` : s;
    e.has = true;
  }
  push();
  return entries;
}

function parseClasses(input) {
  const lines = Array.isArray(input) ? input : htmlToLines(input);
  const slots = [];
  let dow = null, cur = null;
  const flush = () => { if (cur) { slots.push(cur); cur = null; } };
  for (const line of lines) {
    if (cur && FOOTER.test(line)) break;           // подвал сайта: дальше расписания нет
    const dayWord = line.toLowerCase().replace(/[.:,]/g, '').trim();
    if (Object.hasOwn(DAYS, dayWord)) { flush(); dow = DAYS[dayWord]; continue; }
    if (dow == null) continue;
    const tm = line.match(TIME);
    if (tm && line.length < 40) {      // строка вида «3. 13:30-15:00»
      flush();
      cur = { dow, start: hhmm(+tm[1], tm[2]), end: hhmm(+tm[3], tm[4]), body: [] };
      continue;
    }
    if (!cur) continue;
    if (/^\d{1,2}\.?$/.test(line)) continue;   // номер пары отдельной строкой
    cur.body.push(line);
  }
  flush();

  const out = [];
  for (const slot of slots) {
    if (!(slot.start < slot.end || slot.end === '00:00')) continue;
    for (const e of splitEntries(slot.body)) {
      out.push({
        dow: slot.dow, start: slot.start, end: slot.end,
        title: (e.title || 'Пара').slice(0, 160), kind: e.kind, room: e.room.join('; ').slice(0, 80), teacher: e.teacher.join(', ').slice(0, 120),
        week: e.week, ranges: parseRanges(e.note),
      });
    }
  }
  return out;
}

async function classes(id, { fresh = false } = {}) {
  if (!/^\d{1,9}$/.test(String(id))) { const e = new Error('Неверный номер группы'); e.status = 400; throw e; }
  const hit = classesCache.get(String(id));
  if (!fresh && hit && Date.now() - hit.at < CLASSES_TTL) return hit.lessons;
  const html = await fetchHtml(`${HOST}/schedule/${id}/classes`);
  const lines = htmlToLines(html);
  const lessons = parseClasses(lines);
  if (!lessons.length) {
    // сохраняем текст страницы, чтобы можно было подправить разбор
    try {
      fs.mkdirSync(path.dirname(cfg.dbPath), { recursive: true });
      fs.writeFileSync(path.join(path.dirname(cfg.dbPath), `herzen-debug-${id}.txt`), lines.slice(0, 600).join('\n'));
    } catch { /* не критично */ }
    const e = new Error('Не получилось распознать расписание этой группы. Возможно, на сайте вуза изменилась вёрстка или расписание пустое.');
    e.status = 422; throw e;
  }
  classesCache.set(String(id), { at: Date.now(), lessons });
  if (classesCache.size > 200) classesCache.delete(classesCache.keys().next().value);
  return lessons;
}

/* ---------- экзамены, зачёты, практики ---------- */
// Страницы /exams и /credits-practice устроены как список записей: дата, время, предмет, вид (экзамен/зачёт/консультация…),
// аудитория, преподаватель. Разбор намеренно терпимый: запись начинается со строки, где есть дата, а всё остальное
// определяется по виду строк. Если на странице есть текст, но ничего не распознано — он сохраняется в файл для отладки.
const MONTHS_RU = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const DATE_NUM = /(?<![\d:.])(\d{1,2})\.(\d{2})(?:\.(\d{4}|\d{2}))?(?![\d:])/;
const DATE_WORD = new RegExp(`(\\d{1,2})\\s+(${MONTHS_RU.join('|')})(?:\\s+(\\d{4}))?`, 'i');
const TIME_ONE = /(?<!\d)(\d{1,2}):(\d{2})(?:\s*[-–—]\s*(\d{1,2}):(\d{2}))?/;
const WEEKDAY = /^(пн|вт|ср|чт|пт|сб|вс|понедельник|вторник|среда|четверг|пятница|суббота|воскресенье)[.,]?$/i;
const EXAM_KIND = /(экзамен[а-яё]*|зач[её]т[а-яё]*(?:\s+с\s+оценкой)?|консультаци[а-яё]*|практик[а-яё]*|курсов[а-яё]*\s+работ[а-яё]*|аттестаци[а-яё]*)/i;   // \w в JS не знает кириллицу
const ROOM_IN = /(?:ауд(?:итория|\.)?\s*|каб(?:инет|\.)?\s*)([0-9a-zа-яё\-./]+)/i;

function normKind(raw) {
  const k = String(raw || '').toLowerCase();
  if (/экзамен/.test(k)) return 'Экзамен';
  if (/зач[её]т.*оценк/.test(k)) return 'Зачёт с оценкой';
  if (/зач[её]т/.test(k)) return 'Зачёт';
  if (/консультац/.test(k)) return 'Консультация';
  if (/практик/.test(k)) return 'Практика';
  if (/курсов/.test(k)) return 'Курсовая';
  if (/аттестац/.test(k)) return 'Аттестация';
  return '';
}
function pickDate(line, todayKey) {
  let d, mo, y;
  let m = line.match(DATE_WORD);
  if (m) { d = +m[1]; mo = MONTHS_RU.indexOf(m[2].toLowerCase()) + 1; y = m[3] ? +m[3] : 0; }
  else if ((m = line.match(DATE_NUM))) { d = +m[1]; mo = +m[2]; y = m[3] ? (m[3].length === 2 ? 2000 + +m[3] : +m[3]) : 0; }
  else return null;
  if (!(mo >= 1 && mo <= 12 && d >= 1 && d <= 31)) return null;
  if (!y) {                                   // года нет — берём ближайший, который не раньше чем за два месяца до сегодня
    const ty = +todayKey.slice(0, 4);
    y = ty;
    const cand = (yy) => `${yy}-${pad(mo)}-${pad(d)}`;
    const lim = (() => { const t = new Date(todayKey + 'T00:00:00Z'); t.setUTCDate(t.getUTCDate() - 60); return t.toISOString().slice(0, 10); })();
    if (cand(y) < lim) y += 1;
  }
  const key = `${y}-${pad(mo)}-${pad(d)}`;
  const chk = new Date(key + 'T00:00:00Z');
  if (Number.isNaN(chk.getTime()) || chk.getUTCDate() !== d) return null;
  return { key, text: m[0] };
}

// Строка таблицы приходит одной строкой текста: «25.12.2099 11:20 Предмет Зачёт ауд. 223 Иванова А. П.» — разбираем по частям
const INLINE_TEACHER = /(?:(?:проф|доц|ст\.?\s*преп|преп|асс)\.?\s+)?[А-ЯЁ][а-яё-]+\s+(?:[А-ЯЁ]\.\s?[А-ЯЁ]\.|[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё-]+)/;
function splitInline(text) {
  let s = text;
  const out = [];
  const take = (re) => { const m = s.match(re); if (m) { out.push(m[0].trim()); s = s.replace(m[0], ' '); } };
  take(TIME_ONE); take(ROOM_IN); take(EXAM_KIND);
  const tm = s.match(INLINE_TEACHER);
  const teacher = tm && /\.\s?[А-ЯЁ]\.|\s[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё-]+$/.test(tm[0]) ? tm[0].trim() : '';
  if (teacher) s = s.replace(tm[0], ' ');
  return [s.trim(), ...out, teacher].filter(Boolean);
}

function parseExams(input, todayKey, defaultKind = '') {
  const lines = (Array.isArray(input) ? input : htmlToLines(input));
  const out = [];
  let cur = null;
  const flush = () => {
    if (!cur) return;
    const body = cur.lines.filter(Boolean);
    let start = '', end = '', kind = '', room = '', teacher = '';
    const rest = [];
    for (const raw of body) {
      let l = raw;
      const tm = l.match(TIME_ONE);
      if (tm && !start) { start = hhmm(+tm[1], tm[2]); if (tm[3] !== undefined) end = hhmm(+tm[3], tm[4]); l = l.replace(tm[0], ' ').trim(); }
      const km = l.match(EXAM_KIND);
      if (km && !kind) { kind = normKind(km[1]); }
      const rm = l.match(ROOM_IN);
      if (rm && !room) { room = rm[0].replace(/\s+/g, ' ').trim(); l = l.replace(rm[0], ' ').trim(); }
      l = l.replace(/^[\s,;:|·—–-]+|[\s,;:|·—–-]+$/g, '').trim();
      if (!l || WEEKDAY.test(l)) continue;
      if (TEACHER.test(l) && !teacher && !/[«"]/.test(l)) { teacher = l; continue; }
      if (ROOM.test(l) && !room) { room = l; continue; }
      if (EXAM_KIND.test(l) && l.replace(EXAM_KIND, '').replace(/[\s,;:.|·—–-]/g, '') === '') continue;   // строка из одного слова «Экзамен»
      rest.push(l.replace(/^(экзамен|зач[её]т(?:\s+с\s+оценкой)?|консультация)\s*[:—–-]\s*/i, ''));
    }
    const title = (rest[0] || '').slice(0, 160);
    if (title || kind) out.push({ date: cur.date, start, end, title: title || kind, kind: kind || normKind(defaultKind), room: room.slice(0, 80), teacher: teacher.slice(0, 120) });
    cur = null;
  };
  for (const raw of lines) {
    if (FOOTER.test(raw)) break;
    const dt = pickDate(raw, todayKey);
    const tm = raw.match(TIME_ONE);
    // новая запись: строка с датой; либо второе время в блоке той же даты после уже набранного названия
    if (dt) {
      flush();
      const rest = raw.replace(dt.text, ' ').trim();
      cur = { date: dt.key, lines: rest.length > 30 ? splitInline(rest) : [rest] };
    } else if (cur) {
      if (tm && cur.lines.some((l) => TIME_ONE.test(l)) && cur.lines.length > 1) { const date = cur.date; flush(); cur = { date, lines: [raw] }; }
      else cur.lines.push(raw);
    }
  }
  flush();
  // убираем дубли (одна запись могла быть на двух вкладках)
  const seen = new Set();
  return out.filter((e) => { const k = [e.date, e.start, e.title, e.kind].join('|'); if (seen.has(k)) return false; seen.add(k); return true; })
    .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start))
    .slice(0, 80)
    .map((e, i) => ({ id: 'x' + i, ...e }));
}

const examsCache = new Map();
async function exams(id, todayKey, { fresh = false } = {}) {
  if (!/^\d{1,9}$/.test(String(id))) { const e = new Error('Неверный номер группы'); e.status = 400; throw e; }
  const hit = examsCache.get(String(id));
  if (!fresh && hit && Date.now() - hit.at < CLASSES_TTL) return hit.list;
  const pages = [['exams', 'Экзамен'], ['credits-practice', 'Зачёт']];
  let all = [], okPages = 0, firstErr = null;
  for (const [tab, kind] of pages) {
    try {
      const lines = htmlToLines(await fetchHtml(`${HOST}/schedule/${id}/${tab}`));
      okPages++;
      const got = parseExams(lines, todayKey, kind);
      if (!got.length && lines.length > 20) {
        try {
          fs.mkdirSync(path.dirname(cfg.dbPath), { recursive: true });
          fs.writeFileSync(path.join(path.dirname(cfg.dbPath), `herzen-debug-${id}-${tab}.txt`), lines.slice(0, 600).join('\n'));
        } catch { /* не критично */ }
      }
      all = all.concat(got);
    } catch (e) { firstErr = firstErr || e; }
  }
  if (!okPages) throw firstErr;               // обе страницы недоступны — пусть вызывающий покажет старые данные
  const seen = new Set();
  const list = all.filter((e) => { const k = [e.date, e.start, e.title].join('|'); if (seen.has(k)) return false; seen.add(k); return true; })
    .sort((a, b) => (a.date + a.start).localeCompare(b.date + b.start)).map((e, i) => ({ ...e, id: 'x' + i }));
  examsCache.set(String(id), { at: Date.now(), list });
  if (examsCache.size > 200) examsCache.delete(examsCache.keys().next().value);
  return list;
}

// Сентябрьская неделя с 1 сентября — «верхняя» (допущение; можно поправить в настройках)
function guessTopWeek(todayKey) {
  const [y, m] = todayKey.split('-').map(Number);
  const year = m >= 8 ? y : y - 1;
  return `${year}-09-01`;
}

// Определяем «верхнюю» неделю по самим данным: если у пары с пометкой В/Н первая дата периода приходится на её день недели,
// то это точная дата занятия, и неделя этой даты — верхняя (для «Н» — следующая). Решаем голосованием по чётности недель.
function inferTopWeek(lessons, todayKey) {
  const [ty, tm] = todayKey.split('-').map(Number);
  const startYear = tm >= 8 ? ty : ty - 1;
  const monday = (d) => Math.floor(d.getTime() / 86400000) - ((d.getUTCDay() + 6) % 7);   // номер дня понедельника
  const votes = new Map();
  for (const l of lessons) {
    if ((l.week !== 'В' && l.week !== 'Н') || !l.ranges.length) continue;
    const [m, d] = l.ranges[0][0].split('-').map(Number);
    const date = new Date(Date.UTC(m >= 8 ? startYear : startYear + 1, m - 1, d));
    if (date.getUTCDay() !== l.dow) continue;           // дата не совпадает с днём недели — слишком неточно
    let mon = monday(date);
    if (l.week === 'Н') mon += 7;
    const par = ((mon % 14) + 14) % 14;
    votes.set(par, (votes.get(par) || 0) + 1);
  }
  if (!votes.size) return null;
  const best = [...votes.entries()].sort((a, b) => b[1] - a[1])[0][0];
  // ближайший понедельник с такой чётностью, начиная с 1 сентября учебного года
  let day = Math.floor(Date.UTC(startYear, 8, 1) / 86400000);
  day -= (new Date(day * 86400000).getUTCDay() + 6) % 7;
  while (((day % 14) + 14) % 14 !== best) day += 7;
  return new Date(day * 86400000).toISOString().slice(0, 10);
}

function toSchedule(lessons) {
  return lessons.slice(0, 150).map((l, i) => ({ id: 'h' + i, ...l }));
}

module.exports = { htmlToLines, parseGroups, parseClasses, parseRanges, parseExams, exams, groups, searchGroups, classes, guessTopWeek, inferTopWeek, toSchedule };
