'use strict';
// Загрузка расписания пар с сайта вуза (guide.herzen.spb.ru/schedule): список групп и занятия группы.
// Сайт отдаёт обычный HTML, поэтому HTML превращается в строки текста и разбирается по структуре
// «день недели → пары (время, предмет, примечание, тип, преподаватель, аудитория)».
// Адреса собираются только на сервере из числового id группы — произвольные URL запрашивать нельзя.
const fs = require('fs');
const path = require('path');
const cfg = require('./config');

const HOST = process.env.HERZEN_BASE || 'https://guide.herzen.spb.ru';
const UA = 'StudyTracker/1.0 (+personal study planner; contact via Telegram bot)';
const GROUPS_TTL = 12 * 3600 * 1000;
const CLASSES_TTL = 6 * 3600 * 1000;
let groupsCache = { at: 0, list: [] };
const classesCache = new Map();           // id → { at, lessons }

async function fetchHtml(url) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), 15000);
  try {
    const res = await fetch(url, { headers: { 'user-agent': UA, accept: 'text/html' }, signal: ctrl.signal });
    if (!res.ok) { const e = new Error(`Сайт расписания ответил ${res.status}`); e.status = 502; throw e; }
    const text = await res.text();
    if (text.length > 3 * 1024 * 1024) { const e = new Error('Страница расписания слишком большая'); e.status = 502; throw e; }
    return text;
  } catch (err) {
    if (err.status) throw err;
    const e = new Error('Не удалось связаться с сайтом расписания вуза. Попробуй позже.'); e.status = 502; throw e;
  } finally { clearTimeout(timer); }
}

const ENT = { nbsp: ' ', amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", ndash: '–', mdash: '—', laquo: '«', raquo: '»' };
const decode = (s) => s
  .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
  .replace(/&#x([0-9a-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)))
  .replace(/&([a-z]+);/gi, (m, n) => (n.toLowerCase() in ENT ? ENT[n.toLowerCase()] : m));

// HTML → массив непустых строк текста
function htmlToLines(html) {
  const t = String(html)
    .replace(/<(script|style|noscript)[\s\S]*?<\/\1>/gi, '')
    .replace(/<!--[\s\S]*?-->/g, '')
    .replace(/<\/(p|div|li|ul|ol|tr|table|section|h[1-6]|dd|dt|thead|tbody)>|<br\s*\/?>|<(li|tr|h[1-6]|p|div)[\s>]/gi, '\n$&')
    .replace(/<\/?(td|th)[^>]*>/gi, ' ')
    .replace(/<[^>]+>/g, ' ');
  return decode(t).split('\n').map((l) => l.replace(/[ \t ]+/g, ' ').trim()).filter(Boolean);
}

/* ---------- список групп ---------- */
function parseGroups(html) {
  const out = new Map();
  const re = /<a\b[^>]*href\s*=\s*["']([^"']*\/schedule\/(\d+)\/classes[^"']*)["'][^>]*>([\s\S]*?)<\/a>/gi;
  let m;
  while ((m = re.exec(html))) {
    const name = decode(m[3].replace(/<[^>]+>/g, ' ')).replace(/\s+/g, ' ').trim();
    if (name && !out.has(m[2])) out.set(m[2], { id: m[2], name });
  }
  return [...out.values()];
}
async function groups() {
  if (Date.now() - groupsCache.at < GROUPS_TTL && groupsCache.list.length) return groupsCache.list;
  const list = parseGroups(await fetchHtml(`${HOST}/schedule`));
  if (!list.length) { const e = new Error('Не удалось получить список групп с сайта вуза.'); e.status = 502; throw e; }
  groupsCache = { at: Date.now(), list };
  return list;
}
async function searchGroups(q, limit = 30) {
  const needle = String(q || '').trim().toLowerCase();
  if (needle.length < 2) return [];
  return (await groups()).filter((g) => g.name.toLowerCase().includes(needle)).slice(0, limit);
}

/* ---------- занятия группы ---------- */
const DAYS = { понедельник: 1, вторник: 2, среда: 3, четверг: 4, пятница: 5, суббота: 6, воскресенье: 0 };
const TIME = /(\d{1,2}):(\d{2})\s*[-–—]\s*(\d{1,2}):(\d{2})/;   // только двоеточие: точки — у дат в примечаниях
const pad = (n) => String(n).padStart(2, '0');
const hhmm = (h, m) => `${pad(h)}:${m}`;
const KIND = /^(лекц\w*|практ\w*|лаб\w*|сем\w*|конс\w*|зач\w*|экз\w*)\.?$/i;
const ROOM = /^(ауд\.|аудитория|корп|каб\.|видеолекц|дистанц|онлайн)/i;
const TEACHER = /^(проф|доц|ст\.?\s*преп|преп|асс|зав|к\.\s?[а-я]\.\s?н|д\.\s?[а-я]\.\s?н)|[А-ЯЁ][а-яё-]+\s+[А-ЯЁ]\.\s?[А-ЯЁ]\./;
const FULLNAME = /^[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё-]+\s+[А-ЯЁ][а-яё-]+$/;

// «7.09—28.09, 2.11—7.12» → [['09-07','09-28'], ['11-02','12-07']]; «17.11» → [['11-17','11-17']]
function parseRanges(text) {
  const out = [];
  const re = /(\d{1,2})\.(\d{1,2})(?:\.\d{2,4})?\s*(?:[-–—]\s*(\d{1,2})\.(\d{1,2})(?:\.\d{2,4})?)?/g;
  let m;
  while ((m = re.exec(text)) && out.length < 24) {
    const a = `${pad(+m[2])}-${pad(+m[1])}`;
    const b = m[3] ? `${pad(+m[4])}-${pad(+m[3])}` : a;
    if (+m[2] >= 1 && +m[2] <= 12 && (!m[4] || (+m[4] >= 1 && +m[4] <= 12)) && +m[1] >= 1 && +m[1] <= 31) out.push([a, b]);
  }
  return out;
}

function parseClasses(input) {
  const lines = Array.isArray(input) ? input : htmlToLines(input);
  const lessons = [];
  let dow = null, cur = null;
  const flush = () => { if (cur) { lessons.push(cur); cur = null; } };
  for (const line of lines) {
    const dayWord = line.toLowerCase().replace(/[.:,]/g, '').trim();
    if (Object.hasOwn(DAYS, dayWord)) { flush(); dow = DAYS[dayWord]; continue; }
    if (dow == null) continue;
    const tm = line.match(TIME);
    if (tm && line.length < 40) {      // строка вида «3. 13:30-15:00»
      flush();
      cur = { dow, start: hhmm(+tm[1], tm[2]), end: hhmm(+tm[3], tm[4]), body: [] };
      continue;
    }
    if (!cur) continue;
    if (/^\d{1,2}\.?$/.test(line)) continue;   // номер пары отдельной строкой
    cur.body.push(line);
  }
  flush();

  return lessons.map((l) => {
    let title = '', kind = '', room = '', week = '', note = '';
    const teachers = [];
    for (let i = 0; i < l.body.length; i++) {
      const s = l.body[i];
      if (/^примечани[ея]/i.test(s)) { note = s.replace(/^примечани[ея]\s*:?\s*/i, '') || l.body[i + 1] || ''; if (!s.replace(/^примечани[ея]\s*:?\s*/i, '')) i++; continue; }
      if ((s === 'В' || s === 'Н') && !title) { week = s; continue; }
      if (KIND.test(s)) { kind = s.replace(/\.$/, ''); continue; }
      if (ROOM.test(s)) { room = room ? `${room}; ${s}` : s; continue; }
      if (TEACHER.test(s) || FULLNAME.test(s)) { teachers.push(s); continue; }
      if (!title) title = s;
      else if (!/^(видеолекция|дистанционное)/i.test(s)) title += ' ' + s;
    }
    return {
      dow: l.dow, start: l.start, end: l.end,
      title: title || 'Пара', kind, room, teacher: teachers.join(', '), week, ranges: parseRanges(note),
    };
  }).filter((l) => l.start < l.end || l.end === '00:00');
}

async function classes(id) {
  if (!/^\d{1,9}$/.test(String(id))) { const e = new Error('Неверный номер группы'); e.status = 400; throw e; }
  const hit = classesCache.get(String(id));
  if (hit && Date.now() - hit.at < CLASSES_TTL) return hit.lessons;
  const html = await fetchHtml(`${HOST}/schedule/${id}/classes`);
  const lines = htmlToLines(html);
  const lessons = parseClasses(lines);
  if (!lessons.length) {
    // сохраняем текст страницы, чтобы можно было подправить разбор
    try {
      fs.mkdirSync(path.dirname(cfg.dbPath), { recursive: true });
      fs.writeFileSync(path.join(path.dirname(cfg.dbPath), `herzen-debug-${id}.txt`), lines.slice(0, 600).join('\n'));
    } catch { /* не критично */ }
    const e = new Error('Не получилось распознать расписание этой группы. Возможно, на сайте вуза изменилась вёрстка или расписание пустое.');
    e.status = 422; throw e;
  }
  classesCache.set(String(id), { at: Date.now(), lessons });
  if (classesCache.size > 200) classesCache.delete(classesCache.keys().next().value);
  return lessons;
}

// Сентябрьская неделя с 1 сентября — «верхняя» (допущение; можно поправить в настройках)
function guessTopWeek(todayKey) {
  const [y, m] = todayKey.split('-').map(Number);
  const year = m >= 8 ? y : y - 1;
  return `${year}-09-01`;
}

function toSchedule(lessons) {
  return lessons.slice(0, 40).map((l, i) => ({ id: 'h' + i, ...l }));
}

module.exports = { htmlToLines, parseGroups, parseClasses, parseRanges, groups, searchGroups, classes, guessTopWeek, toSchedule };
