'use strict';
// HTTP-сервер: статика сайта + JSON API (без внешних зависимостей).
const http = require('http');
const fs = require('fs');
const path = require('path');
const cfg = require('./config');
const T = require('./time');
const store = require('./store');
const S = require('./settings');
const F = require('./format');
const tg = require('./tg');
const bot = require('./bot');
const scheduler = require('./scheduler');
const herzen = require('./herzen');
const rating = require('./rating');

const MIME = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.webmanifest': 'application/manifest+json; charset=utf-8',
  '.png': 'image/png', '.svg': 'image/svg+xml', '.ico': 'image/x-icon',
};
const SEC_HEADERS = {
  'X-Content-Type-Options': 'nosniff',
  'X-Frame-Options': 'DENY',
  'Referrer-Policy': 'same-origin',
  'Content-Security-Policy': "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; worker-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'",
};

class HttpError extends Error { constructor(status, msg) { super(msg); this.status = status; } }

/* ---------- утилиты ---------- */
function send(res, status, body, headers = {}) {
  res.writeHead(status, { ...SEC_HEADERS, ...headers });
  res.end(body);
}
const json = (res, status, obj, headers = {}) => send(res, status, JSON.stringify(obj), { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });

function parseCookies(req) {
  const out = {};
  for (const part of (req.headers.cookie || '').split(';')) {
    const i = part.indexOf('=');
    if (i > 0) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  return out;
}
function sessionCookie(value, maxAgeSec) {
  return `sid=${encodeURIComponent(value)}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAgeSec}${cfg.secureCookie ? '; Secure' : ''}`;
}
function readBody(req, limit = 512 * 1024) {
  return new Promise((resolve, reject) => {
    let size = 0; const chunks = [];
    req.on('data', (c) => { size += c.length; if (size > limit) { reject(new HttpError(413, 'Слишком большой запрос')); req.destroy(); } else chunks.push(c); });
    req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
    req.on('error', reject);
  });
}
function clientIp(req) {
  const addr = req.socket.remoteAddress || '';
  const loopback = addr === '127.0.0.1' || addr === '::1' || addr === '::ffff:127.0.0.1';
  const xff = req.headers['x-forwarded-for'];
  return loopback && xff ? String(xff).split(',')[0].trim() : addr;
}
const hits = new Map();
function rateLimit(key, max, windowMs) {
  const nowMs = Date.now();
  const arr = (hits.get(key) || []).filter((t) => nowMs - t < windowMs);
  if (arr.length >= max) { hits.set(key, arr); throw new HttpError(429, 'Слишком много попыток, подожди немного'); }
  arr.push(nowMs); hits.set(key, arr);
  if (hits.size > 5000) for (const [k, v] of hits) if (!v.length || nowMs - v[v.length - 1] > windowMs) hits.delete(k);
}

/* ---------- маршруты ---------- */
const routes = [];
function route(method, pattern, handler, { auth = true } = {}) {
  const keys = [];
  const re = new RegExp('^' + pattern.replace(/:(\w+)/g, (_, k) => { keys.push(k); return '([^/]+)'; }) + '/?$');
  routes.push({ method, re, keys, handler, auth });
}

const stateFor = (user) => {
  const today = store.todayOf(user);
  return {
    user: { name: user.name, username: user.username, tz: user.tz },
    settings: user.settings,
    today,
    tasks: store.listTasks(user.id),
    study: store.studyMap(user.id, T.addDays(today, -400)),
    timer: store.getTimer(user.id, 'web') || null,
    bot: bot.username(),
    features: { java: store.hasJava(user) },
  };
};

// --- вход ---
route('GET', '/api/auth/info', async () => ({ body: { bot: bot.username(), siteUrl: cfg.baseUrl, botReady: !!cfg.botToken } }), { auth: false });

route('POST', '/api/auth/start', async ({ req }) => {
  rateLimit('auth:' + clientIp(req), 30, 10 * 60 * 1000);
  if (!cfg.botToken) throw new HttpError(503, 'Бот не настроен на сервере (BOT_TOKEN)');
  const code = store.newLogin(null);
  const name = bot.username();
  return { body: { code, bot: name, link: name ? `https://t.me/${name}?start=login_${code}` : null } };
}, { auth: false });

route('GET', '/api/auth/poll', async ({ query }) => {
  const r = store.consumeLogin(query.get('code') || '');
  if (r === 'pending') return { body: { pending: true } };
  if (r == null) return { status: 410, body: { error: 'Код входа устарел' } };
  const sid = store.createSession(r);
  return { body: { ok: true }, headers: { 'Set-Cookie': sessionCookie(sid, 30 * 24 * 3600) } };
}, { auth: false });

route('POST', '/api/auth/logout', async ({ req }) => {
  store.destroySession(parseCookies(req).sid);
  return { body: { ok: true }, headers: { 'Set-Cookie': sessionCookie('', 0) } };
}, { auth: false });

// --- состояние ---
route('GET', '/api/state', async ({ user }) => ({ body: stateFor(user) }));

// --- задачи ---
route('POST', '/api/tasks', async ({ user, body }) => {
  const t = store.cleanTask(body);
  return { status: 201, body: store.insertTask(user.id, t) };
});
route('PATCH', '/api/tasks/:id', async ({ user, params, body }) => {
  const p = store.cleanTask(body, { partial: true });
  const t = store.patchTask(user.id, params.id, p);
  if (!t) throw new HttpError(404, 'Задача не найдена');
  return { body: t };
});
route('DELETE', '/api/tasks/:id', async ({ user, params }) => {
  if (!store.deleteTask(user.id, params.id)) throw new HttpError(404, 'Задача не найдена');
  return { body: { ok: true } };
});

// --- настройки ---
route('PUT', '/api/settings', async ({ user, body }) => {
  if (body && body.tz !== undefined && !T.validTz(body.tz)) throw new HttpError(400, 'Неизвестный часовой пояс');
  const u = store.updateSettings(user.id, body);
  rating.invalidate();
  return { body: { settings: u.settings, tz: u.tz } };
});

// --- учёт времени ---
route('POST', '/api/log', async ({ user, body }) => {
  const ms = Math.round(Number(body.ms) || 0);
  if (ms < 0 || ms > 6 * 3600 * 1000) throw new HttpError(400, 'Неверное время');
  const pomo = body.pomo ? 1 : 0;
  const today = store.todayOf(user);
  if (ms || pomo) store.addStudy(user.id, today, ms, pomo);
  if (ms && body.taskId) store.addTaskSpent(user.id, body.taskId, ms);
  return { body: { ok: true } };
});

// --- серверный таймер (чтобы уведомление пришло, даже если вкладку закрыли) ---
route('PUT', '/api/timer', async ({ user, body }) => {
  const endsAt = Number(body.endsAt);
  const nowMs = Date.now();
  if (!Number.isFinite(endsAt) || endsAt < nowMs - 5000 || endsAt > nowMs + 6 * 3600 * 1000) throw new HttpError(400, 'Неверное время окончания');
  if (!['work', 'break'].includes(body.phase)) throw new HttpError(400, 'Неверная фаза');
  const task = body.taskId ? store.getTask(user.id, body.taskId) : null;
  // предыдущая фаза закончилась прямо сейчас (автозапуск следующей) — сначала отправим её уведомление
  const old = store.getTimer(user.id, 'web');
  if (old && old.endsAt <= nowMs + 3000) await scheduler.fireTimer(old, nowMs);
  store.setTimer(user.id, 'web', {
    endsAt, phase: body.phase, mode: String(body.mode || '').slice(0, 40),
    workMin: Math.max(0, Math.min(240, Math.round(Number(body.workMin) || 0))),
    breakMin: Math.max(0, Math.min(120, Math.round(Number(body.breakMin) || 0))),
    taskId: task ? task.id : '', startedAt: nowMs,
  });
  return { body: { ok: true } };
});
route('DELETE', '/api/timer', async ({ user }) => { store.clearTimer(user.id, 'web'); return { body: { ok: true } }; });

// --- план ---
route('POST', '/api/plan/generate', async ({ user, body }) => {
  const startDate = body.startDate || store.todayOf(user);
  if (!T.validDate(startDate)) throw new HttpError(400, 'Неверная дата начала');
  const r = store.generatePlan(user, { startDate, fromDay: body.fromDay, track: body.track });
  return { body: r };
});
route('POST', '/api/plan/shift', async ({ user, body }) => {
  const r = store.shiftPlan(user, body && body.track);
  if (!r) throw new HttpError(409, 'В плане нет невыполненных задач');
  return { body: r };
});

// --- очистка и импорт ---
route('POST', '/api/clear', async ({ user, body }) => {
  if (body.confirm !== true) throw new HttpError(400, 'Нужно подтверждение');
  const r = store.clearData(user, { tasks: body.tasks !== false, stats: body.stats === true, schedule: body.schedule === true });
  return { body: r };
});
route('POST', '/api/plan/import', async ({ user, body }) => {
  if (body.startDate != null && !T.validDate(body.startDate)) throw new HttpError(400, 'Неверная дата начала');
  return { body: store.importPlan(user, body.doc, { startDate: body.startDate }) };
});

// --- расписание с сайта вуза ---
const herzenCool = new Map();
const HERZEN_COOLDOWN = Number(process.env.HERZEN_COOLDOWN_MS ?? 4000);
const cool = (user) => {
  const last = herzenCool.get(user.id) || 0;
  if (Date.now() - last < HERZEN_COOLDOWN) throw new HttpError(429, 'Подожди пару секунд');
  herzenCool.set(user.id, Date.now());
  if (herzenCool.size > 5000) herzenCool.clear();
};
route('GET', '/api/herzen/groups', async ({ user, query }) => {
  cool(user);
  return { body: { groups: await herzen.searchGroups(query.get('q') || '') } };
});
// Только разбор: ничего не сохраняет, клиент подставляет пары в форму настроек, и человек правит их перед сохранением
route('POST', '/api/herzen/classes', async ({ user, body }) => {
  cool(user);
  const lessons = await herzen.classes(String(body.groupId || ''));
  return { body: { schedule: herzen.toSchedule(lessons), topWeek: user.settings.topWeek || herzen.guessTopWeek(store.todayOf(user)) } };
});

// --- рейтинг ---
route('GET', '/api/rating', async ({ user, query }) => {
  const scope = ['week', 'month', 'all'].includes(query.get('scope')) ? query.get('scope') : 'week';
  return { body: rating.board(scope, user.id) };
});
route('GET', '/api/avatar/:pid', async ({ params }) => {
  const buf = /^[0-9a-f]{12}$/.test(params.pid) ? await rating.avatarFor(params.pid) : null;
  if (!buf) throw new HttpError(404, 'Нет фото');
  return { buffer: buf, headers: { 'Content-Type': 'image/jpeg', 'Cache-Control': 'private, max-age=3600' } };
});

// --- прочее ---
route('POST', '/api/test-message', async ({ user }) => {
  const r = await tg.send(user.tgId, '✅ Связь работает! Это тестовое сообщение из настроек сайта.');
  if (!r) throw new HttpError(502, 'Telegram не принял сообщение. Нажми /start у бота и попробуй снова.');
  return { body: { ok: true } };
});
route('GET', '/api/export', async ({ user }) => ({
  body: { exportedAt: new Date().toISOString(), user: { name: user.name, tz: user.tz }, settings: user.settings, tasks: store.listTasks(user.id), study: store.studyMap(user.id, '2000-01-01') },
  headers: { 'Content-Disposition': 'attachment; filename="tracker-export.json"' },
}));
route('DELETE', '/api/account', async ({ user, req }) => {
  store.deleteUser(user.id);
  return { body: { ok: true }, headers: { 'Set-Cookie': sessionCookie('', 0) } };
});
route('GET', '/api/health', async () => ({ body: { ok: true } }), { auth: false });

// вход по одноразовой ссылке из бота: /auth/<код>
route('GET', '/auth/:code', async ({ params }) => {
  const r = store.consumeLogin(params.code);
  if (typeof r !== 'number') return { status: 302, raw: true, headers: { Location: '/?login=expired' } };
  const sid = store.createSession(r);
  return { status: 302, raw: true, headers: { Location: '/', 'Set-Cookie': sessionCookie(sid, 30 * 24 * 3600), 'Cache-Control': 'no-store' } };
}, { auth: false });

/* ---------- статика ---------- */
function serveStatic(req, res, pathname) {
  let rel = decodeURIComponent(pathname);
  if (rel === '/' || rel === '') rel = '/index.html';
  const file = path.normalize(path.join(cfg.publicDir, rel));
  if (!file.startsWith(cfg.publicDir + path.sep) && file !== cfg.publicDir) return send(res, 403, 'Forbidden');
  fs.stat(file, (err, st) => {
    if (err || !st.isFile()) return send(res, 404, 'Not found', { 'Content-Type': 'text/plain; charset=utf-8' });
    const ext = path.extname(file).toLowerCase();
    res.writeHead(200, {
      ...SEC_HEADERS,
      'Content-Type': MIME[ext] || 'application/octet-stream',
      'Content-Length': st.size,
      'Cache-Control': ext === '.png' ? 'public, max-age=86400' : 'no-cache',
    });
    if (req.method === 'HEAD') return res.end();
    fs.createReadStream(file).pipe(res);
  });
}

/* ---------- обработчик ---------- */
async function handle(req, res) {
  const url = new URL(req.url, 'http://x');
  const pathname = url.pathname;
  try {
    const isApi = pathname.startsWith('/api/') || pathname.startsWith('/auth/');
    if (!isApi) {
      if (req.method !== 'GET' && req.method !== 'HEAD') throw new HttpError(405, 'Method not allowed');
      return serveStatic(req, res, pathname);
    }
    for (const r of routes) {
      if (r.method !== req.method) continue;
      const m = pathname.match(r.re);
      if (!m) continue;
      const params = {};
      r.keys.forEach((k, i) => { params[k] = decodeURIComponent(m[i + 1]); });
      let user = null;
      if (r.auth) {
        user = store.sessionUser(parseCookies(req).sid);
        if (!user) throw new HttpError(401, 'Нужен вход');
      }
      let body = {};
      if (['POST', 'PUT', 'PATCH'].includes(req.method)) {
        // CSRF: принимаем только JSON (кросс-сайтовая форма не может отправить такой Content-Type)
        if (!/^application\/json\b/i.test(req.headers['content-type'] || '')) throw new HttpError(415, 'Нужен Content-Type: application/json');
        const raw = await readBody(req);
        try { body = raw ? JSON.parse(raw) : {}; } catch { throw new HttpError(400, 'Некорректный JSON'); }
        if (body === null || typeof body !== 'object' || Array.isArray(body)) throw new HttpError(400, 'Ожидается объект JSON');
      }
      const out = await r.handler({ req, res, user, params, body, query: url.searchParams });
      if (out && out.buffer) return send(res, out.status || 200, out.buffer, { 'Content-Length': out.buffer.length, ...(out.headers || {}) });
      if (out && out.raw) return send(res, out.status || 200, '', out.headers || {});
      return json(res, (out && out.status) || 200, (out && out.body) ?? {}, (out && out.headers) || {});
    }
    throw new HttpError(404, 'Не найдено');
  } catch (e) {
    if (e instanceof HttpError) return json(res, e.status, { error: e.message });
    if (e && e.status) return json(res, e.status, { error: e.message });
    console.error('[http]', req.method, pathname, e);
    return json(res, 500, { error: 'Внутренняя ошибка сервера' });
  }
}

function createServer() { return http.createServer((req, res) => { handle(req, res); }); }
module.exports = { createServer };
