(() => {
'use strict';

/* ================= утилиты ================= */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const pad = (n) => String(n).padStart(2, '0');
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const dkey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
const parseKey = (k) => { const [y, m, d] = k.split('-').map(Number); return new Date(y, m - 1, d); };
const addDays = (k, n) => { const d = parseKey(k); d.setDate(d.getDate() + n); return dkey(d); };
const ddmm = (k) => { const [, m, d] = k.split('-'); return `${d}.${m}`; };
const fmtMin = (ms) => { const m = Math.floor(ms / 60000); return m < 60 ? `${m} мин` : `${Math.floor(m / 60)} ч ${m % 60} мин`; };
const MONTHS = ['Январь', 'Февраль', 'Март', 'Апрель', 'Май', 'Июнь', 'Июль', 'Август', 'Сентябрь', 'Октябрь', 'Ноябрь', 'Декабрь'];
const MONTHS_G = ['января', 'февраля', 'марта', 'апреля', 'мая', 'июня', 'июля', 'августа', 'сентября', 'октября', 'ноября', 'декабря'];
const DOW_FULL = ['воскресенье', 'понедельник', 'вторник', 'среда', 'четверг', 'пятница', 'суббота'];
const DOW_SHORT = ['Вс', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'];
const CATS = { math: { n: 'Математика', c: 'var(--math)' }, java: { n: 'Java', c: 'var(--java)' }, study: { n: 'Учёба', c: 'var(--study)' }, other: { n: 'Другое', c: 'var(--other)' } };
const TYPES = { task: 'Задача', lesson: 'Урок', note: 'Заметка' };
const REMINDS = [[0, 'В момент начала'], [15, 'За 15 мин'], [30, 'За 30 мин'], [60, 'За 1 час'], [120, 'За 2 часа']];
const remindLabel = (m) => (m === 0 ? 'в момент начала' : m < 60 ? `за ${m} мин` : m % 60 === 0 ? `за ${m / 60} ч` : `за ${m} мин`);

// «сейчас» в часовом поясе пользователя
const tzFmt = {};
function tzNow(tz) {
  let f = tzFmt[tz];
  if (!f) {
    const base = { hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' };
    try { f = tzFmt[tz] = new Intl.DateTimeFormat('en-CA', { timeZone: tz, ...base }); } catch { f = tzFmt[tz] = new Intl.DateTimeFormat('en-CA', base); }
  }
  const o = {};
  f.formatToParts(new Date()).forEach((p) => { o[p.type] = p.value; });
  return { key: `${o.year}-${o.month}-${o.day}`, h: +o.hour % 24, mi: +o.minute };
}
const browserTz = () => Intl.DateTimeFormat().resolvedOptions().timeZone || 'Europe/Moscow';
const curTz = () => (S && S.user && S.user.tz) || browserTz();
const todayKey = () => tzNow(curTz()).key;

/* ================= состояние ================= */
let S = null;                 // { user, settings, tasks, study, today, timer, bot }
let viewMonth = new Date();
let sel = null;
let editingId = null;
let inflight = 0;
const UI = (() => { try { return { mode: 'pomodoro', taskId: '', ...JSON.parse(localStorage.getItem('tt_ui') || '{}') }; } catch { return { mode: 'pomodoro', taskId: '' }; } })();
const saveUI = () => { try { localStorage.setItem('tt_ui', JSON.stringify(UI)); } catch { /* ignore */ } };

/* ================= API ================= */
async function api(method, path, body, { quiet = false } = {}) {
  const opts = { method, credentials: 'same-origin', headers: {} };
  if (['POST', 'PUT', 'PATCH'].includes(method) || body !== undefined) { opts.headers['content-type'] = 'application/json'; opts.body = JSON.stringify(body ?? {}); }
  const mut = method !== 'GET';
  if (mut) inflight++;
  try {
    const r = await fetch('/api' + path, opts);
    let data = null;
    try { data = await r.json(); } catch { /* пусто */ }
    if (!r.ok) {
      const e = new Error((data && data.error) || `Ошибка ${r.status}`);
      e.status = r.status;
      if (r.status === 401 && !quiet) showLogin();
      throw e;
    }
    return data;
  } finally { if (mut) inflight--; }
}

function toast(title, text = '', err = false) {
  const el = document.createElement('div');
  el.className = 'toast' + (err ? ' err' : '');
  el.innerHTML = `<b>${esc(title)}</b>${esc(text)}`;
  $('#toasts').appendChild(el);
  setTimeout(() => el.remove(), err ? 8000 : 5500);
}
const fail = (e) => toast('Не получилось', e.message, true);
const openModal = (id) => $('#' + id).classList.add('open');
const closeModals = () => $$('.modal').forEach((m) => m.classList.remove('open'));
const modalOpen = () => $$('.modal.open').length > 0;

/* ================= вход через Telegram ================= */
let loginTimer = null, loginSeq = 0;
function showLogin() {
  $('#app').hidden = true;
  $('#login').hidden = false;
  if (new URLSearchParams(location.search).get('login') === 'expired') {
    history.replaceState(null, '', '/');
    $('#loginStatus').textContent = 'Ссылка из бота устарела — войди заново кнопкой ниже.';
  }
  startLogin();
}
async function startLogin() {
  clearTimeout(loginTimer);
  const seq = ++loginSeq;
  const link = $('#loginLink');
  link.setAttribute('aria-disabled', 'true');
  link.removeAttribute('href');
  $('#loginAlt').hidden = true;
  try {
    const r = await fetch('/api/auth/start', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
    const d = await r.json();
    if (!r.ok) throw new Error(d.error || 'Ошибка');
    if (seq !== loginSeq) return;
    if (!d.link) { $('#loginStatus').textContent = 'Бот ещё запускается — обнови страницу через минуту.'; $('#loginStatus').className = 'status err'; return; }
    link.href = d.link;
    link.setAttribute('aria-disabled', 'false');
    $('#loginBot').textContent = '@' + d.bot;
    $('#loginCmd').textContent = '/start login_' + d.code;
    $('#loginAlt').hidden = false;
    $('#loginStatus').className = 'status';
    if (!$('#loginStatus').textContent.startsWith('Ссылка из бота')) $('#loginStatus').textContent = 'Нажми кнопку, в Telegram — «Запустить» (Start). Страница обновится сама.';
    pollLogin(d.code, seq, Date.now());
  } catch (e) {
    $('#loginStatus').textContent = e.message;
    $('#loginStatus').className = 'status err';
  }
}
async function pollLogin(code, seq, since) {
  if (seq !== loginSeq) return;
  if (Date.now() - since > 9.5 * 60 * 1000) { startLogin(); return; }
  try {
    const r = await fetch('/api/auth/poll?code=' + encodeURIComponent(code), { credentials: 'same-origin' });
    const d = await r.json().catch(() => ({}));
    if (r.ok && d.ok) { loginSeq++; $('#login').hidden = true; await boot(); return; }
    if (r.status === 410) { startLogin(); return; }
  } catch { /* сеть — пробуем снова */ }
  loginTimer = setTimeout(() => pollLogin(code, seq, since), 2000);
}

/* ================= загрузка ================= */
async function loadState() {
  const st = await api('GET', '/state');
  S = st;
  return st;
}
async function refreshState() {
  try {
    const st = await api('GET', '/state', undefined, { quiet: true });
    S.tasks = st.tasks; S.study = st.study; S.settings = st.settings; S.user = st.user; S.bot = st.bot; S.features = st.features;
    if (pending.ms > 0) bumpStudy(pending.ms, 0, true);       // ещё не отправленное время не должно «откатываться»
    renderAll();
  } catch (e) { if (e.status === 401) showLogin(); }
}

async function boot() {
  try { await loadState(); } catch (e) {
    if (e.status === 401) return;                      // api() уже показал экран входа
    $('#login').hidden = false; $('#loginStatus').textContent = 'Сервер недоступен: ' + e.message; $('#loginStatus').className = 'status err'; return;
  }
  $('#login').hidden = true;
  $('#app').hidden = false;
  sel = todayKey();
  const d = parseKey(sel);
  viewMonth = new Date(d.getFullYear(), d.getMonth(), 1);
  restoreTimer();
  renderAll();
  if (!S.settings.onboarded) openOnboarding();
}

/* ================= расчёты ================= */
const classesFor = (key) => Sched.classesOn(S.settings, key);
const countable = (list) => list.filter((t) => t.type !== 'note');
const byDate = () => { const g = {}; for (const t of S.tasks) (g[t.date] = g[t.date] || []).push(t); return g; };
function streakOf() {
  const days = new Set(S.tasks.filter((t) => t.done && t.type !== 'note').map((t) => t.date));
  let k = todayKey(), n = 0;
  if (!days.has(k)) k = addDays(k, -1);
  while (days.has(k)) { n++; k = addDays(k, -1); }
  return n;
}
const studyOf = (k) => S.study[k] || { ms: 0, pomos: 0 };
function bumpStudy(ms, pomos, silent) {
  const k = todayKey();
  const cur = S.study[k] || { ms: 0, pomos: 0 };
  S.study[k] = { ms: cur.ms + ms, pomos: cur.pomos + pomos };
  if (!silent) { /* отрисовку делает тик таймера */ }
}
function planInfo(track = 'math') {
  const pl = S.tasks.filter((t) => t.plan && (t.track || 'math') === track);
  if (!pl.length) return null;
  const gen = Math.max(...pl.map((t) => t.planGen));
  const rows = pl.filter((t) => t.planGen === gen);
  const topics = rows.filter((t) => t.planKind === 'topic'), reps = rows.filter((t) => t.planKind === 'repeat');
  const next = rows.filter((t) => !t.done).sort((a, b) => a.date.localeCompare(b.date) || a.time.localeCompare(b.time))[0] || null;
  return {
    total: rows.length, done: rows.filter((t) => t.done).length,
    topicsTotal: topics.length, topicsDone: topics.filter((t) => t.done).length,
    repsTotal: reps.length, repsDone: reps.filter((t) => t.done).length, next,
  };
}

/* ================= отрисовка ================= */
function renderHeader() {
  const st = studyOf(todayKey());
  $('#chipTime').textContent = fmtMin(st.ms);
  $('#chipPomo').textContent = st.pomos;
  $('#chipStreak').textContent = streakOf() + ' дн.';
  $('#userName').textContent = S.user.name || (S.user.username ? '@' + S.user.username : 'Профиль');
}

function renderCalendar() {
  const y = viewMonth.getFullYear(), m = viewMonth.getMonth();
  $('#calTitle').textContent = `${MONTHS[m]} ${y}`;
  const off = (new Date(y, m, 1).getDay() + 6) % 7;
  const g = byDate();
  const today = todayKey();
  let html = '';
  for (let i = 0; i < 42; i++) {
    const d = new Date(y, m, 1 - off + i), k = dkey(d), list = g[k] || [];
    const cnt = countable(list), done = cnt.filter((t) => t.done).length;
    const cls = ['cell'];
    if (d.getMonth() !== m) cls.push('out');
    if (k === today) cls.push('today');
    if (k === sel) cls.push('sel');
    const cats = [...new Set(list.map((t) => t.cat))].map((c) => `<i style="background:${(CATS[c] || CATS.other).c}"></i>`);
    if (classesFor(k).length) cats.push('<i style="background:var(--class)"></i>');
    const pct = cnt.length ? Math.round((done / cnt.length) * 100) : 0;
    html += `<button class="${cls.join(' ')}" data-k="${k}" aria-label="${d.getDate()} ${MONTHS_G[d.getMonth()]}"><span class="n">${d.getDate()}</span><span class="dots">${cats.slice(0, 4).join('')}</span>${cnt.length ? `<span class="mini"><b style="width:${pct}%"></b></span>` : '<span class="mini" style="background:none"></span>'}</button>`;
  }
  $('#calGrid').innerHTML = html;
}

function renderDay() {
  const d = parseKey(sel);
  $('#dayTitle').textContent = `${d.getDate()} ${MONTHS_G[d.getMonth()]}`;
  $('#daySub').textContent = DOW_FULL[d.getDay()] + (sel === todayKey() ? ' · сегодня' : '');
  const list = (byDate()[sel] || []).slice().sort((a, b) => a.time.localeCompare(b.time) || a.title.localeCompare(b.title));
  const cnt = countable(list), done = cnt.filter((t) => t.done).length, pct = cnt.length ? Math.round((done / cnt.length) * 100) : 0;
  $('#dayBar').style.width = pct + '%';
  $('#dayCount').textContent = cnt.length ? `Выполнено ${done} из ${cnt.length} · ${pct}%` : 'Нет задач на этот день';
  $('#dayMsg').textContent = !cnt.length ? '' : pct === 100 ? 'День закрыт! 🔥' : pct >= 50 ? 'Больше половины — не сбавляй темп' : pct > 0 ? 'Хороший старт, продолжай' : 'Начни с самой простой задачи';
  const classes = classesFor(sel).map((c) => `<div class="task klass">
      <div class="note-ico">🎓</div>
      <div class="t-main"><div class="t-title">${esc(c.title)}</div>
      <div class="t-meta"><span>🕐 ${c.start}–${c.end}</span><span class="tag" style="color:var(--class)">Пара</span>${c.kind ? `<span>${esc(c.kind)}</span>` : ''}${c.room ? `<span>📍 ${esc(c.room)}</span>` : ''}${c.teacher ? `<span>👤 ${esc(c.teacher)}</span>` : ''}</div></div></div>`).join('');
  if (!list.length && !classes) { $('#taskList').innerHTML = '<div class="empty">На этот день пока ничего нет.<br>Нажми «Добавить» или сгенерируй план обучения.</div>'; return; }
  const items = list.map((t) => {
    const c = CATS[t.cat] || CATS.other, isNote = t.type === 'note';
    const rem = t.time && t.remind.length ? `🔔 ${[...t.remind].sort((a, b) => b - a).map(remindLabel).join(', ')}` : '';
    const spent = t.spentMs > 0 || t.est ? `⏱ ${fmtMin(t.spentMs || 0)}${t.est ? ' / ' + t.est + ' мин' : ''}` : '';
    const badge = t.planKind === 'repeat' ? `<span class="tag" style="color:var(--repeat)">Повторение · день ${t.planIdx + 1}</span>`
      : t.plan ? `<span>План · день ${t.planIdx + 1}</span>` : '';
    return `<div class="task${t.done ? ' done' : ''}${UI.taskId === t.id ? ' active' : ''}" data-id="${esc(t.id)}" style="--c:${t.planKind === 'repeat' ? 'var(--repeat)' : c.c}">
      ${isNote ? '<div class="note-ico">📝</div>' : '<button class="chk" data-act="toggle" aria-label="Отметить выполненным"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3.5" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5L20 7"/></svg></button>'}
      <div class="t-main">
        <div class="t-title">${esc(t.title)}</div>
        <div class="t-meta">${t.time ? `<span>🕐 ${t.time}</span>` : ''}<span class="tag" style="color:${c.c}">${c.n}</span><span>${TYPES[t.type]}</span>${badge}${spent ? `<span>${spent}</span>` : ''}${rem ? `<span>${rem}</span>` : ''}</div>
        ${t.note ? `<div class="t-note">${esc(t.note)}</div>` : ''}
      </div>
      <div class="t-act">
        ${isNote ? '' : '<button class="icon" data-act="timer" title="Запустить таймер на этой задаче" aria-label="Запустить таймер">▶</button>'}
        <button class="icon" data-act="edit" title="Редактировать" aria-label="Редактировать">✎</button>
      </div></div>`;
  }).join('');
  $('#taskList').innerHTML = classes + items;
}

function renderPlanCard(track, ids) {
  const p = planInfo(track);
  const $$id = (k) => $('#' + ids[k]);
  if (!p) {
    $$id('stat').textContent = 'План не создан'; $$id('pct').textContent = ''; $$id('bar').style.width = '0'; $$id('rep').textContent = '';
    $$id('next').style.display = 'none';
    return false;
  }
  const pct = Math.round((p.done / p.total) * 100);
  $$id('stat').textContent = `Тем: ${p.topicsDone} из ${p.topicsTotal}`;
  $$id('pct').textContent = pct + '%';
  $$id('bar').style.width = pct + '%';
  $$id('rep').textContent = p.repsTotal ? `Повторений: ${p.repsDone} из ${p.repsTotal}` : 'Повторения выключены';
  const el = $$id('next');
  el.style.display = '';
  if (p.next) { el.dataset.k = p.next.date; el.innerHTML = `<span class="muted">Ближайшее · ${ddmm(p.next.date)} ${esc(p.next.time)}</span><br><b>${esc(p.next.title)}</b>`; }
  else { el.dataset.k = ''; el.innerHTML = '🎉 <b>План выполнен!</b> Создай новый цикл.'; }
  return true;
}
const hasJava = () => !!(S.features && S.features.java);
function renderPlan() {
  const m = renderPlanCard('math', { stat: 'planStat', pct: 'planPct', bar: 'planBar', rep: 'planRep', next: 'planNext' });
  $('#javaCard').style.display = hasJava() ? '' : 'none';
  const j = hasJava() ? renderPlanCard('java', { stat: 'javaStat', pct: 'javaPct', bar: 'javaBar', rep: 'javaRep', next: 'javaNext' }) : false;
  $('#planShift').disabled = !(m || j);
}

function renderStats() {
  const today = todayKey();
  const days = [];
  for (let i = 13; i >= 0; i--) { const k = addDays(today, -i); days.push({ k, ms: studyOf(k).ms, pomos: studyOf(k).pomos }); }
  const max = Math.max(60 * 60000, ...days.map((d) => d.ms));
  $('#bars').innerHTML = days.map((d) => `<div class="bar${d.ms ? '' : ' zero'}${d.k === today ? ' today' : ''}" title="${ddmm(d.k)}: ${fmtMin(d.ms)}"><i style="height:${Math.max(2, Math.round((d.ms / max) * 88))}px"></i><span>${parseKey(d.k).getDate()}</span></div>`).join('');
  const week = days.slice(7);
  const weekMs = week.reduce((a, d) => a + d.ms, 0), weekPomos = week.reduce((a, d) => a + d.pomos, 0);
  const p = planInfo();
  const cells = [
    [fmtMin(weekMs), 'за 7 дней'],
    [fmtMin(Math.round(weekMs / 7)), 'в среднем в день'],
    [String(weekPomos), 'помодоро за 7 дней'],
    [streakOf() + ' дн.', 'серия с выполненными задачами'],
  ];
  if (p) { cells.push([`${p.topicsDone}/${p.topicsTotal}`, 'тем плана']); cells.push([`${p.repsDone}/${p.repsTotal}`, 'повторений']); }
  const pj = hasJava() ? planInfo('java') : null;
  if (pj) cells.push([`${pj.topicsDone}/${pj.topicsTotal}`, 'тем Java']);
  $('#statsGrid').innerHTML = cells.map(([v, l]) => `<div class="stat"><b>${esc(v)}</b><span>${esc(l)}</span></div>`).join('');
}

function renderAll() { renderHeader(); renderCalendar(); renderDay(); renderPlan(); renderStats(); renderTimer(); }

/* ================= задачи ================= */
function remindChecks(el, selected, name) {
  el.innerHTML = REMINDS.map(([m, l]) => `<label><input type="checkbox" name="${name}" value="${m}"${selected.includes(m) ? ' checked' : ''}>${l}</label>`).join('');
}
const checked = (name) => $$(`input[name=${name}]:checked`).map((i) => +i.value);

function openTask(id) {
  editingId = id || null;
  const t = id ? S.tasks.find((x) => x.id === id) : null;
  $('#mTaskTitle').textContent = t ? 'Редактировать' : 'Новая запись';
  $('#fTitle').value = t ? t.title : '';
  $('#fDate').value = t ? t.date : sel;
  let def = '';
  if (!t) { const n = tzNow(curTz()); def = $('#fDate').value === n.key ? `${pad(Math.min(n.h + 1, 23))}:00` : '10:00'; }
  $('#fTime').value = t ? t.time : def;
  $('#fType').value = t ? t.type : 'task';
  const fc = $('#fCat');
  if (hasJava() && !fc.querySelector('option[value="java"]')) fc.insertAdjacentHTML('afterbegin', '<option value="java">Java</option>');
  fc.value = t ? t.cat : 'study';
  $('#fNote').value = t ? t.note : '';
  $('#fEst').value = t && t.est ? t.est : '';
  remindChecks($('#fRemind'), t ? t.remind : S.settings.defaultRemind, 'rm');
  $('#fDelete').style.display = t ? '' : 'none';
  openModal('mTask');
  setTimeout(() => $('#fTitle').focus(), 50);
}
async function saveTask() {
  const title = $('#fTitle').value.trim();
  if (!title) { $('#fTitle').focus(); return; }
  const body = {
    title, date: $('#fDate').value || sel, time: $('#fTime').value || '', type: $('#fType').value, cat: $('#fCat').value,
    note: $('#fNote').value.trim(), est: +$('#fEst').value || 0, remind: checked('rm'),
  };
  try {
    let t;
    if (editingId) { t = await api('PATCH', '/tasks/' + editingId, body); S.tasks = S.tasks.map((x) => (x.id === t.id ? t : x)); }
    else { t = await api('POST', '/tasks', body); S.tasks.push(t); }
    sel = t.date;
    const d = parseKey(sel); viewMonth = new Date(d.getFullYear(), d.getMonth(), 1);
    closeModals(); renderAll();
    if (body.time && body.remind.length && !S.settings.tgOn) toast('Напоминания выключены', 'Включи их в настройках, чтобы сообщения приходили в Telegram.');
  } catch (e) { fail(e); }
}
async function toggleDone(t) {
  t.done = !t.done; renderAll();
  try { Object.assign(t, await api('PATCH', '/tasks/' + t.id, { done: t.done })); renderAll(); }
  catch (e) { t.done = !t.done; renderAll(); fail(e); }
}

/* ================= таймер ================= */
const MODES = { pomodoro: { w: 25, b: 5 }, deep: { w: 50, b: 10 }, custom: {}, stopwatch: {} };
const T = { running: false, phase: 'work', remaining: 0, total: 0, elapsed: 0, last: Date.now() };
let pending = { ms: 0, taskId: '', pomo: 0 };
let tickN = 0, audio = null;

function cfg() {
  if (UI.mode === 'custom') return { w: Math.max(1, +S.settings.custom.work || 25), b: Math.max(0, +S.settings.custom.brk || 0) };
  const m = MODES[UI.mode];
  return m && m.w ? { w: m.w, b: m.b } : { w: 0, b: 0 };
}
const linkedTask = () => S.tasks.find((t) => t.id === UI.taskId) || null;
function unlockAudio() { try { audio = audio || new (window.AudioContext || window.webkitAudioContext)(); if (audio.state === 'suspended') audio.resume(); } catch { /* ignore */ } }
function beep() {
  try {
    unlockAudio(); if (!audio) return;
    [0, 0.22, 0.44].forEach((t, i) => {
      const o = audio.createOscillator(), g = audio.createGain();
      o.type = 'sine'; o.frequency.value = [660, 880, 1100][i]; o.connect(g); g.connect(audio.destination);
      const n = audio.currentTime + t;
      g.gain.setValueAtTime(0.0001, n); g.gain.exponentialRampToValueAtTime(0.25, n + 0.02); g.gain.exponentialRampToValueAtTime(0.0001, n + 0.2);
      o.start(n); o.stop(n + 0.22);
    });
  } catch { /* ignore */ }
}

function resetTimer() {
  T.running = false; T.phase = 'work'; const c = cfg();
  T.total = c.w * 60000; T.remaining = T.total; T.elapsed = 0; T.last = Date.now();
}
function restoreTimer() {
  resetTimer();
  const t = S.timer;
  if (!t || t.endsAt <= Date.now()) return;
  if (['pomodoro', 'deep', 'custom'].includes(t.mode)) UI.mode = t.mode;
  if (t.taskId) UI.taskId = t.taskId;
  saveUI();
  const c = cfg();
  T.phase = t.phase; T.total = (t.phase === 'work' ? c.w : c.b) * 60000;
  T.remaining = Math.min(T.total || Infinity, t.endsAt - Date.now());
  T.running = true; T.last = Date.now();
}
function syncTimer(fireOnly) {
  const quiet = { quiet: true };
  if (UI.mode === 'stopwatch' || !T.running) { if (!fireOnly) api('DELETE', '/timer', undefined, quiet).catch(() => {}); return; }
  api('PUT', '/timer', { phase: T.phase, mode: UI.mode, workMin: cfg().w, breakMin: cfg().b, taskId: UI.taskId || '', endsAt: Date.now() + T.remaining }, quiet).catch(() => {});
}
function addStudyLocal(ms) {
  if (ms <= 0) return;
  bumpStudy(ms, 0, true);
  const t = linkedTask(); if (t) t.spentMs = (t.spentMs || 0) + ms;
  if (pending.taskId !== (UI.taskId || '') && pending.ms > 0) flushLog();
  pending.taskId = UI.taskId || '';
  pending.ms += ms;
}
function flushLog(beacon) {
  if (pending.ms <= 0 && !pending.pomo) return;
  const payload = { ms: Math.round(pending.ms), pomo: pending.pomo };
  if (pending.taskId) payload.taskId = pending.taskId;
  pending = { ms: 0, taskId: UI.taskId || '', pomo: 0 };
  if (beacon && navigator.sendBeacon) { navigator.sendBeacon('/api/log', new Blob([JSON.stringify(payload)], { type: 'application/json' })); return; }
  api('POST', '/log', payload, { quiet: true }).catch(() => { pending.ms += payload.ms; pending.pomo += payload.pomo; });
}
function toggleTimer() {
  unlockAudio();
  if (T.running) { T.running = false; flushLog(); syncTimer(); }
  else {
    if (UI.mode !== 'stopwatch' && T.remaining <= 0) resetTimer();
    T.running = true; T.last = Date.now(); syncTimer();
  }
  renderTimer();
}
function phaseEnd(manual) {
  const c = cfg(), task = linkedTask();
  if (T.phase === 'work') {
    if (!manual) {
      pending.pomo += 1; bumpStudy(0, 1, true);
      const msg = `Сессия ${c.w} мин завершена${task ? ` · ${task.title}` : ''}${c.b ? `\nПерерыв ${c.b} мин.` : ''}`;
      toast('🍅 Время вышло!', msg); beep();
    }
    T.phase = c.b > 0 ? 'break' : 'work'; T.total = (c.b > 0 ? c.b : c.w) * 60000;
  } else {
    if (!manual) { toast('☕ Перерыв закончился', 'Пора возвращаться к работе'); beep(); }
    T.phase = 'work'; T.total = c.w * 60000;
  }
  T.remaining = T.total; T.last = Date.now();
  if (!manual) T.running = !!S.settings.autoStart;
  flushLog();
  // обычное завершение: серверный таймер сам пришлёт сообщение; при автозапуске ставим следующий
  if (manual) syncTimer(); else if (T.running) syncTimer(true);
  renderTimer(); renderHeader(); renderDay(); renderStats();
}
function skipPhase() {
  if (UI.mode === 'stopwatch') return;
  const was = T.running; T.remaining = 0; phaseEnd(true); T.running = was; T.last = Date.now(); syncTimer(); renderTimer();
}
function timerTick() {
  const now = Date.now();
  if (!T.running) { T.last = now; return; }
  const dt = now - T.last; T.last = now;
  if (UI.mode === 'stopwatch') { T.elapsed += dt; addStudyLocal(dt); }
  else {
    if (T.phase === 'work') addStudyLocal(Math.min(dt, Math.max(T.remaining, 0)));
    T.remaining -= dt;
    if (T.remaining <= 0) { T.remaining = 0; phaseEnd(false); return; }
  }
  if (++tickN % 10 === 0) flushLog();
  renderTimer(true);
}
const fmtClock = (ms) => { const s = Math.max(0, Math.round(ms / 1000)), h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), ss = s % 60; return h ? `${h}:${pad(m)}:${pad(ss)}` : `${pad(m)}:${pad(ss)}`; };

function renderTimer(light) {
  if (!S) return;
  const sw = UI.mode === 'stopwatch';
  $('#tTime').textContent = sw ? fmtClock(T.elapsed) : fmtClock(T.remaining);
  const C = 326.7, prog = sw ? (T.elapsed % 3600000) / 3600000 : (T.total ? 1 - T.remaining / T.total : 0);
  $('#ringFg').style.strokeDashoffset = String(C * (sw ? 1 - prog : prog));
  $('#ring').classList.toggle('break', !sw && T.phase === 'break');
  $('#tPhase').textContent = sw ? 'Секундомер' : T.phase === 'work' ? 'Фокус' : 'Перерыв';
  $('#tStart').textContent = T.running ? '⏸ Пауза' : (sw ? (T.elapsed ? '▶ Продолжить' : '▶ Старт') : (T.total && T.remaining < T.total ? '▶ Продолжить' : '▶ Старт'));
  document.title = T.running ? `${$('#tTime').textContent} · ${$('#tPhase').textContent}` : 'Трекер учёбы';
  const st = studyOf(todayKey());
  $('#sTime').textContent = fmtMin(st.ms); $('#sPomo').textContent = st.pomos;
  $('#chipTime').textContent = fmtMin(st.ms); $('#chipPomo').textContent = st.pomos;
  if (light) return;
  $$('#modes button').forEach((b) => b.classList.toggle('on', b.dataset.m === UI.mode));
  $('#customBox').style.display = UI.mode === 'custom' ? '' : 'none';
  $('#cWork').value = S.settings.custom.work; $('#cBreak').value = S.settings.custom.brk;
  $('#autoStart').checked = !!S.settings.autoStart;
  $('#tSkip').style.display = sw ? 'none' : '';
  $('#timerHint').textContent = sw ? 'считает вперёд' : `${cfg().w} мин работа${cfg().b ? ` · ${cfg().b} мин отдых` : ''}`;
  const today = todayKey(), seen = new Set(), opts = [];
  const g = byDate();
  const cand = [...(g[today] || []), ...(sel !== today ? (g[sel] || []) : [])].filter((t) => t.type !== 'note' && (!t.done || t.id === UI.taskId));
  for (const t of cand.sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))) {
    if (seen.has(t.id)) continue; seen.add(t.id);
    opts.push(`<option value="${esc(t.id)}">${ddmm(t.date)}${t.time ? ' ' + t.time : ''} · ${esc(t.title.length > 46 ? t.title.slice(0, 46) + '…' : t.title)}</option>`);
  }
  const cur = linkedTask();
  if (cur && !seen.has(cur.id)) opts.unshift(`<option value="${esc(cur.id)}">${ddmm(cur.date)} · ${esc(cur.title.slice(0, 46))}</option>`);
  $('#tTask').innerHTML = '<option value="">— без привязки —</option>' + opts.join('');
  $('#tTask').value = cur ? cur.id : '';
  $('#sTask').innerHTML = cur ? `<span>На задаче: <b>${fmtMin(cur.spentMs || 0)}</b>${cur.est ? ' из ' + cur.est + ' мин' : ''}</span>` : '';
}

/* ================= план ================= */
async function doShift() {
  try {
    const r = await api('POST', '/plan/shift', {});
    await loadState();
    sel = todayKey(); const d = parseKey(sel); viewMonth = new Date(d.getFullYear(), d.getMonth(), 1);
    renderAll(); toast('Расписание сдвинуто', `Тема дня ${r.firstDay} теперь на сегодня.`);
  } catch (e) { fail(e); }
}
function fillPlanModal(track) {
  const p = planInfo(track);
  const from = p && p.next ? Math.min(28, p.next.planIdx + 1) : 1;
  $('#pDate').value = todayKey(); $('#pFrom').value = from;
  const pl = track === 'java' ? S.settings.java : S.settings.plan;
  $('#pInfo').textContent = `Тема в ${pl.topicTime} (${pl.topicMin} мин)${pl.repeatOn ? `; повторение через ${pl.repeatAfter} дн. в ${pl.repeatTime} (${pl.repeatMin} мин)` : '; повторения выключены'}. Изменить — в настройках.`;
}
function openPlanModal(track = 'math') {
  $('#pTrackBox').style.display = hasJava() ? '' : 'none';
  $('#pTrack').value = track === 'java' && hasJava() ? 'java' : 'math';
  fillPlanModal($('#pTrack').value);
  openModal('mPlan');
}
async function generatePlan(startDate, fromDay, track = 'math') {
  const r = await api('POST', '/plan/generate', { startDate, fromDay, track });
  await loadState();
  sel = startDate; const d = parseKey(sel); viewMonth = new Date(d.getFullYear(), d.getMonth(), 1);
  return r;
}

/* ================= первый запуск ================= */
function openOnboarding() {
  const s = S.settings;
  $('#oTz').value = browserTz(); $('#oDate').value = todayKey(); $('#oTime').value = s.plan.topicTime;
  $('#oRepeat').checked = s.plan.repeatOn; $('#oRepeatTime').value = s.plan.repeatTime;
  $('#oSched').checked = true; $('#oDigest').checked = s.digest; $('#oDigestTime').value = s.digestTime;
  openModal('mOnb');
}
async function finishOnboarding(withPlan) {
  const body = {
    onboarded: true, tz: $('#oTz').value.trim() || browserTz(),
    plan: { topicTime: $('#oTime').value || '19:00', repeatOn: $('#oRepeat').checked, repeatTime: $('#oRepeatTime').value || '20:00' },
    digest: $('#oDigest').checked, digestTime: $('#oDigestTime').value || '08:00',
  };
  if (!$('#oSched').checked) body.schedule = [];
  try {
    const r = await api('PUT', '/settings', body);
    S.settings = r.settings; S.user.tz = r.tz;
    if (withPlan) await generatePlan($('#oDate').value || todayKey(), 1); else await loadState();
    closeModals(); renderAll();
    toast(withPlan ? 'План создан' : 'Готово', withPlan ? 'Первая тема уже в календаре.' : 'Настройки сохранены.');
  } catch (e) { fail(e); }
}

/* ================= настройки ================= */
const mdLabel = (x) => x.slice(3) + '.' + x.slice(0, 2);
const rangesLabel = (r) => (r || []).map(([a, b]) => (a === b ? mdLabel(a) : mdLabel(a) + '–' + mdLabel(b))).join(', ');
const schedRowHtml = (c) => {
  const ex = { kind: c.kind || '', week: c.week || '', ranges: c.ranges || [] };
  const tags = [ex.kind, ex.week ? 'неделя ' + ex.week : '', ex.ranges.length ? 'даты: ' + rangesLabel(ex.ranges) : ''].filter(Boolean).join(' · ');
  return `<div class="sched-row" data-id="${esc(c.id)}" data-extra="${esc(JSON.stringify(ex))}">
  <select class="s-dow">${[1, 2, 3, 4, 5, 6, 0].map((d) => `<option value="${d}"${d === c.dow ? ' selected' : ''}>${DOW_SHORT[d]}</option>`).join('')}</select>
  <input type="time" class="s-start" value="${esc(c.start)}"><input type="time" class="s-end" value="${esc(c.end)}">
  <input type="text" class="s-title" value="${esc(c.title)}" maxlength="160" placeholder="Название">
  <button class="icon s-del" title="Удалить" aria-label="Удалить пару">✕</button>
  <div class="s-sub"><input type="text" class="s-room" value="${esc(c.room || '')}" maxlength="80" placeholder="Аудитория"><input type="text" class="s-teacher" value="${esc(c.teacher || '')}" maxlength="120" placeholder="Преподаватель">
  ${tags ? `<div class="small muted s-tags">${esc(tags)}</div>` : ''}</div></div>`;
};
function readSchedule() {
  return $$('#schedRows .sched-row').map((r, i) => {
    let ex = {}; try { ex = JSON.parse(r.dataset.extra || '{}'); } catch { /* пусто */ }
    return {
      id: r.dataset.id || 'c' + i, dow: +$('.s-dow', r).value, start: $('.s-start', r).value || '09:00', end: $('.s-end', r).value || '10:00',
      title: $('.s-title', r).value.trim() || 'Пара', room: $('.s-room', r).value.trim(), teacher: $('.s-teacher', r).value.trim(),
      kind: ex.kind || '', week: ex.week || '', ranges: ex.ranges || [],
    };
  });
}
function openSettings() {
  const s = S.settings;
  $('#tgStatus').textContent = `Подключено: ${S.user.name || 'без имени'}${S.user.username ? ' (@' + S.user.username + ')' : ''}. Напоминания приходят от бота${S.bot ? ' @' + S.bot : ''}.`;
  const link = $('#sBotLink'); if (S.bot) link.href = 'https://t.me/' + S.bot; else link.style.display = 'none';
  $('#sOn').checked = s.tgOn; $('#sTimerNotify').checked = s.notifyTimer; $('#sDigest').checked = s.digest; $('#sDigestTime').value = s.digestTime;
  remindChecks($('#sRemind'), s.defaultRemind, 'dr');
  $('#sTz').value = S.user.tz;
  $('#sTopicTime').value = s.plan.topicTime; $('#sTopicMin').value = s.plan.topicMin; $('#sRepeatOn').checked = s.plan.repeatOn;
  $('#sRepeatAfter').value = s.plan.repeatAfter; $('#sRepeatTime').value = s.plan.repeatTime; $('#sRepeatMin').value = s.plan.repeatMin;
  $('#javaSet').style.display = hasJava() ? '' : 'none';
  if (hasJava()) {
    const j = s.java;
    $('#jTopicTime').value = j.topicTime; $('#jTopicMin').value = j.topicMin; $('#jRepeatOn').checked = j.repeatOn;
    $('#jRepeatAfter').value = j.repeatAfter; $('#jRepeatTime').value = j.repeatTime; $('#jRepeatMin').value = j.repeatMin;
  }
  $('#schedRows').innerHTML = s.schedule.map(schedRowHtml).join('');
  $('#sTopWeek').value = s.topWeek || '';
  $('#gQ').value = s.group || ''; $('#gList').innerHTML = '';
  openModal('mSet');
}
async function saveSettings() {
  const body = {
    tgOn: $('#sOn').checked, notifyTimer: $('#sTimerNotify').checked, digest: $('#sDigest').checked, digestTime: $('#sDigestTime').value || '08:00',
    defaultRemind: checked('dr'), tz: $('#sTz').value.trim() || S.user.tz,
    plan: { topicTime: $('#sTopicTime').value || '19:00', topicMin: +$('#sTopicMin').value || 45, repeatOn: $('#sRepeatOn').checked, repeatAfter: +$('#sRepeatAfter').value || 5, repeatTime: $('#sRepeatTime').value || '20:00', repeatMin: +$('#sRepeatMin').value || 60 },
    schedule: readSchedule(), topWeek: $('#sTopWeek').value || '', group: $('#gQ').value.trim(),
  };
  if (hasJava()) body.java = { topicTime: $('#jTopicTime').value || '21:00', topicMin: +$('#jTopicMin').value || 60, repeatOn: $('#jRepeatOn').checked, repeatAfter: +$('#jRepeatAfter').value || 5, repeatTime: $('#jRepeatTime').value || '22:00', repeatMin: +$('#jRepeatMin').value || 30 };
  try {
    const r = await api('PUT', '/settings', body);
    S.settings = r.settings; S.user.tz = r.tz;
    closeModals(); renderAll(); toast('Настройки сохранены');
  } catch (e) { fail(e); }
}

/* ================= рейтинг ================= */
let ratingScope = 'week';
const initial = (name) => esc((String(name).replace(/^@/, '').trim()[0] || '?').toUpperCase());
async function loadRating() {
  try {
    const r = await api('GET', '/rating?scope=' + ratingScope);
    $('#rList').innerHTML = r.entries.length ? r.entries.map((x) => `<div class="rrow${x.me ? ' me' : ''}"><span class="rk">${x.rank}</span>
      <span class="av">${initial(x.name)}${x.photo ? `<img src="/api/avatar/${esc(x.pid)}" alt="" loading="lazy">` : ''}</span>
      <span class="rn">${esc(x.name)}${x.me ? ' (ты)' : ''}</span><span class="rx">${x.xp} оч.</span></div>`).join('')
      : '<div class="empty">Пока никого нет. Запусти таймер и вступи в рейтинг — будешь первым.</div>';
    $('#rMe').textContent = !r.me.on ? 'Ты пока не участвуешь в рейтинге.' : r.me.rank ? `Твоё место: ${r.me.rank} из ${r.total} · ${r.me.xp} оч.` : 'Занимайся с таймером — и ты появишься в таблице.';
  } catch (e) { fail(e); }
}
function openRating() {
  const rt = S.settings.rating || {};
  $('#rOn').checked = !!rt.on; $('#rNick').value = rt.nick || ''; $('#rPhoto').checked = rt.photo !== false;
  openModal('mRating'); loadRating();
}

/* ================= события ================= */
function bind() {
  $('#calGrid').addEventListener('click', (e) => {
    const b = e.target.closest('.cell'); if (!b) return;
    sel = b.dataset.k; const d = parseKey(sel);
    if (d.getMonth() !== viewMonth.getMonth()) viewMonth = new Date(d.getFullYear(), d.getMonth(), 1);
    renderCalendar(); renderDay(); renderTimer();
  });
  $('#prevM').onclick = () => { viewMonth = new Date(viewMonth.getFullYear(), viewMonth.getMonth() - 1, 1); renderCalendar(); };
  $('#nextM').onclick = () => { viewMonth = new Date(viewMonth.getFullYear(), viewMonth.getMonth() + 1, 1); renderCalendar(); };
  $('#todayBtn').onclick = () => { sel = todayKey(); const d = parseKey(sel); viewMonth = new Date(d.getFullYear(), d.getMonth(), 1); renderAll(); };
  $('#addBtn').onclick = () => openTask(null);
  $('#taskList').addEventListener('click', (e) => {
    const row = e.target.closest('.task'); if (!row || !row.dataset.id) return;
    const t = S.tasks.find((x) => x.id === row.dataset.id); if (!t) return;
    const act = e.target.closest('[data-act]');
    if (!act) return;
    if (act.dataset.act === 'toggle') toggleDone(t);
    else if (act.dataset.act === 'edit') openTask(t.id);
    else if (act.dataset.act === 'timer') {
      flushLog(); UI.taskId = t.id; saveUI(); pending.taskId = t.id;
      if (!T.running) toggleTimer(); else syncTimer();
      renderTimer(); renderDay(); $('#ring').scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
  });
  $('#fSave').onclick = saveTask;

  // очистка календаря
  $('#clearBtn').onclick = () => { $('#cTasks').checked = true; $('#cStats').checked = false; $('#cSched').checked = false; openModal('mClear'); };
  $('#cGo').onclick = async () => {
    const body = { confirm: true, tasks: $('#cTasks').checked, stats: $('#cStats').checked, schedule: $('#cSched').checked };
    if (!body.tasks && !body.stats && !body.schedule) { toast('Ничего не выбрано', 'Отметь, что очистить.', true); return; }
    try {
      const r = await api('POST', '/clear', body);
      await loadState(); closeModals(); renderAll();
      toast('Календарь очищен', `Задач удалено: ${r.tasks}${body.stats ? `, дней статистики: ${r.stats}` : ''}${body.schedule ? `, пар: ${r.schedule}` : ''}.`);
    } catch (e) { fail(e); }
  };

  // загрузка плана из .json
  $('#importBtn').onclick = () => { $('#iFile').value = ''; $('#iStart').value = todayKey(); $('#iResult').textContent = ''; openModal('mImport'); };
  $('#iGo').onclick = async () => {
    const f = $('#iFile').files[0];
    if (!f) { toast('Выбери файл', 'Нужен файл .json со списком задач.', true); return; }
    if (f.size > 480 * 1024) { toast('Файл слишком большой', 'Максимум около 480 КБ.', true); return; }
    let doc;
    try { doc = JSON.parse((await f.text()).replace(/^\uFEFF/, '')); } catch { toast('Не получилось прочитать файл', 'Это не корректный JSON — проверь запятые и кавычки.', true); return; }
    try {
      const r = await api('POST', '/plan/import', { doc, startDate: $('#iStart').value || undefined });
      await loadState(); renderAll();
      const bad = r.errorCount ? ` Пропущено с ошибкой: ${r.errorCount}${r.errors.length ? ' (например, №' + r.errors[0].index + ': ' + r.errors[0].error + ')' : ''}.` : '';
      $('#iResult').textContent = `Добавлено: ${r.added}, уже было: ${r.skipped}.${bad}`;
      toast('План загружен', `Добавлено задач: ${r.added}.`);
    } catch (e) { fail(e); }
  };

  // расписание с сайта вуза
  $('#gFind').onclick = async () => {
    const q = $('#gQ').value.trim();
    if (q.length < 2) { toast('Введи название группы', 'Хотя бы 2 символа, например «ПМИ».', true); return; }
    try {
      const r = await api('GET', '/herzen/groups?q=' + encodeURIComponent(q));
      $('#gList').innerHTML = r.groups.length ? r.groups.map((g) => `<button class="btn sm" data-gid="${esc(g.id)}" data-gname="${esc(g.name)}">${esc(g.name)}</button>`).join('') : '<span class="small muted">Ничего не найдено.</span>';
    } catch (e) { fail(e); }
  };
  $('#gQ').addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); $('#gFind').click(); } });
  $('#gList').addEventListener('click', async (e) => {
    const b = e.target.closest('[data-gid]'); if (!b) return;
    try {
      const r = await api('POST', '/herzen/classes', { groupId: b.dataset.gid });
      $('#schedRows').innerHTML = r.schedule.map(schedRowHtml).join('');
      if (!$('#sTopWeek').value) $('#sTopWeek').value = r.topWeek || '';
      $('#gQ').value = b.dataset.gname; $('#gList').innerHTML = '';
      toast('Расписание загружено', `Пар: ${r.schedule.length}. Проверь список и нажми «Сохранить». Какая неделя верхняя (В) — поправь дату выше.`);
    } catch (err) { fail(err); }
  });

  // рейтинг
  $('#ratingBtn').onclick = () => { ratingScope = 'week'; $$('#rTabs button').forEach((x) => x.classList.toggle('on', x.dataset.s === 'week')); openRating(); };
  $('#rTabs').addEventListener('click', (e) => { const b = e.target.closest('button'); if (!b) return; ratingScope = b.dataset.s; $$('#rTabs button').forEach((x) => x.classList.toggle('on', x === b)); loadRating(); });
  $('#rList').addEventListener('error', (e) => { if (e.target.tagName === 'IMG') e.target.remove(); }, true);
  $('#rSave').onclick = async () => {
    try {
      const r = await api('PUT', '/settings', { rating: { on: $('#rOn').checked, nick: $('#rNick').value.trim(), photo: $('#rPhoto').checked } });
      S.settings = r.settings; await loadRating(); toast('Сохранено', $('#rOn').checked ? 'Ты в рейтинге.' : 'Тебя нет в рейтинге.');
    } catch (e) { fail(e); }
  };
  $('#fTitle').addEventListener('keydown', (e) => { if (e.key === 'Enter') saveTask(); });
  $('#fDelete').onclick = async () => {
    if (!editingId || !confirm('Удалить эту запись?')) return;
    try {
      await api('DELETE', '/tasks/' + editingId);
      S.tasks = S.tasks.filter((x) => x.id !== editingId);
      if (UI.taskId === editingId) { UI.taskId = ''; saveUI(); }
      closeModals(); renderAll();
    } catch (e) { fail(e); }
  };
  $('#fTime').addEventListener('input', () => { $('#fRemindHint').textContent = $('#fTime').value ? 'Сообщение придёт в выбранные моменты до начала.' : 'Напоминания работают, если задано время.'; });
  $$('[data-close]').forEach((b) => { b.onclick = closeModals; });
  $$('.modal').forEach((m) => m.addEventListener('mousedown', (e) => { if (e.target === m && m.id !== 'mOnb') closeModals(); }));
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && !$('#mOnb').classList.contains('open')) closeModals(); });

  // таймер
  $('#modes').addEventListener('click', (e) => {
    const b = e.target.closest('button'); if (!b) return;
    flushLog(); UI.mode = b.dataset.m; saveUI(); resetTimer(); syncTimer(); renderTimer();
  });
  $('#tStart').onclick = toggleTimer;
  $('#tReset').onclick = () => { flushLog(); resetTimer(); syncTimer(); renderTimer(); };
  $('#tSkip').onclick = skipPhase;
  $('#tTask').onchange = (e) => { flushLog(); UI.taskId = e.target.value || ''; saveUI(); pending.taskId = UI.taskId; if (T.running) syncTimer(); renderDay(); renderTimer(); };
  const saveCustom = async () => {
    const custom = { work: Math.max(1, +$('#cWork').value || 25), brk: Math.max(0, +$('#cBreak').value || 0) };
    try { const r = await api('PUT', '/settings', { custom }); S.settings = r.settings; if (!T.running) { resetTimer(); } renderTimer(); } catch (e) { fail(e); }
  };
  $('#cWork').onchange = saveCustom; $('#cBreak').onchange = saveCustom;
  $('#autoStart').onchange = async (e) => { try { const r = await api('PUT', '/settings', { autoStart: e.target.checked }); S.settings = r.settings; } catch (er) { fail(er); } };

  // план
  $('#planShift').onclick = doShift;
  $('#javaNext').onclick = (e) => { const k = e.currentTarget.dataset.k; if (k) { sel = k; const d = parseKey(k); viewMonth = new Date(d.getFullYear(), d.getMonth(), 1); renderAll(); } };
  $('#planNext').onclick = (e) => { const k = e.currentTarget.dataset.k; if (k) { sel = k; const d = parseKey(k); viewMonth = new Date(d.getFullYear(), d.getMonth(), 1); renderAll(); } };
  $('#planGen').onclick = () => openPlanModal('math');
  $('#javaGen').onclick = () => openPlanModal('java');
  $('#pTrack').onchange = () => fillPlanModal($('#pTrack').value);
  $('#pGo').onclick = async () => {
    try {
      const r = await generatePlan($('#pDate').value || todayKey(), +$('#pFrom').value || 1, hasJava() ? $('#pTrack').value : 'math');
      closeModals(); renderAll(); toast('План создан', `Добавлено задач: ${r.count}.`);
    } catch (e) { fail(e); }
  };

  // онбординг
  $('#oGo').onclick = () => finishOnboarding(true);
  $('#oSkip').onclick = () => finishOnboarding(false);

  // настройки
  $('#userBtn').onclick = openSettings;
  $('#sSave').onclick = saveSettings;
  $('#schedAdd').onclick = () => { $('#schedRows').insertAdjacentHTML('beforeend', schedRowHtml({ id: 'n' + Date.now().toString(36), dow: 1, start: '09:00', end: '10:30', title: 'Пара' })); };
  $('#schedRows').addEventListener('click', (e) => { const b = e.target.closest('.s-del'); if (b) b.closest('.sched-row').remove(); });
  $('#sTest').onclick = async () => {
    try { await api('POST', '/test-message', {}); toast('Отправлено', 'Проверь Telegram.'); } catch (e) { fail(e); }
  };
  $('#logoutBtn').onclick = async () => { try { await api('POST', '/auth/logout', {}, { quiet: true }); } catch { /* ignore */ } location.reload(); };
  $('#deleteAcc').onclick = async () => {
    if (!confirm('Удалить аккаунт и ВСЕ данные (задачи, статистику, настройки)? Это нельзя отменить.')) return;
    try { await api('DELETE', '/account', undefined, { quiet: true }); } catch (e) { fail(e); return; }
    location.reload();
  };

  window.addEventListener('pagehide', () => flushLog(true));
  document.addEventListener('visibilitychange', () => { if (document.hidden) flushLog(true); else { timerTick(); if (S && !modalOpen()) refreshState(); } });
  setInterval(() => { if (S && !document.hidden && !inflight && !modalOpen() && !$('#app').hidden) refreshState(); }, 30000);
}

/* ================= запуск ================= */
function startTicker() {
  try { const w = new Worker('/ticker.js'); w.onmessage = () => { if (S) timerTick(); }; }
  catch { setInterval(() => { if (S) timerTick(); }, 1000); }
}
bind();
startTicker();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('/sw.js').catch(() => {});
boot();
})();
