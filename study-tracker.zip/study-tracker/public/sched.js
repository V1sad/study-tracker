'use strict';
// Логика расписания пар, общая для сервера (бот, сводка) и браузера: какие пары идут в конкретную дату.
// Пара — { dow, start, end, title, room, teacher, kind, week: ''|'В'|'Н', ranges: [['MM-DD','MM-DD'], …] }.
// ranges — периоды из «Примечания» на сайте вуза (без года); week — верхняя/нижняя неделя.
(function (root) {
  const dowOf = (key) => { const [y, m, d] = key.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d)).getUTCDay(); };
  const dayNum = (key) => { const [y, m, d] = key.split('-').map(Number); return Math.floor(Date.UTC(y, m - 1, d) / 86400000); };
  // понедельник той недели, в которой лежит дата (номер дня от эпохи)
  const mondayNum = (key) => { const n = dayNum(key); const w = dowOf(key); return n - ((w + 6) % 7); };

  function inRanges(ranges, key) {
    if (!Array.isArray(ranges) || !ranges.length) return true;
    const md = key.slice(5);
    return ranges.some(([a, b]) => (a <= b ? md >= a && md <= b : md >= a || md <= b)); // период может переходить через Новый год
  }
  // 'В' (верхняя) / 'Н' (нижняя) неделя; topWeek — любая дата внутри верхней недели
  function weekKind(topWeek, key) {
    if (!topWeek || !/^\d{4}-\d{2}-\d{2}$/.test(topWeek)) return '';
    const diff = Math.round((mondayNum(key) - mondayNum(topWeek)) / 7);
    return Math.abs(diff) % 2 === 0 ? 'В' : 'Н';
  }
  function classesOn(settings, key) {
    const list = (settings && settings.schedule) || [];
    const wk = weekKind(settings && settings.topWeek, key);
    const dow = dowOf(key);
    return list
      .filter((c) => c.dow === dow && inRanges(c.ranges, key) && (!c.week || !wk || c.week === wk))
      .sort((a, b) => a.start.localeCompare(b.start));
  }
  // «Фамилия И.О.» · аудитория · тип — короткая строка деталей пары
  const classDetails = (c) => [c.kind, c.room, c.teacher].filter(Boolean).join(' · ');

  const api = { classesOn, classDetails, weekKind, inRanges };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.Sched = api;
})(typeof self !== 'undefined' ? self : this);
