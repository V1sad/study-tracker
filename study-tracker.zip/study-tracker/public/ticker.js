// Тикер в Web Worker: не засыпает в фоновой вкладке, как обычный setInterval.
setInterval(function () { postMessage(1); }, 1000);
