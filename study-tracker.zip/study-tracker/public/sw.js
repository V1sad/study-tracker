// Минимальный service worker: нужен, чтобы сайт можно было установить как приложение.
// Данные всегда берутся с сервера, поэтому ничего не кэшируем.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => { /* без кэша: пусть отвечает сеть */ });
